import React, { useState, useEffect } from 'react';
import {
  fetchActiveAcademies,
  registerUserAccount,
  getUserAccountByEmail,
  DEV_EMAILS,
  getLocalAcademies,
} from '../../lib/academyService';
import { type Academy, type AppUser, type UserRole } from '../../types';

export type Role = 'developer' | 'admin' | 'teacher' | 'student' | 'parent';
export type User = AppUser;

export const getCurrentUser = (): AppUser | null => {
  try {
    return JSON.parse(localStorage.getItem('taleemos_current_user_v5') || 'null');
  } catch {
    return null;
  }
};

export const logout = () => {
  localStorage.removeItem('taleemos_current_user_v5');
  location.reload();
};

export const AuthSystem = ({ onLogin }: { onLogin: (u: AppUser) => void }) => {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [academies, setAcademies] = useState<Academy[]>(getLocalAcademies());
  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirm: '',
    role: 'teacher' as Role,
    academyId: '',
    newAcademyName: '',
    newAcademyCode: '',
    newAcademyAddress: '',
  });

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [remember, setRemember] = useState(true);
  const [showPending, setShowPending] = useState(false);
  const [pendingUser, setPendingUser] = useState<AppUser | null>(null);

  useEffect(() => {
    fetchActiveAcademies().then((data) => {
      setAcademies(data);
      if (data.length > 0 && !form.academyId) {
        setForm((prev) => ({ ...prev, academyId: data[0].academyId }));
      }
    });
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const email = form.email.toLowerCase().trim();
    if (!email) {
      setError('Please enter a valid email address.');
      return;
    }

    setLoading(true);

    try {
      if (mode === 'signup') {
        if (form.password !== form.confirm) {
          setError('Passwords do not match');
          setLoading(false);
          return;
        }

        const existing = await getUserAccountByEmail(email);
        if (existing) {
          setError('An account with this email already exists. Please login.');
          setLoading(false);
          return;
        }

        let chosenAcademyId = form.academyId;
        let chosenAcademyName = '';

        if (form.role === 'admin' && form.academyId === 'new') {
          chosenAcademyId = `acad-${Date.now().toString().slice(-4)}`;
          chosenAcademyName = form.newAcademyName || 'New Requested Academy';
        } else {
          const selected = academies.find((a) => a.academyId === form.academyId);
          chosenAcademyId = selected ? selected.academyId : academies[0]?.academyId || 'inst-1';
          chosenAcademyName = selected ? selected.academyName : 'Taleem Academy';
        }

        const newUser = await registerUserAccount({
          uid: `usr-${Date.now()}`,
          email,
          name: form.name.trim(),
          phone: form.phone.trim(),
          role: form.role,
          academyId: form.role === 'developer' ? null : chosenAcademyId,
          academyName: form.role === 'developer' ? 'All Academies' : chosenAcademyName,
          password: form.password,
        });

        if (newUser.status === 'approved') {
          localStorage.setItem('taleemos_current_user_v5', JSON.stringify(newUser));
          onLogin(newUser);
        } else {
          setPendingUser(newUser);
          setShowPending(true);
        }
      } else {
        // Login Flow
        const userDoc = await getUserAccountByEmail(email);

        if (!userDoc) {
          // If developer email, auto-create approved developer account
          if (DEV_EMAILS.includes(email) || email === 'developer@hisaabkitaab.com') {
            const devUser: AppUser = {
              uid: 'dev-master',
              id: 'dev-master',
              email,
              name: 'Super Developer / Chief Architect',
              role: 'developer',
              academyId: null,
              academyName: 'All Academies Network',
              status: 'approved',
              createdAt: Date.now(),
            };
            localStorage.setItem('taleemos_current_user_v5', JSON.stringify(devUser));
            onLogin(devUser);
            return;
          }
          throw new Error('No registered account found. Please sign up first.');
        }

        // Check user approval status
        if (userDoc.status === 'pending') {
          setPendingUser(userDoc);
          setShowPending(true);
          setLoading(false);
          return;
        }

        if (userDoc.status === 'rejected') {
          throw new Error('Your registration was rejected by the administrator. Contact your academy.');
        }

        localStorage.setItem('taleemos_current_user_v5', JSON.stringify(userDoc));
        onLogin(userDoc);
      }
    } catch (err: any) {
      setError(err.message || 'Authentication error. Please check your inputs.');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemo = (role: Role) => {
    let demoUser: AppUser;
    const defaultAcad = academies[0] || {
      academyId: 'inst-1',
      academyName: 'Taleem Academy Main Campus (Kandhkot)',
    };

    switch (role) {
      case 'developer':
        demoUser = {
          uid: 'usr-dev-super',
          id: 'usr-dev-super',
          name: 'Super Developer / Chief Architect',
          email: 'developer@hisaabkitaab.com',
          role: 'developer',
          academyId: null,
          academyName: 'All Academies (Super Super Admin)',
          status: 'approved',
          createdAt: Date.now(),
        };
        break;
      case 'admin':
        demoUser = {
          uid: 'usr-admin-kandhkot',
          id: 'usr-admin-kandhkot',
          name: 'Prof. Ghulam Rasool (Academy Admin)',
          email: 'admin.kandhkot@taleemacademy.edu.pk',
          role: 'admin',
          academyId: defaultAcad.academyId,
          academyName: defaultAcad.academyName,
          status: 'approved',
          createdAt: Date.now(),
        };
        break;
      case 'teacher':
        demoUser = {
          uid: 'usr-teach-1',
          id: 'usr-teach-1',
          name: 'Sir Sajjad Ali Qasmi (Senior Faculty)',
          email: 'teacher@taleemacademy.edu.pk',
          role: 'teacher',
          academyId: defaultAcad.academyId,
          academyName: defaultAcad.academyName,
          status: 'approved',
          createdAt: Date.now(),
        };
        break;
      case 'student':
        demoUser = {
          uid: 'usr-stud-1',
          id: 'usr-stud-1',
          name: 'Ahmed Ali (Roll # TA-2026-001)',
          email: 'student.ahmed@taleemacademy.edu.pk',
          role: 'student',
          academyId: defaultAcad.academyId,
          academyName: defaultAcad.academyName,
          status: 'approved',
          createdAt: Date.now(),
        };
        break;
      case 'parent':
        demoUser = {
          uid: 'usr-parent-1',
          id: 'usr-parent-1',
          name: 'Haji Mohammad Qasmi (Parent)',
          email: 'parent.qasmi@taleemacademy.edu.pk',
          role: 'parent',
          academyId: defaultAcad.academyId,
          academyName: defaultAcad.academyName,
          status: 'approved',
          createdAt: Date.now(),
        };
        break;
    }

    localStorage.setItem('taleemos_current_user_v5', JSON.stringify(demoUser));
    onLogin(demoUser);
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex items-center justify-center p-4 relative font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Background radial glow */}
      <div className="absolute inset-0 bg-radial from-indigo-500/10 via-transparent to-transparent pointer-events-none" />

      {/* Pending Approval Modal */}
      {showPending && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div onClick={() => setShowPending(false)} className="absolute inset-0 bg-black/70 backdrop-blur-md" />
          <div className="relative bg-white rounded-3xl w-full max-w-md p-6 text-center shadow-2xl border border-slate-200">
            <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto text-2xl font-bold mb-3 shadow-inner">
              ⏳
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-0.5 rounded-full">
              Status: Pending Approval
            </span>
            <h3 className="text-xl font-black text-slate-900 mt-2">
              Waiting for Approval
            </h3>

            <div className="mt-3 p-3.5 bg-slate-50 rounded-2xl border text-left text-xs space-y-1.5 text-slate-700">
              <p>
                <b>Account:</b> {pendingUser?.name} ({pendingUser?.email})
              </p>
              <p>
                <b>Requested Role:</b> <span className="uppercase font-bold text-indigo-600">{pendingUser?.role}</span>
              </p>
              <p>
                <b>Academy:</b> {pendingUser?.academyName || 'Pending Allocation'}
              </p>
            </div>

            <p className="text-xs text-slate-500 mt-3 leading-relaxed">
              {pendingUser?.role === 'admin'
                ? 'Your Admin registration has been sent to the Super Developer (developer@hisaabkitaab.com). You will be granted access once your academy is authorized.'
                : `Your registration has been sent to your Academy Administrator (${pendingUser?.academyName}). You will be able to log in as soon as they approve your profile.`}
            </p>

            <div className="mt-5 flex gap-2">
              <button
                type="button"
                onClick={async () => {
                  setLoading(true);
                  if (pendingUser?.email) {
                    const refreshed = await getUserAccountByEmail(pendingUser.email);
                    if (refreshed?.status === 'approved') {
                      localStorage.setItem('taleemos_current_user_v5', JSON.stringify(refreshed));
                      onLogin(refreshed);
                      return;
                    }
                  }
                  setLoading(false);
                  setError('Account is still pending approval.');
                }}
                className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition cursor-pointer"
              >
                {loading ? 'Checking...' : 'Check Approval Status'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowPending(false);
                  setMode('login');
                }}
                className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Authentication Card */}
      <div className="w-full max-w-md bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-800/40 relative z-10">
        {/* Header Branding */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-gradient-to-tr from-indigo-600 to-indigo-800 text-white rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-indigo-600/30 text-xl font-black mb-3">
            TO
          </div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">TaleemOS Hub</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Enterprise Multi-Tenant Educational ERP Architecture
          </p>
        </div>

        {/* Tab Toggle */}
        <div className="flex bg-slate-100 p-1 rounded-2xl mb-5 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setError('');
            }}
            className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
              mode === 'login' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('signup');
              setError('');
            }}
            className={`flex-1 py-2 rounded-xl transition cursor-pointer ${
              mode === 'signup' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            Register Profile
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-medium leading-relaxed">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'signup' && (
            <>
              {/* Full Name */}
              <div>
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. Sajjad Ali Qasmi"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 font-medium"
                />
              </div>

              {/* Role Selection */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                    Your Role *
                  </label>
                  <select
                    value={form.role}
                    onChange={(e) => setForm({ ...form, role: e.target.value as Role })}
                    className="w-full px-3 py-2.5 bg-slate-50 border rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-indigo-500"
                  >
                    <option value="admin">🎓 Academy Admin</option>
                    <option value="teacher">👨‍🏫 Teacher / Faculty</option>
                    <option value="student">👨‍🎓 Student</option>
                    <option value="parent">👨‍👩‍👧 Parent</option>
                    <option value="developer">👑 Developer (Master)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                    Phone (Optional)
                  </label>
                  <input
                    type="tel"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="0300-1234567"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 font-medium"
                  />
                </div>
              </div>

              {/* Academy Selector */}
              {form.role !== 'developer' && (
                <div>
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                    Select Your Academy *
                  </label>
                  <select
                    value={form.academyId}
                    onChange={(e) => setForm({ ...form, academyId: e.target.value })}
                    className="w-full px-3 py-2.5 bg-slate-50 border rounded-xl text-xs font-bold text-slate-800 outline-none focus:border-indigo-500 truncate"
                  >
                    {academies.map((a) => (
                      <option key={a.academyId} value={a.academyId}>
                        {a.academyName} ({a.code})
                      </option>
                    ))}
                    {form.role === 'admin' && (
                      <option value="new">+ Request New Academy Setup</option>
                    )}
                  </select>
                </div>
              )}

              {/* If Requesting New Academy (Admin only) */}
              {form.role === 'admin' && form.academyId === 'new' && (
                <div className="p-3 bg-indigo-50/60 border border-indigo-200 rounded-2xl space-y-2">
                  <p className="text-[11px] font-bold text-indigo-900">New Academy Proposal:</p>
                  <input
                    type="text"
                    required
                    value={form.newAcademyName}
                    onChange={(e) => setForm({ ...form, newAcademyName: e.target.value })}
                    placeholder="Academy / School Name"
                    className="w-full px-3 py-2 bg-white border rounded-xl text-xs"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      value={form.newAcademyCode}
                      onChange={(e) => setForm({ ...form, newAcademyCode: e.target.value })}
                      placeholder="Code (e.g. TAK-04)"
                      className="w-full px-3 py-2 bg-white border rounded-xl text-xs uppercase font-mono"
                    />
                    <input
                      type="text"
                      value={form.newAcademyAddress}
                      onChange={(e) => setForm({ ...form, newAcademyAddress: e.target.value })}
                      placeholder="City / Address"
                      className="w-full px-3 py-2 bg-white border rounded-xl text-xs"
                    />
                  </div>
                </div>
              )}
            </>
          )}

          {/* Email */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Email Address *
            </label>
            <input
              type="email"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              placeholder="e.g. user@taleemacademy.edu.pk"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          {/* Password */}
          <div>
            <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1">
              Password *
            </label>
            <input
              type="password"
              required
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              placeholder="••••••••"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          {mode === 'signup' && (
            <div>
              <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1">
                Confirm Password *
              </label>
              <input
                type="password"
                required
                value={form.confirm}
                onChange={(e) => setForm({ ...form, confirm: e.target.value })}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 font-medium"
              />
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-black shadow-lg shadow-indigo-600/30 transition cursor-pointer"
            >
              {loading ? 'Processing...' : mode === 'login' ? 'Sign In to Portal' : 'Submit Registration'}
            </button>
          </div>
        </form>

        {/* 1-Click Quick Demo Access for 5 Roles */}
        <div className="mt-5 pt-4 border-t border-slate-100">
          <p className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 text-center mb-2.5">
            ⚡ Quick 1-Click Role Testing
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            <button
              type="button"
              onClick={() => handleQuickDemo('developer')}
              className="p-2 bg-slate-900 hover:bg-black text-white rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition cursor-pointer col-span-2 sm:col-span-1"
            >
              👑 Developer
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('admin')}
              className="p-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition cursor-pointer border border-indigo-200"
            >
              🎓 Admin
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('teacher')}
              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition cursor-pointer"
            >
              👨‍🏫 Teacher
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('student')}
              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition cursor-pointer"
            >
              👨‍🎓 Student
            </button>
            <button
              type="button"
              onClick={() => handleQuickDemo('parent')}
              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-[11px] font-bold flex items-center justify-center gap-1 transition cursor-pointer col-span-2 sm:col-span-2"
            >
              👨‍👩‍👧 Parent Portal
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
