import React, { useState, useEffect } from 'react';
import {
  Menu,
  Search,
  Bell,
  Shield,
  Building2,
  Download,
  Calendar,
  Clock,
  CheckCircle,
  Database,
} from 'lucide-react';
import { erpStorage, INSTITUTIONS } from '../../lib/storage';
import { type UserRole, type Academy } from '../../types';
import { getCurrentUser, logout, type User } from '../auth/AuthSystem';
import { fetchActiveAcademies } from '../../lib/academyService';

interface HeaderProps {
  onToggleMobileDrawer: () => void;
  onOpenSearch: () => void;
  onOpenApprovals: () => void;
  onOpenExportZip: () => void;
  onNavigate: (path: string) => void;
  currentUser?: User | null;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleMobileDrawer,
  onOpenSearch,
  onOpenApprovals,
  onOpenExportZip,
  onNavigate,
  currentUser: propUser,
}) => {
  const state = erpStorage.getState();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [currentUser, setCurrentUser] = useState<User | null>(propUser || getCurrentUser());
  const [activeAcademies, setActiveAcademies] = useState<Academy[]>([]);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (propUser) {
      setCurrentUser(propUser);
    } else {
      setCurrentUser(getCurrentUser());
    }
    fetchActiveAcademies().then(setActiveAcademies);
  }, [propUser]);

  const isDev = currentUser?.role === 'developer';
  const isAdmin = currentUser?.role === 'admin';

  const pendingApprovalsCount = state.approvals.filter(
    (a) => a.status === 'Pending Approval'
  ).length;

  const currentInstitution =
    INSTITUTIONS.find((i) => i.id === state.activeInstitutionId) || INSTITUTIONS[0];

  const handleInstitutionChange = (instId: string) => {
    erpStorage.setActiveInstitution(instId);
  };

  const formattedDate = currentTime.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  const formattedTime = currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  // Role Badge Styling
  const getRoleBadge = (role?: string) => {
    switch (role) {
      case 'developer':
        return { label: 'Developer', color: 'bg-purple-500/20 text-purple-300 border-purple-400/40', icon: '👑' };
      case 'admin':
        return { label: 'Academy Admin', color: 'bg-blue-500/20 text-blue-300 border-blue-400/40', icon: '🛡️' };
      case 'teacher':
        return { label: 'Teacher', color: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/40', icon: '👨‍🏫' };
      case 'student':
        return { label: 'Student', color: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40', icon: '🎓' };
      case 'parent':
        return { label: 'Parent', color: 'bg-amber-500/20 text-amber-300 border-amber-400/40', icon: '👨‍👩‍👧' };
      default:
        return { label: role || 'Member', color: 'bg-slate-500/20 text-slate-300 border-slate-400/40', icon: '👤' };
    }
  };

  const roleBadge = getRoleBadge(currentUser?.role);

  return (
    <header className="sticky top-0 z-20 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white border-b border-indigo-900/40 shadow-lg no-print">
      {/* Top Header Row */}
      <div className="px-4 md:px-6 py-2.5 flex items-center justify-between gap-2 md:gap-4">
        {/* Left side: Hamburger (mobile) + Campus selector */}
        <div className="flex items-center gap-2 md:gap-4">
          <button
            type="button"
            onClick={onToggleMobileDrawer}
            className="md:hidden p-2 text-slate-300 hover:text-white rounded-xl hover:bg-white/10 cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Campus Multi-Tenant Switcher / Scoped Academy Display */}
          {isDev ? (
            <div className="flex items-center gap-2 bg-purple-900/40 hover:bg-purple-900/60 backdrop-blur-md px-3 py-1.5 rounded-xl border border-purple-500/40 transition-colors">
              <Building2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
              <div className="flex flex-col">
                <span className="text-[9px] uppercase font-bold text-purple-300 leading-none">
                  Dev Network Scope
                </span>
                <select
                  value={state.activeInstitutionId}
                  onChange={(e) => handleInstitutionChange(e.target.value)}
                  className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer pr-1"
                >
                  <option value="all" className="bg-slate-900 text-purple-300">
                    🌐 All Academies (Global Network)
                  </option>
                  {(activeAcademies.length > 0 ? activeAcademies : INSTITUTIONS).map((inst: any) => (
                    <option
                      key={inst.academyId || inst.id}
                      value={inst.academyId || inst.id}
                      className="bg-slate-900 text-white"
                    >
                      {inst.academyName || inst.name || inst.campusName} ({inst.code})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10">
              <Building2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <div className="flex flex-col">
                <span className="text-[9px] uppercase font-bold text-slate-400 leading-none">
                  My Academy
                </span>
                <span className="text-xs font-bold text-white truncate max-w-[170px] sm:max-w-[240px]">
                  {currentUser?.academyName || currentInstitution.campusName || 'Taleem Academy'}
                </span>
              </div>
            </div>
          )}

          {/* Live Date / Time */}
          <div className="hidden lg:flex items-center gap-3 text-xs text-slate-300 border-l border-white/10 pl-3">
            <div className="flex items-center gap-1.5 font-medium">
              <Calendar className="w-3.5 h-3.5 text-indigo-400" />
              <span>{formattedDate}</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-indigo-200 bg-white/5 px-2 py-0.5 rounded">
              <Clock className="w-3 h-3 text-indigo-400" />
              <span>{formattedTime}</span>
            </div>
          </div>
        </div>

        {/* Center / Right side: Search, Developer Hub, Approvals, Profile, SignOut */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* Spotlight Search Trigger */}
          <button
            type="button"
            onClick={onOpenSearch}
            className="flex items-center gap-2 px-3 py-1.5 bg-white/10 hover:bg-white/15 backdrop-blur-md border border-white/10 rounded-xl text-xs text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            <Search className="w-3.5 h-3.5 text-indigo-300" />
            <span className="hidden sm:inline">Search Hub</span>
            <kbd className="hidden sm:inline-block px-1.5 py-0.2 bg-black/30 text-[10px] font-mono rounded text-slate-300">
              Ctrl+K
            </kbd>
          </button>

          {/* Developer Direct Link if Developer */}
          {isDev && (
            <button
              onClick={() => onNavigate('developer')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-bold border border-purple-400/40 shadow-sm transition active:scale-95 cursor-pointer"
            >
              <span>👑 Developer Hub</span>
            </button>
          )}

          {/* User Role Badge */}
          <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-bold ${roleBadge.color}`}>
            <span>{roleBadge.icon}</span>
            <span className="hidden sm:inline">{roleBadge.label}</span>
          </div>

          {/* Approvals Center Bell Trigger */}
          <button
            type="button"
            onClick={onOpenApprovals}
            title="Open Approvals Center"
            className="relative p-2 bg-white/10 hover:bg-white/15 text-slate-200 hover:text-white rounded-xl border border-white/10 transition-colors cursor-pointer"
          >
            <Bell className="w-4 h-4" />
            {pendingApprovalsCount > 0 && (
              <span className="absolute -top-1 -right-1 px-1.5 py-0.2 bg-rose-500 text-white font-black text-[10px] rounded-full animate-bounce shadow">
                {pendingApprovalsCount}
              </span>
            )}
          </button>

          {/* Termux ZIP Export Button */}
          <button
            type="button"
            onClick={onOpenExportZip}
            title="Download ZIP for Termux"
            className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black rounded-xl shadow-md shadow-emerald-900/30 active:scale-95 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export ZIP</span>
          </button>

          {/* User Sign Out */}
          <button
            type="button"
            onClick={logout}
            title="Sign out of account"
            className="px-2.5 py-1.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 hover:text-white border border-rose-500/40 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
          >
            <span className="text-xs">🚪</span>
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </div>

      {/* Header Embedded KPIs Row */}
      <div className="px-4 md:px-6 py-2 bg-black/25 border-t border-white/5 flex items-center justify-between overflow-x-auto text-xs whitespace-nowrap gap-4 scrollbar-none">
        <div className="flex items-center gap-6">
          <div
            onClick={() => onNavigate('students')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Students:</span>
            <span className="font-extrabold text-white font-mono">{state.students.length}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          </div>

          <div
            onClick={() => onNavigate('admissions')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Confirmed Adm:</span>
            <span className="font-extrabold text-emerald-300 font-mono">
              {state.admissions.filter((a) => a.status === 'Confirmed').length}
            </span>
          </div>

          <div
            onClick={() => onNavigate('batches')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Active Batches:</span>
            <span className="font-extrabold text-indigo-300 font-mono">
              {state.batches.filter((b) => b.status === 'Active').length}
            </span>
          </div>

          <div
            onClick={() => onNavigate('fees')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-[11px] text-slate-400 uppercase font-semibold">October Fee Col:</span>
            <span className="font-extrabold text-amber-300 font-mono">
              PKR{' '}
              {state.fees
                .filter((f) => f.status === 'Paid')
                .reduce((acc, curr) => acc + curr.netPayable, 0)
                .toLocaleString()}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-slate-400 text-[11px]">
          <Database className="w-3 h-3 text-cyan-400" />
          <span>Storage: Local + Firebase Sync</span>
        </div>
      </div>
    </header>
  );
};
