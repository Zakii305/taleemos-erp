import React, { useState, useEffect } from 'react';
import { setUserApprovalStatus, getLocalUsers } from '../../lib/academyService';

interface Props {
  currentPath: string;
  setCurrentPath: (p: string) => void;
  isMobileDrawerOpen: boolean;
  setIsMobileDrawerOpen: (v: boolean) => void;
}

interface UserItem {
  id: string;
  name: string;
  email: string;
  role: string;
  institutionId: string;
  institutionName: string;
  status: string;
}

const BASE_MENU = [
  { section: 'MAIN', items: [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'alerts', label: 'Alerts & Notifications', icon: '🔔', pro: true },
  ]},
  { section: 'ADMISSIONS', items: [
    { id: 'enquiries', label: 'New Enquiries', icon: '📝', pro: true },
    { id: 'admissions', label: 'Admissions', icon: '✅', pro: true },
    { id: 'batches', label: 'Batches', icon: '👥', pro: true },
  ]},
  { section: 'STUDENTS', items: [
    { id: 'students', label: 'Students Directory', icon: '🎓' },
    { id: 'idCards', label: 'ID Cards', icon: '🪪' },
    { id: 'transfers', label: 'Transfers / TC', icon: '🔄', pro: true },
    { id: 'promote', label: 'Promote', icon: '⬆️' },
    { id: 'certificates', label: 'Certificates', icon: '🏅' },
  ]},
  { section: 'ACADEMICS', items: [
    { id: 'calendar', label: 'Academic Calendar', icon: '📅', pro: true },
    { id: 'courses', label: 'Courses', icon: '📚' },
    { id: 'timetable', label: 'Timetable', icon: '🕒', pro: true },
    { id: 'exams', label: 'Exams', icon: '📝' },
    { id: 'reportCards', label: 'Report Cards', icon: '📄', pro: true },
    { id: 'library', label: 'Library', icon: '📚' },
  ]},
  { section: 'ATTENDANCE', items: [
    { id: 'attendance', label: 'Student Attend', icon: '📅' },
    { id: 'staffAttendance', label: 'Staff Attend', icon: '👔' },
    { id: 'leaves', label: 'Leave Mgmt', icon: '🌴', pro: true },
  ]},
  { section: 'FINANCE', items: [
    { id: 'fees', label: 'Fees & Challans', icon: '💰' },
    { id: 'defaulters', label: 'Fee Defaulters', icon: '⚠️' },
    { id: 'expenses', label: 'Expenses Ledger', icon: '💸' },
    { id: 'payroll', label: 'Payroll & Salaries', icon: '💵' },
    { id: 'accounts', label: 'Accounts & Ledger', icon: '📒', pro: true },
  ]},
  { section: 'OPERATIONS', items: [
    { id: 'teachers', label: 'Teacher Zone', icon: '👨‍🏫' },
    { id: 'campus', label: 'Campus Facilities', icon: '🏫' },
    { id: 'inventory', label: 'Inventory Stock', icon: '📦' },
    { id: 'assets', label: 'Assets & Equipment', icon: '🏛️' },
    { id: 'communication', label: 'Broadcast SMS / WhatsApp', icon: '💬', pro: true },
    { id: 'settings', label: 'Settings', icon: '⚙️' },
  ]},
];

function formatSince(id: string){
  try {
    const ts = parseInt(id.replace(/\D/g,'').slice(0,13));
    if(!isNaN(ts) && ts > 1000000000000){
      const d = new Date(ts);
      const diff = Date.now() - d.getTime();
      const days = Math.floor(diff/(1000*60*60*24));
      if(days===0) return 'Today';
      if(days===1) return '1d ago';
      if(days<30) return `${days}d ago`;
      return d.toLocaleDateString('en-GB', {day:'2-digit', month:'short'});
    }
  } catch {}
  return 'Recently';
}

export const SidebarDrawer: React.FC<Props> = ({ currentPath, setCurrentPath, isMobileDrawerOpen, setIsMobileDrawerOpen }) => {
  const [users, setUsers] = useState<UserItem[]>([]);
  const [showUsers, setShowUsers] = useState(false);
  const [showApprovals, setShowApprovals] = useState(true);
  const [currentUser, setCurrentUser] = useState<any>(null);

  const load = () => {
    try {
      const v5: UserItem[] = JSON.parse(localStorage.getItem('taleemos_users_v5') || '[]');
      const coll = getLocalUsers();
      
      // Merge users by email
      const map = new Map<string, UserItem>();
      v5.forEach((u) => map.set(u.email.toLowerCase(), u));
      coll.forEach((c) => {
        map.set(c.email.toLowerCase(), {
          id: c.uid || c.id || '',
          name: c.name,
          email: c.email,
          role: c.role,
          institutionId: c.academyId || '',
          institutionName: c.academyName || '',
          status: c.status,
        });
      });

      setUsers(Array.from(map.values()));
      setCurrentUser(JSON.parse(localStorage.getItem('taleemos_current_user_v5') || 'null'));
    } catch {}
  };

  useEffect(()=>{
    load();
    const onStorage = () => load();
    window.addEventListener('storage', onStorage);
    const interval = setInterval(load, 2000);
    return ()=>{ window.removeEventListener('storage', onStorage); clearInterval(interval); };
  }, []);

  const save = (newUsers: UserItem[]) => {
    setUsers(newUsers);
    localStorage.setItem('taleemos_users_v5', JSON.stringify(newUsers));
    window.dispatchEvent(new Event('storage'));
  };

  const updateStatus = async (id: string, status: 'approved' | 'rejected') => {
    await setUserApprovalStatus(id, status);
    save(users.map((u) => (u.id === id ? { ...u, status } : u)));
  };

  const deleteUser = (id:string, target: UserItem) => {
    const isDev = currentUser?.role==='developer';
    const isAdmin = currentUser?.role==='admin';
    if(!isDev){
      if(target.role==='admin' || target.role==='developer'){
        alert('❌ Admin cannot delete Admin/Developer');
        return;
      }
      if(target.institutionId!==currentUser?.institutionId && target.institutionId!==currentUser?.academyId){
        alert('❌ Only your academy roles can be deleted');
        return;
      }
    }
    if(confirm(`Delete ${target.name}?`)){
      save(users.filter(u=>u.id!==id));
    }
  };

  const isDev = currentUser?.role==='developer';
  const isAdmin = currentUser?.role==='admin';
  const userAcadId = currentUser?.academyId || currentUser?.institutionId;

  // Filter approvals as per rules
  const approvalList = users.filter((u) => {
    if (u.status !== 'pending') return false;
    if (isDev) return true; // Developer sees all pending (including admin)
    if (isAdmin) return (u.institutionId === userAcadId) && u.role !== 'admin' && u.role !== 'developer';
    return false;
  });

  const adminRequests = users.filter((u) => u.role === 'admin');

  // Build menu with Developer Hub if developer
  const MENU = [
    ...(isDev
      ? [
          {
            section: 'DEVELOPER SUPER ADMIN',
            items: [
              { id: 'developer', label: 'Developer Master Hub', icon: '👑', pro: true },
            ],
          },
        ]
      : []),
    ...BASE_MENU,
  ];

  return (
    <>
      {isMobileDrawerOpen && <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={()=>setIsMobileDrawerOpen(false)} />}
      <div className={`fixed left-0 top-0 h-full w-[285px] bg-[#0f172a] text-white z-50 transform transition-transform md:translate-x-0 ${isMobileDrawerOpen ? 'translate-x-0' : '-translate-x-full'} flex flex-col`}>
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold">T</div>
            <div><div className="font-bold text-sm flex items-center gap-2">TaleemOS Hub <span className="bg-orange-500 text-[9px] px-1.5 py-0.5 rounded">BETA • ERP</span></div><div className="text-[10px] text-slate-400">Educational ERP Suite</div></div>
          </div>
          <div className="mt-3 relative"><input placeholder="Search 23 modules..." className="w-full bg-white/10 rounded-lg px-3 py-2 text-xs placeholder:text-slate-400" /><span className="absolute right-2 top-2 text-[10px] bg-white/20 px-1.5 py-0.5 rounded">Ctrl K</span></div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {/* REQUEST APPROVALS IN DRAWER - As you requested */}
          <div className="p-3 border-b border-white/10 bg-gradient-to-br from-orange-500/10 to-indigo-600/10">
            <button onClick={()=>setShowApprovals(!showApprovals)} className="w-full flex justify-between items-center text-[11px] font-bold tracking-widest text-orange-300 mb-2">
              <span>✅ REQUEST APPROVALS • {approvalList.length}</span>
              <span className="flex items-center gap-2">
                {approvalList.length>0 && <span className="bg-orange-500 text-white text-[10px] px-2 py-0.5 rounded-full animate-pulse">{approvalList.length} NEW</span>}
                <span>{showApprovals?'▼':'▶'}</span>
              </span>
            </button>
            
            {showApprovals && (
              <div className="space-y-2">
                <div className="text-[10px] text-slate-400 bg-black/20 p-2 rounded">
                  {isDev ? '👑 Dev: You approve Admins of any institution' : isAdmin ? `🛡️ Admin: You approve Teachers/Students/Parents of ${currentUser?.institutionName}` : 'No approval rights'}
                </div>

                {approvalList.length===0 && <div className="text-[11px] text-slate-500 text-center py-4 bg-white/5 rounded-lg">✅ No pending requests<br/><span className="text-[9px]">All clear!</span></div>}

                {approvalList.map(u=>(
                  <div key={u.id} className="bg-white/10 hover:bg-white/[0.15] border border-orange-500/20 rounded-xl p-2.5">
                    <div className="flex gap-2">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[11px] font-bold ${u.role==='admin'?'bg-blue-600':u.role==='teacher'?'bg-green-600':'bg-slate-600'}`}>{u.name.charAt(0)}</div>
                      <div className="flex-1 min-w-0">
                        <div className="text-[11px] font-bold truncate">{u.name} <span className={`text-[8px] px-1 py-0.5 rounded ${u.role==='admin'?'bg-blue-600':'bg-white/20'}`}>{u.role.toUpperCase()}</span></div>
                        <div className="text-[9px] text-slate-300 truncate">{u.email}</div>
                        <div className="text-[9px] text-slate-400 mt-1 flex gap-1">
                          <span className="bg-white/10 px-1 rounded truncate">{u.institutionName?.slice(0,20)}</span>
                          <span>• {formatSince(u.id)}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-1 mt-2.5">
                      <button onClick={()=>updateStatus(u.id,'approved')} className="flex-1 bg-green-600 hover:bg-green-700 text-white text-[10px] py-1.5 rounded-lg font-bold">✓ Approve</button>
                      <button onClick={()=>updateStatus(u.id,'rejected')} className="flex-1 bg-white/10 hover:bg-white/20 text-white text-[10px] py-1.5 rounded-lg">✕ Reject</button>
                      <button onClick={()=>deleteUser(u.id, u)} className="bg-red-600/80 hover:bg-red-600 text-white text-[10px] px-2 py-1.5 rounded-lg">🗑️</button>
                    </div>
                  </div>
                ))}

                {isDev && adminRequests.filter(a=>a.status==='pending').length>0 && (
                  <div className="mt-3 pt-3 border-t border-white/10">
                    <div className="text-[10px] font-bold text-blue-300 mb-2">👑 ADMIN REQUESTS (Dev Only)</div>
                    {adminRequests.filter(a=>a.status==='pending').map(u=>(
                      <div key={u.id} className="bg-blue-600/20 border border-blue-500/30 rounded-lg p-2 mb-2 flex justify-between items-center">
                        <div className="text-[11px]"><b>{u.name}</b><br/><span className="text-[9px] text-slate-400">{u.institutionName}</span></div>
                        <div className="flex gap-1"><button onClick={()=>updateStatus(u.id,'approved')} className="bg-green-600 text-white text-[9px] px-2 py-1 rounded">Approve</button><button onClick={()=>deleteUser(u.id, u)} className="bg-red-600 text-white text-[9px] px-2 py-1 rounded">Del</button></div>
                      </div>
                    ))}
                  </div>
                )}

                <button onClick={()=>{ setCurrentPath('approvals'); setIsMobileDrawerOpen(false); }} className="w-full text-[10px] text-orange-300 hover:text-orange-200 py-2 bg-white/5 rounded-lg mt-2">Open Full Approvals Page →</button>
              </div>
            )}
          </div>

          {/* USER SECTION */}
          <div className="p-3 border-b border-white/10">
            <button onClick={()=>setShowUsers(!showUsers)} className="w-full flex justify-between items-center text-[11px] font-bold tracking-widest text-slate-400 mb-2">
              <span>👥 USER SECTION • {users.length}</span>
              <span>{showUsers?'▼':'▶'}</span>
            </button>
            {showUsers && (
              <div className="space-y-1.5 max-h-[200px] overflow-y-auto pr-1">
                {users.slice(0,15).map(u=>(
                  <div key={u.id} className="bg-white/5 rounded-lg p-2 flex gap-2 text-[11px]">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[9px] font-bold ${u.role==='developer'?'bg-purple-600':u.role==='admin'?'bg-blue-600':u.role==='teacher'?'bg-green-600':'bg-slate-600'}`}>{u.name.charAt(0)}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1"><span className="truncate font-medium">{u.name}</span><span className={`text-[7px] px-1 rounded ${u.status==='approved'?'bg-green-600':'bg-orange-500'}`}>{u.status}</span></div>
                      <div className="text-[9px] text-slate-400 flex gap-1"><span className="bg-white/10 px-1 rounded">{u.role}</span><span className="truncate">{u.institutionName?.split(' ')[0]}</span><span>• {formatSince(u.id)}</span></div>
                    </div>
                    {(isDev || (isAdmin && u.institutionId===currentUser?.institutionId && u.role!=='admin' && u.role!=='developer')) && <button onClick={()=>deleteUser(u.id, u)} className="text-[10px] text-red-400 hover:text-red-300">🗑️</button>}
                  </div>
                ))}
                <button onClick={()=>{ setCurrentPath('users'); setIsMobileDrawerOpen(false); }} className="w-full text-[10px] text-indigo-400 py-1">View all {users.length} users →</button>
              </div>
            )}
          </div>

          <div className="p-3 space-y-4">
            {MENU.map(sec=>(
              <div key={sec.section}>
                <div className="text-[10px] tracking-widest text-slate-500 font-bold mb-2">{sec.section}</div>
                <div className="space-y-0.5">
                  {sec.items.map(item => {
                    const isSelected = currentPath.toLowerCase().replace(/[-_]/g, '') === item.id.toLowerCase().replace(/[-_]/g, '');
                    return (
                      <button
                        key={item.id}
                        onClick={() => { setCurrentPath(item.id); setIsMobileDrawerOpen(false); }}
                        className={`w-full text-left px-3 py-2 rounded-xl text-[12px] flex items-center gap-2.5 transition-all ${
                          isSelected
                            ? 'bg-gradient-to-r from-indigo-600 to-indigo-700 text-white font-bold shadow-md shadow-indigo-900/40'
                            : 'text-slate-300 hover:bg-white/5 hover:text-white'
                        }`}
                      >
                        <span className="text-[14px]">{item.icon}</span>
                        <span className="flex-1 truncate">{item.label}</span>
                        {(item as any).pro && <span className="text-[8px] bg-indigo-400/20 text-indigo-300 border border-indigo-400/30 px-1.5 py-0.2 rounded font-bold">PRO</span>}
                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-sm shadow-emerald-400"></span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-3 border-t border-white/10 bg-[#0f172a] text-[10px] text-slate-500">
          {currentUser?.role.toUpperCase()} • {currentUser?.institutionName?.slice(0,25)} • Since {formatSince(currentUser?.id || '')}
        </div>
      </div>
    </>
  );
};
