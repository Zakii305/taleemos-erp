import React, { useState } from 'react';
import {
  Layers,
  Plus,
  Printer,
  Download,
  Search,
  User,
  Clock,
  DoorOpen,
  UserPlus,
  Trash2,
  Edit2,
  Calendar,
  Percent,
} from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type Batch } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const BatchesModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [courseFilter, setCourseFilter] = useState('All');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedBatch, setSelectedBatch] = useState<Batch | null>(null);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);

  // 12 fields as required
  const [batchName, setBatchName] = useState('');
  const [course, setCourse] = useState('F.Sc Pre-Engineering');
  const [teacher, setTeacher] = useState('Sir Saeed Ahmed (Physics)');
  const [room, setRoom] = useState('Room 101 - Lecture Hall A');
  const [capacity, setCapacity] = useState(40);
  const [enrolled, setEnrolled] = useState(0);
  const [timing, setTiming] = useState('08:00 AM - 01:00 PM');
  const [status, setStatus] = useState<Batch['status']>('Active');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState('');
  const [feeStructure, setFeeStructure] = useState('PKR 4,500/Month');
  const [remarks, setRemarks] = useState('');

  // 5 KPIs (Total, Active, Upcoming, Enrolled/Capacity, Occupancy %)
  const totalBatches = state.batches.length;
  const activeCount = state.batches.filter((b) => b.status === 'Active').length;
  const upcomingCount = state.batches.filter((b) => b.status === 'Upcoming').length;
  const totalEnrolled = state.batches.reduce((sum, b) => sum + b.enrolled, 0);
  const totalCapacity = state.batches.reduce((sum, b) => sum + b.capacity, 0);
  const overallOccupancy = totalCapacity > 0 ? Math.round((totalEnrolled / totalCapacity) * 100) : 0;

  const filtered = state.batches.filter((b) => {
    const matchSearch =
      b.batchName.toLowerCase().includes(search.toLowerCase()) ||
      b.teacher.toLowerCase().includes(search.toLowerCase()) ||
      b.room.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'All' || b.status === statusFilter;
    const matchCourse = courseFilter === 'All' || b.course === courseFilter;
    return matchSearch && matchStatus && matchCourse;
  });

  const handleSaveBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchName.trim() || !course.trim()) return;

    if (isEditMode && selectedBatch) {
      erpStorage.updateItem('batches', selectedBatch.id, {
        batchName,
        course,
        teacher,
        room,
        capacity: Number(capacity),
        enrolled: Number(enrolled),
        timing,
        status,
        startDate,
        endDate: endDate || '2027-05-30',
        feeStructure,
        remarks,
      });
    } else {
      const newBatch: Batch = {
        id: `BAT-0${state.batches.length + 1}`,
        batchName,
        course,
        teacher,
        room,
        capacity: Number(capacity),
        enrolled: Number(enrolled),
        timing,
        status,
        startDate,
        endDate: endDate || '2027-05-30',
        feeStructure,
        remarks,
      };
      erpStorage.addItem('batches', newBatch);
    }

    setIsAddModalOpen(false);
    setIsEditMode(false);
    setSelectedBatch(null);
    resetForm();
  };

  const resetForm = () => {
    setBatchName('');
    setCapacity(40);
    setEnrolled(0);
    setRemarks('');
  };

  const handlePlusOneEnroll = (b: Batch, e: React.MouseEvent) => {
    e.stopPropagation();
    if (b.enrolled < b.capacity) {
      erpStorage.updateItem('batches', b.id, { enrolled: b.enrolled + 1 });
    } else {
      alert(`Batch ${b.batchName} has reached full capacity of ${b.capacity} students.`);
    }
  };

  const handleOpenEdit = (b: Batch, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedBatch(b);
    setIsEditMode(true);
    setBatchName(b.batchName);
    setCourse(b.course);
    setTeacher(b.teacher);
    setRoom(b.room);
    setCapacity(b.capacity);
    setEnrolled(b.enrolled);
    setTiming(b.timing);
    setStatus(b.status);
    setStartDate(b.startDate);
    setEndDate(b.endDate);
    setFeeStructure(b.feeStructure);
    setRemarks(b.remarks);
    setIsAddModalOpen(true);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this batch?')) {
      erpStorage.deleteItem('batches', id);
      if (selectedBatch?.id === id) setSelectedBatch(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <Layers className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Batches PRO</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              COHORT ROSTER
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Section capacities, occupancy monitoring, faculty assignments, and timing allocations.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print All
          </button>
          <button
            type="button"
            onClick={() => {
              setIsEditMode(false);
              resetForm();
              setIsAddModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add New
          </button>
        </div>
      </div>

      {/* 5 KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Total Batches</div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">{totalBatches}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-emerald-600 uppercase">Active Running</div>
          <div className="text-2xl font-black text-emerald-600 font-mono mt-1">{activeCount}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-blue-500 uppercase">Upcoming Intake</div>
          <div className="text-2xl font-black text-blue-600 font-mono mt-1">{upcomingCount}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-indigo-500 uppercase">Enrolled / Cap</div>
          <div className="text-xl md:text-2xl font-black text-indigo-600 font-mono mt-1">
            {totalEnrolled} / {totalCapacity}
          </div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-purple-500 uppercase">Occupancy Rate</div>
          <div className="text-2xl font-black text-purple-600 font-mono mt-1">
            {overallOccupancy}%
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search batches by cohort name, faculty, or room..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
            Status:
          </span>
          {['All', 'Active', 'Upcoming', 'Completed', 'Cancelled'].map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                statusFilter === st
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Results Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => {
          const occ = Math.round((item.enrolled / item.capacity) * 100);
          // Color indicator as required by prompt: red if full, amber if 80%, emerald if available
          const occBadgeColor =
            occ >= 100
              ? 'bg-rose-100 text-rose-800 border-rose-300'
              : occ >= 80
              ? 'bg-amber-100 text-amber-800 border-amber-300'
              : 'bg-emerald-100 text-emerald-800 border-emerald-300';

          return (
            <div
              key={item.id}
              onClick={() => setSelectedBatch(item)}
              className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-0.5 text-xs font-bold rounded-lg bg-indigo-50 text-indigo-700">
                    {item.course}
                  </span>
                  <span
                    className={`px-2.5 py-0.5 text-[10px] font-black rounded-full uppercase ${
                      item.status === 'Active'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {item.status}
                  </span>
                </div>

                <h3 className="mt-2 text-base font-black text-slate-900">{item.batchName}</h3>

                <div className="mt-3 space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center gap-1.5 font-medium">
                    <User className="w-3.5 h-3.5 text-indigo-600" />
                    <span>{item.teacher}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <DoorOpen className="w-3.5 h-3.5 text-slate-400" />
                    <span>{item.room}</span>
                  </div>
                  <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-500">
                    <Clock className="w-3.5 h-3.5 text-amber-500" />
                    <span>{item.timing}</span>
                  </div>
                </div>

                {/* Occupancy bar */}
                <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-semibold text-slate-500">Occupancy</span>
                    <span className={`px-2 py-0.2 rounded-full text-[10px] font-black border ${occBadgeColor}`}>
                      {item.enrolled} / {item.capacity} ({occ}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 ${
                        occ >= 100 ? 'bg-rose-500' : occ >= 80 ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, occ)}%` }}
                    />
                  </div>
                  <div className="mt-2 text-[11px] font-bold text-slate-700 flex justify-between">
                    <span>Fee: {item.feeStructure}</span>
                    <span className="text-slate-400 font-normal">
                      {item.capacity - item.enrolled} seats left
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                <span className="text-[11px] text-slate-400 font-mono">
                  {item.startDate} to {item.endDate}
                </span>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={(e) => handlePlusOneEnroll(item, e)}
                    className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-black rounded-lg text-[10px] flex items-center gap-1 cursor-pointer transition-colors"
                    title="+1 Quick Enroll Student"
                  >
                    <UserPlus className="w-3 h-3" />
                    +1 Enroll
                  </button>
                  <button
                    type="button"
                    onClick={(e) => handleOpenEdit(item, e)}
                    className="p-1 text-slate-400 hover:text-indigo-600 rounded cursor-pointer"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={(e) => handleDelete(item.id, e)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ADD / EDIT MODAL (12 fields) */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title={isEditMode ? 'Edit Batch Cohort' : 'Add New Academic Batch'}
        subtitle="Configure schedule, instructor assignment, and capacity quotas"
        badge="12 FIELDS"
        maxWidth="max-w-4xl"
      >
        <form onSubmit={handleSaveBatch} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Batch Name *
              </label>
              <input
                type="text"
                required
                value={batchName}
                onChange={(e) => setBatchName(e.target.value)}
                placeholder="e.g. Batch 2026-D (Morning)"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Course Program *
              </label>
              <select
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                {state.courses.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Lead Teacher / Faculty *
              </label>
              <input
                type="text"
                required
                value={teacher}
                onChange={(e) => setTeacher(e.target.value)}
                placeholder="Teacher name"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Assigned Classroom / Lab
              </label>
              <input
                type="text"
                value={room}
                onChange={(e) => setRoom(e.target.value)}
                placeholder="e.g. Room 101 or Lab 02"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Student Capacity *
              </label>
              <input
                type="number"
                required
                min={1}
                value={capacity}
                onChange={(e) => setCapacity(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-mono font-bold outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Initial Enrolled
              </label>
              <input
                type="number"
                min={0}
                value={enrolled}
                onChange={(e) => setEnrolled(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-mono font-bold outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Class Timing *
              </label>
              <input
                type="text"
                required
                value={timing}
                onChange={(e) => setTiming(e.target.value)}
                placeholder="08:00 AM - 01:00 PM"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as Batch['status'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Active">Active</option>
                <option value="Upcoming">Upcoming</option>
                <option value="Completed">Completed</option>
                <option value="Cancelled">Cancelled</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Start Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">End Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Monthly Fee Structure
              </label>
              <input
                type="text"
                value={feeStructure}
                onChange={(e) => setFeeStructure(e.target.value)}
                placeholder="PKR 4,500/Month"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Remarks & Curriculum Pacing
              </label>
              <input
                type="text"
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="Cohort notes..."
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              {isEditMode ? 'Update Batch' : 'Save Batch'}
            </button>
          </div>
        </form>
      </Modal>

      {/* DETAIL MODAL + Single Print */}
      {selectedBatch && (
        <Modal
          isOpen={Boolean(selectedBatch)}
          onClose={() => setSelectedBatch(null)}
          title={`Batch Cohort: ${selectedBatch.batchName}`}
          subtitle={`${selectedBatch.course} • Lead Instructor: ${selectedBatch.teacher}`}
          badge={selectedBatch.status}
        >
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-slate-400 block font-semibold">Classroom:</span>
                  <span className="font-bold text-slate-900">{selectedBatch.room}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Timing:</span>
                  <span className="font-mono text-slate-900 font-bold">{selectedBatch.timing}</span>
                </div>
              </div>

              <div className="p-3 bg-white rounded-xl border border-slate-200">
                <div className="flex items-center justify-between font-bold mb-1">
                  <span>Enrolled Capacity</span>
                  <span className="text-indigo-600">
                    {selectedBatch.enrolled} / {selectedBatch.capacity} Students (
                    {Math.round((selectedBatch.enrolled / selectedBatch.capacity) * 100)}%)
                  </span>
                </div>
                <div className="text-slate-500 text-[11px]">
                  Fee Structure: {selectedBatch.feeStructure}
                </div>
              </div>

              <div>
                <span className="text-slate-400 block font-semibold">Remarks:</span>
                <p className="text-slate-800 italic">{selectedBatch.remarks}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <button
                type="button"
                onClick={() => triggerBrowserPrint()}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <Printer className="w-4 h-4" />
                Print Batch Roster
              </button>
              <button
                type="button"
                onClick={() => setSelectedBatch(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Batches & Capacities Roster (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('batches-print-table', 'TaleemOS_Batches_Capacity')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="batches-print-table">
              <LetterheadPrint
                title="Academic Batches & Classroom Allocation Ledger"
                documentNo="BATCH-LEDGER-2026"
                summaryStats={[
                  { label: 'Total Batches', value: totalBatches },
                  { label: 'Active Cohorts', value: activeCount },
                  { label: 'Seats Filled', value: `${totalEnrolled} / ${totalCapacity}` },
                  { label: 'Avg Occupancy', value: `${overallOccupancy}%` },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Batch Name</th>
                      <th className="border border-slate-300 p-2">Course</th>
                      <th className="border border-slate-300 p-2">Faculty Lead</th>
                      <th className="border border-slate-300 p-2">Room</th>
                      <th className="border border-slate-300 p-2">Timing</th>
                      <th className="border border-slate-300 p-2">Enrolled / Cap</th>
                      <th className="border border-slate-300 p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((b) => (
                      <tr key={b.id}>
                        <td className="border border-slate-300 p-2 font-bold">{b.batchName}</td>
                        <td className="border border-slate-300 p-2">{b.course}</td>
                        <td className="border border-slate-300 p-2">{b.teacher}</td>
                        <td className="border border-slate-300 p-2">{b.room}</td>
                        <td className="border border-slate-300 p-2 font-mono">{b.timing}</td>
                        <td className="border border-slate-300 p-2 font-mono font-bold">
                          {b.enrolled} / {b.capacity}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold">{b.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BatchesModule;
