import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Building2,
  Users,
  CheckCircle2,
  XCircle,
  Plus,
  Search,
  ArrowRight,
  TrendingUp,
  MapPin,
  Phone,
  Mail,
  UserCheck,
  Clock,
  ExternalLink,
  RefreshCw,
} from 'lucide-react';
import { erpStorage } from '../lib/storage';
import {
  fetchActiveAcademies,
  createAcademy,
  getPendingAdmins,
  setUserApprovalStatus,
  getLocalUsers,
} from '../lib/academyService';
import { type Academy, type AppUser } from '../types';
import { Modal } from '../components/common/Modal';

interface DeveloperModuleProps {
  onNavigate?: (path: string) => void;
  onSelectAcademy?: (academyId: string) => void;
}

export const DeveloperModule: React.FC<DeveloperModuleProps> = ({
  onNavigate,
  onSelectAcademy,
}) => {
  const [academies, setAcademies] = useState<Academy[]>([]);
  const [pendingAdmins, setPendingAdmins] = useState<AppUser[]>([]);
  const [allUsers, setAllUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'academies' | 'pending' | 'users'>('academies');
  const [search, setSearch] = useState('');

  // New Academy Modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newAcademyName, setNewAcademyName] = useState('');
  const [newAcademyCode, setNewAcademyCode] = useState('');
  const [newAcademyAddress, setNewAcademyAddress] = useState('');
  const [newAcademyPhone, setNewAcademyPhone] = useState('');
  const [assignedAdminEmail, setAssignedAdminEmail] = useState('');

  const [toast, setToast] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const [acadList, adminsList] = await Promise.all([
        fetchActiveAcademies(),
        getPendingAdmins(),
      ]);
      setAcademies(acadList);
      setPendingAdmins(adminsList);
      setAllUsers(getLocalUsers());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleCreateAcademy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAcademyName.trim() || !newAcademyCode.trim()) return;

    const newAcad = await createAcademy(
      {
        academyId: `acad-${Date.now().toString().slice(-4)}`,
        academyName: newAcademyName.trim(),
        code: newAcademyCode.trim().toUpperCase(),
        address: newAcademyAddress.trim() || 'Sindh, Pakistan',
        phone: newAcademyPhone.trim() || '0300-0000000',
        adminEmail: assignedAdminEmail.trim() || undefined,
        createdBy: 'developer@hisaabkitaab.com',
      },
      'developer@hisaabkitaab.com'
    );

    setIsCreateModalOpen(false);
    setNewAcademyName('');
    setNewAcademyCode('');
    setNewAcademyAddress('');
    setNewAcademyPhone('');
    setAssignedAdminEmail('');
    showToast(`✅ Created new Academy: ${newAcad.academyName} (${newAcad.code})`);
    loadData();
  };

  const handleApproveAdmin = async (adminUser: AppUser, allottedAcadId?: string) => {
    const targetAcademy = allottedAcadId || adminUser.academyId || academies[0]?.academyId;
    await setUserApprovalStatus(adminUser.uid, 'approved', targetAcademy || undefined);
    showToast(`🎉 Approved Admin: ${adminUser.name} (${adminUser.email})`);
    loadData();
  };

  const handleRejectAdmin = async (adminUser: AppUser) => {
    await setUserApprovalStatus(adminUser.uid, 'rejected');
    showToast(`❌ Rejected Admin registration: ${adminUser.email}`);
    loadData();
  };

  const state = erpStorage.getState();

  const filteredAcademies = academies.filter(
    (a) =>
      a.academyName.toLowerCase().includes(search.toLowerCase()) ||
      a.code.toLowerCase().includes(search.toLowerCase()) ||
      a.address.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 text-xs font-bold animate-fade-in">
          <span>{toast}</span>
        </div>
      )}

      {/* Developer Master Header */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 p-6 md:p-8 text-white shadow-xl border border-indigo-900/50 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-indigo-500/10 to-transparent pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Super Super Admin • Developer Authority
              </span>
              <span className="text-xs text-slate-400">developer@hisaabkitaab.com</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Developer Central Control & Multi-Academy Hub
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Create and allot academies, review & approve new academy administrators, and monitor global multi-tenant institutional operations.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center gap-2 shadow-lg shadow-indigo-950/40 transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create / Allot New Academy</span>
            </button>
            <button
              onClick={loadData}
              title="Refresh Network Data"
              className="w-10 h-10 bg-white/10 hover:bg-white/20 text-white rounded-xl flex items-center justify-center transition border border-white/10 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Global Network Counters */}
        <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Total Academies</span>
            <span className="text-2xl font-black text-indigo-300 font-mono mt-1 block">
              {academies.length} Branches
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Pending Admin Approvals</span>
            <span className={`text-2xl font-black font-mono mt-1 block ${pendingAdmins.length > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {pendingAdmins.length} Requests
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Network Students</span>
            <span className="text-2xl font-black text-emerald-300 font-mono mt-1 block">
              {state.students.length.toLocaleString()}
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Network ERP Modules</span>
            <span className="text-2xl font-black text-sky-300 font-mono mt-1 block">
              29 Modules
            </span>
          </div>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="bg-white rounded-2xl border p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold w-fit">
          <button
            onClick={() => setActiveTab('academies')}
            className={`px-4 py-2 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'academies' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>All Academies ({academies.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('pending')}
            className={`px-4 py-2 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'pending' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Pending Admins</span>
            {pendingAdmins.length > 0 && (
              <span className="px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px]">
                {pendingAdmins.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'users' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Registered Users</span>
          </button>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search academy or code..."
            className="pl-8 pr-3 py-1.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 w-full sm:w-56"
          />
        </div>
      </div>

      {/* Tab 1: All Academies List */}
      {activeTab === 'academies' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAcademies.map((acad) => (
            <div
              key={acad.academyId}
              className="bg-white rounded-3xl border p-5 shadow-sm hover:shadow-md transition flex flex-col justify-between group border-slate-200"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-mono text-xs font-black bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-lg border border-indigo-100">
                    {acad.code}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Active Branch
                  </span>
                </div>

                <h3 className="font-black text-base text-slate-900 group-hover:text-indigo-600 transition">
                  {acad.academyName}
                </h3>

                <div className="mt-3 space-y-1.5 text-xs text-slate-500">
                  <p className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{acad.address}</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{acad.phone}</span>
                  </p>
                  {acad.adminEmail && (
                    <p className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-medium text-slate-700">{acad.adminEmail}</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-slate-400">ID: {acad.academyId}</span>
                <button
                  onClick={() => {
                    erpStorage.setActiveInstitution(acad.academyId);
                    onSelectAcademy?.(acad.academyId);
                    showToast(`Switched active view to ${acad.academyName}`);
                  }}
                  className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                >
                  <span>Enter Academy</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Pending Admin Approvals (Developer Role only) */}
      {activeTab === 'pending' && (
        <div className="bg-white rounded-3xl border shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-black text-base text-slate-900">
                Pending Admin Registrations Awaiting Developer Approval
              </h3>
              <p className="text-xs text-slate-500">
                Admins cannot access institution databases or approve teachers until authorized by Developer.
              </p>
            </div>
            <span className="text-xs font-mono font-bold bg-amber-50 text-amber-700 border border-amber-200 px-3 py-1 rounded-full">
              {pendingAdmins.length} Awaiting
            </span>
          </div>

          {pendingAdmins.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <p className="font-bold text-sm text-slate-800">All Admin registrations are approved!</p>
              <p className="text-xs text-slate-400">New requests will automatically appear here for verification.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {pendingAdmins.map((admin) => (
                <div
                  key={admin.uid}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm text-slate-900">{admin.name}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700">
                        Admin Applicant
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Email: <b>{admin.email}</b> {admin.phone ? `• Phone: ${admin.phone}` : ''}
                    </p>
                    <p className="text-xs text-indigo-600 font-medium mt-1">
                      Target Academy: {admin.academyName || 'New Academy Proposed'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleRejectAdmin(admin)}
                      className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold border border-rose-200 transition cursor-pointer"
                    >
                      Reject
                    </button>
                    <button
                      onClick={() => handleApproveAdmin(admin)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-900/30 transition cursor-pointer"
                    >
                      Authorize & Approve Admin
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Registered Users Directory */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-3xl border shadow-sm p-6 space-y-4">
          <h3 className="font-black text-base text-slate-900">
            Network User Directory (All Roles)
          </h3>
          <div className="divide-y divide-slate-100">
            {allUsers.map((u) => (
              <div key={u.uid} className="py-3 flex items-center justify-between text-xs">
                <div>
                  <p className="font-bold text-slate-900">{u.name}</p>
                  <p className="text-slate-500">
                    {u.email} • {u.academyName}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                    {u.role}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      u.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : u.status === 'pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {u.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal: Create / Allot New Academy */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create & Allot New Academy (Developer Only)"
      >
        <form onSubmit={handleCreateAcademy} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Academy Name *</label>
            <input
              type="text"
              required
              value={newAcademyName}
              onChange={(e) => setNewAcademyName(e.target.value)}
              placeholder="e.g. Taleem Academy Larkana Campus"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Branch Code *</label>
              <input
                type="text"
                required
                value={newAcademyCode}
                onChange={(e) => setNewAcademyCode(e.target.value)}
                placeholder="e.g. TAL-04"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-mono uppercase font-bold"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Official Contact Phone</label>
              <input
                type="text"
                value={newAcademyPhone}
                onChange={(e) => setNewAcademyPhone(e.target.value)}
                placeholder="0300-1234567"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Campus Physical Address</label>
            <input
              type="text"
              value={newAcademyAddress}
              onChange={(e) => setNewAcademyAddress(e.target.value)}
              placeholder="City, District, Province"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Allot to Admin Email (Optional)</label>
            <input
              type="email"
              value={assignedAdminEmail}
              onChange={(e) => setAssignedAdminEmail(e.target.value)}
              placeholder="admin@academy.edu.pk"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black shadow-md shadow-indigo-900/30"
            >
              Confirm & Allot Academy
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default DeveloperModule;
