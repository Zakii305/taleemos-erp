import React, { useState } from 'react';
import { GraduationCap, Plus, Printer, Download, Search, Mail, Phone, BookOpen, Layers, Clock, Trash2 } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type Teacher } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const TeachersModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [selectedTeacher, setSelectedTeacher] = useState<Teacher | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);

  // Form fields
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [qualification, setQualification] = useState('M.Sc Physics');
  const [specialization, setSpecialization] = useState('Physics');
  const [department, setDepartment] = useState('Faculty of Science');
  const [assignedBatch, setAssignedBatch] = useState('Batch 2026-A (Morning)');

  const filtered = state.teachers.filter(
    (t) =>
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.department.toLowerCase().includes(search.toLowerCase()) ||
      t.specialization.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreateTeacher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newTeacher: Teacher = {
      id: `TCH-0${state.teachers.length + 1}`,
      name,
      email: email || `${name.toLowerCase().replace(/\s+/g, '.')}@taleemacademy.edu.pk`,
      phone: phone || '+92 300 0000000',
      qualification,
      specialization,
      department,
      assignedBatches: [assignedBatch],
      assignedSubjects: [specialization],
      joiningDate: new Date().toISOString().split('T')[0],
      status: 'Active',
      photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
    };

    erpStorage.addItem('teachers', newTeacher);
    setIsAddModalOpen(false);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this faculty member profile?')) {
      erpStorage.deleteItem('teachers', id);
      if (selectedTeacher?.id === id) setSelectedTeacher(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <GraduationCap className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Faculty & Teacher Zone PRO</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              FACULTY DOSSIER
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Instructor credentials, subject specializations, individual timetable grids, and workload allocations.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Faculty Roster
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Faculty Member
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search faculty by name, department, or qualification..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none"
          />
        </div>
      </div>

      {/* Faculty Cards (Tappable to teacher detail + timetable) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedTeacher(item)}
            className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="px-2.5 py-0.5 text-xs font-bold bg-indigo-50 text-indigo-700 rounded-lg">
                  {item.department}
                </span>
                <span className="px-2 py-0.2 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800">
                  {item.status}
                </span>
              </div>

              <div className="mt-3 flex items-start gap-3">
                <img
                  src={item.photoUrl}
                  alt={item.name}
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-indigo-200 shrink-0"
                />
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">{item.name}</h3>
                  <p className="text-xs text-slate-500 font-semibold">{item.qualification}</p>
                  <p className="text-[11px] text-indigo-700 font-mono mt-0.5">{item.specialization}</p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
                <div className="flex items-center gap-1.5">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span className="truncate">{item.email}</span>
                </div>
                <div className="flex items-center gap-1.5 font-mono">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span>{item.phone}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-indigo-500" />
                  <span className="font-semibold text-slate-800">
                    Batches: {item.assignedBatches.join(', ')}
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
              <span className="text-[10px] text-indigo-600 font-bold">Tap to view Timetable &rarr;</span>
              <button
                type="button"
                onClick={(e) => handleDelete(item.id, e)}
                className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ADD FACULTY MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Register Faculty Member"
        subtitle="Establish teacher credentials and subject assignments"
        badge="FACULTY PROFILE"
      >
        <form onSubmit={handleCreateTeacher} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Teacher Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Prof. / Dr. Full Name"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Highest Qualification
              </label>
              <input
                type="text"
                value={qualification}
                onChange={(e) => setQualification(e.target.value)}
                placeholder="M.Phil / Ph.D / M.Sc"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="teacher@taleemacademy.edu.pk"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Phone</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+92 300 0000000"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Specialization</label>
              <input
                type="text"
                value={specialization}
                onChange={(e) => setSpecialization(e.target.value)}
                placeholder="e.g. Modern Physics"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Department</label>
              <input
                type="text"
                value={department}
                onChange={(e) => setDepartment(e.target.value)}
                placeholder="Faculty of Science"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Assigned Batch</label>
              <select
                value={assignedBatch}
                onChange={(e) => setAssignedBatch(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                {state.batches.map((b) => (
                  <option key={b.id} value={b.batchName}>
                    {b.batchName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Add Faculty Profile
            </button>
          </div>
        </form>
      </Modal>

      {/* DETAIL MODAL + TEACHER TIMETABLE VIEW */}
      {selectedTeacher && (
        <Modal
          isOpen={Boolean(selectedTeacher)}
          onClose={() => setSelectedTeacher(null)}
          title={`Faculty Dossier: ${selectedTeacher.name}`}
          subtitle={`${selectedTeacher.qualification} • ${selectedTeacher.department}`}
          badge={selectedTeacher.status}
          maxWidth="max-w-4xl"
        >
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center gap-4">
              <img
                src={selectedTeacher.photoUrl}
                alt={selectedTeacher.name}
                className="w-16 h-16 rounded-2xl object-cover border-2 border-indigo-600 shadow"
              />
              <div>
                <h4 className="text-base font-black text-slate-900">{selectedTeacher.name}</h4>
                <div className="text-xs text-slate-600">
                  {selectedTeacher.email} &bull; {selectedTeacher.phone}
                </div>
                <div className="text-xs text-indigo-700 font-bold mt-0.5">
                  Assigned Cohorts: {selectedTeacher.assignedBatches.join(', ')}
                </div>
              </div>
            </div>

            {/* Individual Timetable Grid for this teacher */}
            <div>
              <h5 className="font-bold text-xs uppercase tracking-wider text-slate-700 mb-2 flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-indigo-600" />
                Assigned Weekly Teaching Schedule
              </h5>
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 font-bold">
                    <tr>
                      <th className="p-2.5">Cohort Batch</th>
                      <th className="p-2.5">Day</th>
                      <th className="p-2.5">Period & Timing</th>
                      <th className="p-2.5">Subject</th>
                      <th className="p-2.5">Room</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.timetables.filter((t) => t.teacher === selectedTeacher.name).length === 0 ? (
                      <tr>
                        <td colSpan={5} className="p-4 text-center text-slate-400">
                          No timetable slots assigned yet. Use Timetable GRID module to allocate periods.
                        </td>
                      </tr>
                    ) : (
                      state.timetables
                        .filter((t) => t.teacher === selectedTeacher.name)
                        .map((slot) => (
                          <tr key={slot.id} className="border-t border-slate-100">
                            <td className="p-2.5 font-bold">{slot.batch}</td>
                            <td className="p-2.5 font-semibold text-indigo-700">{slot.day}</td>
                            <td className="p-2.5 font-mono">
                              Period {slot.period} ({slot.timing})
                            </td>
                            <td className="p-2.5 font-bold text-slate-900">{slot.subject}</td>
                            <td className="p-2.5 font-mono">{slot.room}</td>
                          </tr>
                        ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setSelectedTeacher(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Institutional Faculty Directory (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('teachers-print-table', 'TaleemOS_Faculty_Roster')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="teachers-print-table">
              <LetterheadPrint
                title="INSTITUTIONAL TEACHING FACULTY & DEANS ROSTER"
                documentNo="FACULTY-ROSTER-2026"
                summaryStats={[
                  { label: 'Total Faculty', value: state.teachers.length },
                  { label: 'Active Teachers', value: state.teachers.filter((t) => t.status === 'Active').length },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Staff ID</th>
                      <th className="border border-slate-300 p-2">Faculty Name</th>
                      <th className="border border-slate-300 p-2">Qualification</th>
                      <th className="border border-slate-300 p-2">Specialization</th>
                      <th className="border border-slate-300 p-2">Department</th>
                      <th className="border border-slate-300 p-2">Phone</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((t) => (
                      <tr key={t.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-indigo-700">{t.id}</td>
                        <td className="border border-slate-300 p-2 font-bold">{t.name}</td>
                        <td className="border border-slate-300 p-2">{t.qualification}</td>
                        <td className="border border-slate-300 p-2">{t.specialization}</td>
                        <td className="border border-slate-300 p-2">{t.department}</td>
                        <td className="border border-slate-300 p-2 font-mono">{t.phone}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TeachersModule;
