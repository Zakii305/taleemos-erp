import React, { useState } from 'react';
import { Wallet, TrendingUp, TrendingDown, Search, Plus, X, DollarSign, Calendar, FileText } from 'lucide-react';
type Entry = { id: string; date: string; head: string; type: 'Income' | 'Expense'; amount: number; method: string; desc: string; };
const ENTRIES: Entry[] = [
  { id:'ACC-001', date:'2026-01-15', head:'Tuition Fees Jan', type:'Income', amount:720000, method:'Bank', desc:'Monthly fees collection' },
  { id:'ACC-002', date:'2026-01-16', head:'Staff Salaries', type:'Expense', amount:320000, method:'Bank Transfer', desc:'Jan salaries' },
  { id:'ACC-003', date:'2026-01-18', head:'Library Books', type:'Expense', amount:45000, method:'Cash', desc:'New books purchase' },
];
export default function AccountsModule(){
  const [entries, setEntries] = useState(ENTRIES);
  const [showNew, setShowNew] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ head:'', type:'Income' as 'Income'|'Expense', amount:'', method:'Bank', desc:'' });
  const totalIncome = entries.filter(e=>e.type==='Income').reduce((a,b)=>a+b.amount,0);
  const totalExpense = entries.filter(e=>e.type==='Expense').reduce((a,b)=>a+b.amount,0);
  const balance = totalIncome - totalExpense;
  const filtered = entries.filter(e=> e.head.toLowerCase().includes(search.toLowerCase()) || e.id.toLowerCase().includes(search.toLowerCase()));
  const handleCreate = () => { if(!form.head || !form.amount) return; const n: Entry = { id:`ACC-${String(entries.length+1).padStart(3,'0')}`, date:new Date().toISOString().split('T')[0], head:form.head, type:form.type, amount:Number(form.amount), method:form.method, desc:form.desc }; setEntries([n, ...entries]); setShowNew(false); setForm({ head:'', type:'Income', amount:'', method:'Bank', desc:'' }); };
  return (
    <div className="space-y-4">
      <div className="rounded-[20px] bg-black p-5 text-white"><div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center"><Wallet className="w-5 h-5"/></div><div><h1 className="text-[16px] font-black">Accounts • Ledger & Audit</h1><p className="text-[11px] text-zinc-400">Income vs Expense • Balance Sheet</p></div></div></div>
      <div className="grid grid-cols-3 gap-3"><div className="bg-emerald-50 border border-emerald-200 rounded-[16px] p-4 text-center"><p className="text-[10px] font-black uppercase text-emerald-600">Total Income</p><p className="text-[18px] font-black text-emerald-700 mt-1">PKR {totalIncome.toLocaleString()}</p></div><div className="bg-rose-50 border border-rose-200 rounded-[16px] p-4 text-center"><p className="text-[10px] font-black uppercase text-rose-600">Total Expense</p><p className="text-[18px] font-black text-rose-700 mt-1">PKR {totalExpense.toLocaleString()}</p></div><div className="bg-slate-900 rounded-[16px] p-4 text-center text-white"><p className="text-[10px] font-black uppercase text-zinc-400">Net Balance</p><p className="text-[18px] font-black mt-1">PKR {balance.toLocaleString()}</p></div></div>
      <div className="bg-white rounded-[18px] border p-3 flex gap-2"><div className="relative flex-1"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search head, ID..." className="w-full pl-10 pr-4 py-2.5 border rounded-full text-xs outline-none"/></div><button onClick={()=>setShowNew(true)} className="px-4 py-2 bg-black text-white rounded-full text-xs font-black flex items-center gap-1"><Plus className="w-4 h-4"/>Add Entry</button></div>
      <div className="space-y-2">{filtered.map(e=><div key={e.id} className="bg-white rounded-[16px] border p-4 flex items-center justify-between"><div className="flex items-center gap-3"><div className={`w-10 h-10 rounded-xl flex items-center justify-center ${e.type==='Income'?'bg-emerald-100 text-emerald-700':'bg-rose-100 text-rose-700'}`}>{e.type==='Income'?<TrendingUp className="w-5 h-5"/>:<TrendingDown className="w-5 h-5"/>}</div><div><p className="font-bold text-[13px]">{e.head} <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.5 rounded ml-1">{e.id}</span></p><p className="text-[11px] text-slate-500">{e.date} • {e.method} • {e.desc}</p></div></div><p className={`font-black text-[14px] ${e.type==='Income'?'text-emerald-600':'text-rose-600'}`}>{e.type==='Income'?'+':'-'} PKR {e.amount.toLocaleString()}</p></div>)}</div>
      {showNew && <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setShowNew(false)} className="absolute inset-0 bg-black/50"/><div className="relative bg-white rounded-[22px] w-full max-w-[460px] p-5"><div className="flex justify-between mb-4"><h3 className="font-black">Add Ledger Entry</h3><button onClick={()=>setShowNew(false)} className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center"><X className="w-4 h-4"/></button></div><div className="space-y-3"><input value={form.head} onChange={e=>setForm({...form, head:e.target.value})} placeholder="Head e.g., Tuition Fees" className="w-full px-3 py-2.5 border rounded-xl text-xs"/><div className="grid grid-cols-2 gap-2"><select value={form.type} onChange={e=>setForm({...form, type:e.target.value as any})} className="px-3 py-2.5 border rounded-xl text-xs"><option>Income</option><option>Expense</option></select><input value={form.amount} onChange={e=>setForm({...form, amount:e.target.value})} placeholder="Amount PKR" type="number" className="px-3 py-2.5 border rounded-xl text-xs"/></div><input value={form.desc} onChange={e=>setForm({...form, desc:e.target.value})} placeholder="Description" className="w-full px-3 py-2.5 border rounded-xl text-xs"/><button onClick={handleCreate} className="w-full py-2.5 bg-black text-white rounded-full text-xs font-black">Save Entry</button></div></div></div>}
    </div>
  );
}

export { AccountsModule };
