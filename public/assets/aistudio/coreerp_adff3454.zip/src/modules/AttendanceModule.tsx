import React, { useState } from 'react';
import { UserCheck, Printer, Download, Calendar, MessageSquare, Send, CheckCircle2, XCircle, Clock } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type AttendanceRecord } from '../types';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const AttendanceModule: React.FC = () => {
  const state = erpStorage.getState();
  const [selectedBatch, setSelectedBatch] = useState(state.batches[0]?.batchName || 'Batch 2026-A (Morning)');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);
  const [smsSentNotice, setSmsSentNotice] = useState<string | null>(null);

  // Filter students belonging to this batch
  const batchStudents = state.students.filter((s) => s.classBatch === selectedBatch);

  // Status map
  const getStatus = (studentId: string): 'P' | 'A' | 'L' => {
    const rec = state.attendance.find(
      (a) => a.studentId === studentId && a.date === selectedDate && a.batch === selectedBatch
    );
    return rec ? rec.status : 'P';
  };

  const handleSetStatus = (student: (typeof batchStudents)[0], status: 'P' | 'A' | 'L') => {
    const existing = state.attendance.find(
      (a) => a.studentId === student.id && a.date === selectedDate && a.batch === selectedBatch
    );

    if (existing) {
      erpStorage.updateItem('attendance', existing.id, { status });
    } else {
      const newRec: AttendanceRecord = {
        id: `ATT-${Date.now().toString().slice(-4)}`,
        date: selectedDate,
        batch: selectedBatch,
        studentId: student.id,
        studentName: student.name,
        rollNo: student.rollNo,
        status,
      };
      erpStorage.addItem('attendance', newRec);
    }
  };

  const markAll = (status: 'P' | 'A') => {
    batchStudents.forEach((student) => {
      handleSetStatus(student, status);
    });
  };

  // Stats for this batch & date
  const presentCount = batchStudents.filter((s) => getStatus(s.id) === 'P').length;
  const absentCount = batchStudents.filter((s) => getStatus(s.id) === 'A').length;
  const lateCount = batchStudents.filter((s) => getStatus(s.id) === 'L').length;
  const attendanceRate = batchStudents.length > 0 ? Math.round((presentCount / batchStudents.length) * 100) : 0;

  // SMS to Absent Parents action
  const handleSendSmsToAbsents = () => {
    const absents = batchStudents.filter((s) => getStatus(s.id) === 'A');
    if (absents.length === 0) {
      alert('No students marked absent for this batch today.');
      return;
    }

    setSmsSentNotice(`Dispatched absence SMS notification to parents of ${absents.length} students via Gateway.`);
    setTimeout(() => setSmsSentNotice(null), 4000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <UserCheck className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Student Daily Attendance</h1>
            <span className="px-2 py-0.5 bg-emerald-500 text-white font-black text-[10px] rounded uppercase">
              BIOMETRIC & MANUAL
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Batch-wise attendance marking, percentage analytics, and instant automated SMS alerts to absent parents.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Daily Sheet
          </button>
          <button
            type="button"
            onClick={handleSendSmsToAbsents}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            SMS Absent Parents
          </button>
        </div>
      </div>

      {smsSentNotice && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl animate-in fade-in flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{smsSentNotice}</span>
        </div>
      )}

      {/* Date & Batch Filter Bar */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500 uppercase">Batch:</span>
            <select
              value={selectedBatch}
              onChange={(e) => setSelectedBatch(e.target.value)}
              className="px-3.5 py-1.5 bg-indigo-50 border border-indigo-200 rounded-xl text-xs font-bold text-indigo-900 outline-none"
            >
              {state.batches.map((b) => (
                <option key={b.id} value={b.batchName}>
                  {b.batchName} ({b.enrolled} Students)
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-500 uppercase">Date:</span>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => markAll('P')}
            className="px-3 py-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 rounded-xl text-xs font-bold cursor-pointer"
          >
            Mark All Present
          </button>
          <button
            type="button"
            onClick={() => markAll('A')}
            className="px-3 py-1.5 bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 rounded-xl text-xs font-bold cursor-pointer"
          >
            Mark All Absent
          </button>
        </div>
      </div>

      {/* KPIs for Selected Day */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Total in Batch</div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">{batchStudents.length}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-emerald-600 uppercase">Present (P)</div>
          <div className="text-2xl font-black text-emerald-600 font-mono mt-1">{presentCount}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-rose-600 uppercase">Absent (A)</div>
          <div className="text-2xl font-black text-rose-600 font-mono mt-1">{absentCount}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-indigo-600 uppercase">Daily Ratio %</div>
          <div className="text-2xl font-black text-indigo-600 font-mono mt-1">{attendanceRate}%</div>
        </div>
      </div>

      {/* Attendance Roster Table */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm overflow-x-auto">
        {batchStudents.length === 0 ? (
          <div className="py-12 text-center text-slate-400">
            <p className="text-sm font-semibold">No students enrolled in {selectedBatch}</p>
            <p className="text-xs text-slate-400 mt-1">Assign students in Students Directory module</p>
          </div>
        ) : (
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Roll No</th>
                <th className="p-3">Photo</th>
                <th className="p-3">Student Name</th>
                <th className="p-3">Father Name</th>
                <th className="p-3">Parent Phone</th>
                <th className="p-3 text-center">Take Attendance (P / A / L)</th>
              </tr>
            </thead>
            <tbody>
              {batchStudents.map((s) => {
                const status = getStatus(s.id);
                return (
                  <tr key={s.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition-colors">
                    <td className="p-3 font-mono font-bold text-indigo-700">{s.rollNo}</td>
                    <td className="p-3">
                      <img src={s.photoUrl} alt={s.name} className="w-8 h-8 rounded-lg object-cover border" />
                    </td>
                    <td className="p-3 font-bold text-slate-900">{s.name}</td>
                    <td className="p-3 text-slate-600">{s.fatherName}</td>
                    <td className="p-3 font-mono text-slate-500">{s.phone}</td>
                    <td className="p-3 text-center">
                      <div className="inline-flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
                        <button
                          type="button"
                          onClick={() => handleSetStatus(s, 'P')}
                          className={`px-3 py-1 rounded-lg font-bold text-xs cursor-pointer transition-all ${
                            status === 'P'
                              ? 'bg-emerald-600 text-white shadow'
                              : 'text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          P
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSetStatus(s, 'A')}
                          className={`px-3 py-1 rounded-lg font-bold text-xs cursor-pointer transition-all ${
                            status === 'A'
                              ? 'bg-rose-600 text-white shadow'
                              : 'text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          A
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSetStatus(s, 'L')}
                          className={`px-3 py-1 rounded-lg font-bold text-xs cursor-pointer transition-all ${
                            status === 'L'
                              ? 'bg-amber-500 text-white shadow'
                              : 'text-slate-600 hover:bg-slate-200'
                          }`}
                        >
                          L
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* PRINT DAILY ATTENDANCE SHEET */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Daily Attendance Roll Sheet (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('attendance-print-table', `Attendance_${selectedBatch}_${selectedDate}`)}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="attendance-print-table">
              <LetterheadPrint
                title={`DAILY STUDENT ATTENDANCE REGISTER: ${selectedBatch}`}
                documentNo={`ATT-${selectedDate}`}
                date={selectedDate}
                summaryStats={[
                  { label: 'Total Enrolled', value: batchStudents.length },
                  { label: 'Present', value: presentCount },
                  { label: 'Absent', value: absentCount },
                  { label: 'Daily Rate', value: `${attendanceRate}%` },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Roll No</th>
                      <th className="border border-slate-300 p-2">Student Name</th>
                      <th className="border border-slate-300 p-2">Father Name</th>
                      <th className="border border-slate-300 p-2">Parent Phone</th>
                      <th className="border border-slate-300 p-2 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {batchStudents.map((s) => {
                      const st = getStatus(s.id);
                      return (
                        <tr key={s.id}>
                          <td className="border border-slate-300 p-2 font-mono font-bold text-indigo-700">
                            {s.rollNo}
                          </td>
                          <td className="border border-slate-300 p-2 font-bold">{s.name}</td>
                          <td className="border border-slate-300 p-2">{s.fatherName}</td>
                          <td className="border border-slate-300 p-2 font-mono">{s.phone}</td>
                          <td className="border border-slate-300 p-2 text-center font-black">
                            <span
                              className={`px-2 py-0.5 rounded ${
                                st === 'P'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : st === 'A'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-amber-100 text-amber-800'
                              }`}
                            >
                              {st === 'P' ? 'PRESENT' : st === 'A' ? 'ABSENT' : 'LATE'}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceModule;
