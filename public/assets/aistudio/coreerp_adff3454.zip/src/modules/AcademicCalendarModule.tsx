import React, { useState, useMemo, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Search,
  Filter,
  Download,
  Printer,
  Clock,
  MapPin,
  Users,
  GraduationCap,
  CalendarDays,
  List,
  Grid,
  CheckCircle2,
  AlertTriangle,
  Move,
  X,
  Edit2,
  Trash2,
  Share2,
  FileText,
  Tag,
  Building2,
  Sparkles,
} from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type CalendarEvent, type CalendarEventType } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint } from '../lib/pdf';

interface AcademicCalendarModuleProps {
  onNavigate?: (path: string) => void;
}

const EVENT_TYPE_CONFIG: Record<
  CalendarEventType,
  {
    label: string;
    icon: string;
    badgeBg: string;
    badgeText: string;
    border: string;
    cardBg: string;
    pillBg: string;
  }
> = {
  Exam: {
    label: 'Exam',
    icon: '📝',
    badgeBg: 'bg-rose-50 text-rose-700 border-rose-200',
    badgeText: 'text-rose-700',
    border: 'border-rose-400',
    cardBg: 'bg-rose-50/70 border-rose-200',
    pillBg: 'bg-rose-600 text-white',
  },
  Holiday: {
    label: 'Holiday',
    icon: '🌴',
    badgeBg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    badgeText: 'text-emerald-700',
    border: 'border-emerald-400',
    cardBg: 'bg-emerald-50/70 border-emerald-200',
    pillBg: 'bg-emerald-600 text-white',
  },
  Event: {
    label: 'Event',
    icon: '🎪',
    badgeBg: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    badgeText: 'text-indigo-700',
    border: 'border-indigo-400',
    cardBg: 'bg-indigo-50/70 border-indigo-200',
    pillBg: 'bg-indigo-600 text-white',
  },
  Meeting: {
    label: 'Meeting / PTM',
    icon: '👥',
    badgeBg: 'bg-amber-50 text-amber-700 border-amber-200',
    badgeText: 'text-amber-700',
    border: 'border-amber-400',
    cardBg: 'bg-amber-50/70 border-amber-200',
    pillBg: 'bg-amber-600 text-white',
  },
  Sports: {
    label: 'Sports',
    icon: '🏅',
    badgeBg: 'bg-teal-50 text-teal-700 border-teal-200',
    badgeText: 'text-teal-700',
    border: 'border-teal-400',
    cardBg: 'bg-teal-50/70 border-teal-200',
    pillBg: 'bg-teal-600 text-white',
  },
  Ceremony: {
    label: 'Ceremony',
    icon: '🎓',
    badgeBg: 'bg-purple-50 text-purple-700 border-purple-200',
    badgeText: 'text-purple-700',
    border: 'border-purple-400',
    cardBg: 'bg-purple-50/70 border-purple-200',
    pillBg: 'bg-purple-600 text-white',
  },
};

const DAYS_OF_WEEK = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

export const AcademicCalendarModule: React.FC<AcademicCalendarModuleProps> = ({ onNavigate }) => {
  const state = erpStorage.getState();
  const rawEvents = state.calendarEvents || [];

  // Active view state
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'agenda'>('month');
  const [currentDate, setCurrentDate] = useState<Date>(new Date(2026, 9, 26)); // Oct 26, 2026 (current term)
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [search, setSearch] = useState<string>('');

  // Drag and drop state
  const [draggedEventId, setDraggedEventId] = useState<string | null>(null);
  const [dragOverDate, setDragOverDate] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);

  // New Event Form
  const [formTitle, setFormTitle] = useState('');
  const [formType, setFormType] = useState<CalendarEventType>('Exam');
  const [formDate, setFormDate] = useState('2026-10-28');
  const [formEndDate, setFormEndDate] = useState('');
  const [formStartTime, setFormStartTime] = useState('09:00');
  const [formEndTime, setFormEndTime] = useState('12:00');
  const [formLocation, setFormLocation] = useState('Exam Hall A');
  const [formAudience, setFormAudience] = useState<'All' | 'Students' | 'Faculty' | 'Parents' | 'Staff'>('Students');
  const [formClassBatch, setFormClassBatch] = useState('Batch 2026-A (Morning)');
  const [formDescription, setFormDescription] = useState('');
  const [formIsHoliday, setFormIsHoliday] = useState(false);

  // Toast message auto-hide
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 3500);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  // Year & Month for current view
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth();

  // Navigation handlers
  const handlePrev = () => {
    if (viewMode === 'month') {
      setCurrentDate(new Date(currentYear, currentMonth - 1, 1));
    } else if (viewMode === 'week') {
      const newD = new Date(currentDate);
      newD.setDate(newD.getDate() - 7);
      setCurrentDate(newD);
    } else {
      setCurrentDate(new Date(currentYear, currentMonth - 1, 1));
    }
  };

  const handleNext = () => {
    if (viewMode === 'month') {
      setCurrentDate(new Date(currentYear, currentMonth + 1, 1));
    } else if (viewMode === 'week') {
      const newD = new Date(currentDate);
      newD.setDate(newD.getDate() + 7);
      setCurrentDate(newD);
    } else {
      setCurrentDate(new Date(currentYear, currentMonth + 1, 1));
    }
  };

  const handleToday = () => {
    setCurrentDate(new Date(2026, 9, 26));
  };

  // Filtered Events
  const filteredEvents = useMemo(() => {
    return rawEvents.filter((ev) => {
      const matchesType = typeFilter === 'All' || ev.type === typeFilter;
      const matchesSearch =
        search === '' ||
        ev.title.toLowerCase().includes(search.toLowerCase()) ||
        (ev.location && ev.location.toLowerCase().includes(search.toLowerCase())) ||
        (ev.classBatch && ev.classBatch.toLowerCase().includes(search.toLowerCase())) ||
        (ev.description && ev.description.toLowerCase().includes(search.toLowerCase()));
      return matchesType && matchesSearch;
    });
  }, [rawEvents, typeFilter, search]);

  // Calendar matrix calculation for Month View (Monday-based)
  const calendarDays = useMemo(() => {
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
    const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);

    // Monday as index 0: getDay() returns 0 for Sunday, 1 for Monday...
    let firstDayIndex = firstDayOfMonth.getDay() - 1;
    if (firstDayIndex === -1) firstDayIndex = 6;

    const days = [];
    const prevMonthLastDay = new Date(currentYear, currentMonth, 0).getDate();

    // Previous month padding days
    for (let i = firstDayIndex - 1; i >= 0; i--) {
      const dayNum = prevMonthLastDay - i;
      const d = new Date(currentYear, currentMonth - 1, dayNum);
      const dateStr = d.toISOString().split('T')[0];
      days.push({
        date: d,
        dateStr,
        dayNum,
        isCurrentMonth: false,
      });
    }

    // Current month days
    for (let i = 1; i <= lastDayOfMonth.getDate(); i++) {
      const d = new Date(currentYear, currentMonth, i);
      const dateStr = d.toISOString().split('T')[0];
      days.push({
        date: d,
        dateStr,
        dayNum: i,
        isCurrentMonth: true,
      });
    }

    // Next month padding days to complete 35 or 42 grid cells
    const remaining = (7 - (days.length % 7)) % 7;
    for (let i = 1; i <= remaining; i++) {
      const d = new Date(currentYear, currentMonth + 1, i);
      const dateStr = d.toISOString().split('T')[0];
      days.push({
        date: d,
        dateStr,
        dayNum: i,
        isCurrentMonth: false,
      });
    }

    return days;
  }, [currentYear, currentMonth]);

  // Drag and Drop event handlers
  const handleDragStart = (e: React.DragEvent, eventId: string) => {
    e.dataTransfer.setData('text/plain', eventId);
    e.dataTransfer.effectAllowed = 'move';
    setDraggedEventId(eventId);
  };

  const handleDragOver = (e: React.DragEvent, dateStr: string) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    if (dragOverDate !== dateStr) {
      setDragOverDate(dateStr);
    }
  };

  const handleDragLeave = () => {
    setDragOverDate(null);
  };

  const handleDrop = (e: React.DragEvent, targetDate: string) => {
    e.preventDefault();
    const eventId = e.dataTransfer.getData('text/plain') || draggedEventId;
    setDragOverDate(null);
    setDraggedEventId(null);

    if (eventId) {
      const targetEv = rawEvents.find((x) => x.id === eventId);
      if (targetEv) {
        if (targetEv.date === targetDate) return;
        erpStorage.moveCalendarEvent(eventId, targetDate);
        setToastMessage(`✨ Rescheduled "${targetEv.title}" to ${targetDate}`);
      }
    }
  };

  // Event modal actions
  const openAddForDate = (dateStr: string) => {
    setFormDate(dateStr);
    setFormTitle('');
    setFormType('Exam');
    setFormDescription('');
    setFormLocation('Main Campus');
    setFormEndDate('');
    setIsAddModalOpen(true);
  };

  const handleSaveNewEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim()) return;

    const newEv: CalendarEvent = {
      id: `EVT-CAL-${Date.now().toString().slice(-5)}`,
      title: formTitle.trim(),
      date: formDate,
      endDate: formEndDate || undefined,
      startTime: formStartTime || undefined,
      endTime: formEndTime || undefined,
      type: formType,
      location: formLocation || undefined,
      targetAudience: formAudience,
      classBatch: formClassBatch || undefined,
      description: formDescription || undefined,
      isNationalHoliday: formType === 'Holiday' ? formIsHoliday : false,
      status: 'Confirmed',
    };

    erpStorage.addCalendarEvent(newEv);
    setIsAddModalOpen(false);
    setToastMessage(`✅ Successfully added event "${newEv.title}"`);
  };

  const handleDeleteSelected = () => {
    if (!selectedEvent) return;
    erpStorage.deleteCalendarEvent(selectedEvent.id);
    setIsDetailModalOpen(false);
    setSelectedEvent(null);
    setToastMessage(`🗑️ Deleted event "${selectedEvent.title}"`);
  };

  const handleQuickShift = (daysToAdd: number) => {
    if (!selectedEvent) return;
    const cur = new Date(selectedEvent.date);
    cur.setDate(cur.getDate() + daysToAdd);
    const newDateStr = cur.toISOString().split('T')[0];
    erpStorage.moveCalendarEvent(selectedEvent.id, newDateStr);
    setSelectedEvent({ ...selectedEvent, date: newDateStr });
    setToastMessage(`Rescheduled "${selectedEvent.title}" to ${newDateStr}`);
  };

  // Export to iCalendar (.ics) standard format
  const handleExportICS = () => {
    let icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//TaleemOS Hub//Academic Calendar 2026//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
      'X-WR-CALNAME:TaleemOS Academic Calendar',
    ];

    filteredEvents.forEach((ev) => {
      const dtStart = ev.date.replace(/-/g, '') + (ev.startTime ? 'T' + ev.startTime.replace(/:/g, '') + '00' : '');
      const dtEnd = (ev.endDate || ev.date).replace(/-/g, '') + (ev.endTime ? 'T' + ev.endTime.replace(/:/g, '') + '00' : '');

      icsContent.push(
        'BEGIN:VEVENT',
        `UID:${ev.id}@taleemos.edu.pk`,
        `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, '').split('.')[0]}Z`,
        `DTSTART:${dtStart}`,
        `DTEND:${dtEnd}`,
        `SUMMARY:[${ev.type}] ${ev.title}`,
        `DESCRIPTION:${ev.description || ''}`,
        `LOCATION:${ev.location || 'Taleem Academy'}`,
        'STATUS:CONFIRMED',
        'END:VEVENT'
      );
    });

    icsContent.push('END:VCALENDAR');
    const blob = new Blob([icsContent.join('\r\n')], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `TaleemOS_Academic_Calendar_${currentYear}.ics`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    setToastMessage('📅 Exported iCalendar (.ics) file successfully!');
  };

  // Month title formatter
  const monthName = currentDate.toLocaleString('en-US', { month: 'long' });

  // Counts for summary pills
  const examCount = rawEvents.filter((e) => e.type === 'Exam').length;
  const holidayCount = rawEvents.filter((e) => e.type === 'Holiday').length;
  const eventCount = rawEvents.filter((e) => e.type === 'Event' || e.type === 'Sports' || e.type === 'Ceremony').length;
  const meetingCount = rawEvents.filter((e) => e.type === 'Meeting').length;

  return (
    <div className="space-y-5">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 animate-fade-in font-medium text-xs">
          <span>{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Module Header with Live Stats */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl border border-indigo-900/40 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-indigo-500/10 to-transparent pointer-events-none" />
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-300" />
                Drag & Drop Interactive Calendar
              </span>
              <span className="text-xs text-slate-400">Term Session 2026-2027</span>
            </div>
            <h1 className="text-2xl font-black tracking-tight flex items-center gap-2.5">
              <CalendarIcon className="w-6 h-6 text-indigo-400" />
              Academic Calendar & Term Milestones
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Drag-and-drop exams, scheduled holidays, and institution events between calendar days.
              Syncs with exam halls, parent notifications, and timetables.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setIsPrintModalOpen(true)}
              className="px-3.5 py-2 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 border border-white/10 transition shadow-sm cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-indigo-300" />
              <span>Print A4 Schedule</span>
            </button>
            <button
              onClick={handleExportICS}
              className="px-3.5 py-2 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 border border-white/10 transition shadow-sm cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 text-emerald-300" />
              <span>Export .ICS</span>
            </button>
            <button
              onClick={() => openAddForDate(new Date().toISOString().split('T')[0])}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center gap-1.5 shadow-lg shadow-indigo-950/40 transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Event / Exam</span>
            </button>
          </div>
        </div>

        {/* Counter Pills */}
        <div className="mt-5 pt-4 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div
            onClick={() => setTypeFilter('Exam')}
            className={`p-2.5 rounded-xl border transition cursor-pointer flex items-center justify-between ${
              typeFilter === 'Exam'
                ? 'bg-rose-500/20 border-rose-400 text-white'
                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">📝</span>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Exams Scheduled</p>
                <p className="text-sm font-black text-rose-300 font-mono">{examCount} Tests</p>
              </div>
            </div>
            <span className="text-xs text-rose-400">View</span>
          </div>

          <div
            onClick={() => setTypeFilter('Holiday')}
            className={`p-2.5 rounded-xl border transition cursor-pointer flex items-center justify-between ${
              typeFilter === 'Holiday'
                ? 'bg-emerald-500/20 border-emerald-400 text-white'
                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">🌴</span>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Official Holidays</p>
                <p className="text-sm font-black text-emerald-300 font-mono">{holidayCount} Days</p>
              </div>
            </div>
            <span className="text-xs text-emerald-400">View</span>
          </div>

          <div
            onClick={() => setTypeFilter('Event')}
            className={`p-2.5 rounded-xl border transition cursor-pointer flex items-center justify-between ${
              typeFilter === 'Event'
                ? 'bg-indigo-500/20 border-indigo-400 text-white'
                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">🎪</span>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">Galas & Activities</p>
                <p className="text-sm font-black text-indigo-300 font-mono">{eventCount} Events</p>
              </div>
            </div>
            <span className="text-xs text-indigo-400">View</span>
          </div>

          <div
            onClick={() => setTypeFilter('Meeting')}
            className={`p-2.5 rounded-xl border transition cursor-pointer flex items-center justify-between ${
              typeFilter === 'Meeting'
                ? 'bg-amber-500/20 border-amber-400 text-white'
                : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-lg">👥</span>
              <div>
                <p className="text-[10px] uppercase font-bold text-slate-400">PTM & Academic</p>
                <p className="text-sm font-black text-amber-300 font-mono">{meetingCount} Sessions</p>
              </div>
            </div>
            <span className="text-xs text-amber-400">View</span>
          </div>
        </div>
      </div>

      {/* Control Bar: View Switcher, Month Navigation, Filters */}
      <div className="bg-white rounded-2xl border p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Month / Year Navigator */}
        <div className="flex items-center gap-3">
          <div className="flex items-center bg-slate-100 rounded-xl p-1 border">
            <button
              onClick={handlePrev}
              title="Previous Month"
              className="p-1.5 hover:bg-white rounded-lg transition text-slate-700 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleToday}
              className="px-2.5 py-1 text-xs font-bold hover:bg-white rounded-lg transition text-slate-700 cursor-pointer"
            >
              Today
            </button>
            <button
              onClick={handleNext}
              title="Next Month"
              className="p-1.5 hover:bg-white rounded-lg transition text-slate-700 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <h2 className="text-lg font-black text-slate-900 tracking-tight font-mono">
            {monthName} {currentYear}
          </h2>
        </div>

        {/* View Modes & Search */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Search */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search event, exam..."
              className="pl-8 pr-3 py-1.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 w-36 sm:w-44 transition"
            />
          </div>

          {/* Type Filter Dropdown */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border text-xs">
            <Filter className="w-3.5 h-3.5 text-slate-500 ml-1.5" />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="bg-transparent font-bold text-slate-700 outline-none pr-1 cursor-pointer"
            >
              <option value="All">All Types ({rawEvents.length})</option>
              <option value="Exam">📝 Exams ({examCount})</option>
              <option value="Holiday">🌴 Holidays ({holidayCount})</option>
              <option value="Event">🎪 Events & Galas</option>
              <option value="Meeting">👥 PTM & Meetings</option>
              <option value="Sports">🏅 Sports Competitions</option>
              <option value="Ceremony">🎓 Ceremonies</option>
            </select>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border text-xs">
            <button
              onClick={() => setViewMode('month')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                viewMode === 'month' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              <span>Month</span>
            </button>
            <button
              onClick={() => setViewMode('week')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                viewMode === 'week' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Week</span>
            </button>
            <button
              onClick={() => setViewMode('agenda')}
              className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1.5 transition cursor-pointer ${
                viewMode === 'agenda' ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Agenda</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Drag-and-Drop Calendar Container */}
      {viewMode === 'month' && (
        <div className="bg-white rounded-3xl border shadow-sm overflow-hidden">
          {/* Day Headers (Mon - Sun) */}
          <div className="grid grid-cols-7 border-b bg-slate-50/80 text-center text-xs font-bold text-slate-500 py-3">
            {DAYS_OF_WEEK.map((d, idx) => (
              <div key={d} className={`${idx === 5 || idx === 6 ? 'text-rose-500' : ''}`}>
                {d}
              </div>
            ))}
          </div>

          {/* 7-column Calendar Matrix */}
          <div className="grid grid-cols-7 auto-rows-fr divide-x divide-y divide-slate-100">
            {calendarDays.map((cell) => {
              const dayEvents = filteredEvents.filter((ev) => ev.date === cell.dateStr);
              const isToday = cell.dateStr === '2026-10-26';
              const isDropTarget = dragOverDate === cell.dateStr;

              return (
                <div
                  key={cell.dateStr}
                  onDragOver={(e) => handleDragOver(e, cell.dateStr)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, cell.dateStr)}
                  className={`min-h-[110px] md:min-h-[135px] p-2 flex flex-col justify-between transition-all group relative ${
                    cell.isCurrentMonth ? 'bg-white' : 'bg-slate-50/60 text-slate-400'
                  } ${isDropTarget ? 'bg-indigo-50/90 ring-2 ring-indigo-500 ring-inset scale-[1.01] z-10' : ''}`}
                >
                  {/* Cell Header: Day Number + Add Button on Hover */}
                  <div className="flex items-center justify-between mb-1.5">
                    <span
                      className={`text-xs font-mono font-bold w-6 h-6 rounded-full flex items-center justify-center ${
                        isToday
                          ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
                          : cell.isCurrentMonth
                          ? 'text-slate-700'
                          : 'text-slate-400'
                      }`}
                    >
                      {cell.dayNum}
                    </span>

                    <button
                      onClick={() => openAddForDate(cell.dateStr)}
                      title={`Add Event on ${cell.dateStr}`}
                      className="opacity-0 group-hover:opacity-100 w-5 h-5 rounded-md bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center transition cursor-pointer text-xs"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  {/* Event Chips List (Drag & Drop Sources) */}
                  <div className="flex-1 space-y-1 overflow-y-auto max-h-[85px] scrollbar-none">
                    {dayEvents.map((ev) => {
                      const cfg = EVENT_TYPE_CONFIG[ev.type] || EVENT_TYPE_CONFIG.Event;
                      return (
                        <div
                          key={ev.id}
                          draggable
                          onDragStart={(e) => handleDragStart(e, ev.id)}
                          onClick={() => {
                            setSelectedEvent(ev);
                            setIsDetailModalOpen(true);
                          }}
                          className={`px-2 py-1 rounded-lg text-[10.5px] font-bold border transition-all cursor-grab active:cursor-grabbing flex items-center gap-1.5 shadow-xs hover:shadow-sm select-none truncate ${cfg.cardBg} ${cfg.border} hover:scale-[1.02]`}
                          title={`[${ev.type}] ${ev.title} - Drag to move`}
                        >
                          <span className="shrink-0 text-xs">{cfg.icon}</span>
                          <span className="truncate flex-1 text-slate-800">{ev.title}</span>
                          {ev.startTime && (
                            <span className="text-[9px] font-mono text-slate-500 shrink-0 hidden sm:inline">
                              {ev.startTime}
                            </span>
                          )}
                        </div>
                      );
                    })}

                    {dayEvents.length === 0 && isDropTarget && (
                      <div className="border-2 border-dashed border-indigo-400 rounded-lg p-2 text-center text-[10px] text-indigo-600 font-bold bg-white/80">
                        Drop here
                      </div>
                    )}
                  </div>

                  {/* Empty state hint */}
                  {dayEvents.length === 0 && !isDropTarget && (
                    <div
                      onClick={() => openAddForDate(cell.dateStr)}
                      className="h-full flex items-center justify-center opacity-0 group-hover:opacity-30 cursor-pointer"
                    >
                      <span className="text-[9px] text-slate-400">+ Add</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Week View */}
      {viewMode === 'week' && (
        <div className="bg-white rounded-3xl border shadow-sm p-4 overflow-x-auto">
          <div className="min-w-[700px] grid grid-cols-7 gap-3">
            {DAYS_OF_WEEK.map((dName, idx) => {
              // Current week dates starting from Monday of active week
              const firstDayOfWeek = new Date(currentDate);
              const day = firstDayOfWeek.getDay();
              const diff = firstDayOfWeek.getDate() - day + (day === 0 ? -6 : 1) + idx;
              const colDate = new Date(firstDayOfWeek.setDate(diff));
              const dateStr = colDate.toISOString().split('T')[0];
              const dayEvents = filteredEvents.filter((e) => e.date === dateStr);
              const isToday = dateStr === '2026-10-26';
              const isDropTarget = dragOverDate === dateStr;

              return (
                <div
                  key={dName}
                  onDragOver={(e) => handleDragOver(e, dateStr)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, dateStr)}
                  className={`rounded-2xl border p-3 min-h-[360px] flex flex-col justify-between transition ${
                    isToday ? 'bg-indigo-50/40 border-indigo-300' : 'bg-slate-50/60 border-slate-200'
                  } ${isDropTarget ? 'ring-2 ring-indigo-500 bg-indigo-100/60' : ''}`}
                >
                  <div>
                    <div className="flex items-center justify-between pb-2 mb-3 border-b">
                      <div>
                        <p className="text-xs font-bold uppercase text-slate-500">{dName}</p>
                        <p className={`text-base font-black font-mono ${isToday ? 'text-indigo-600' : 'text-slate-800'}`}>
                          {colDate.getDate()} {colDate.toLocaleString('en-US', { month: 'short' })}
                        </p>
                      </div>
                      <button
                        onClick={() => openAddForDate(dateStr)}
                        className="w-6 h-6 rounded-lg bg-white border text-slate-600 hover:bg-slate-100 flex items-center justify-center text-xs"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <div className="space-y-2">
                      {dayEvents.map((ev) => {
                        const cfg = EVENT_TYPE_CONFIG[ev.type] || EVENT_TYPE_CONFIG.Event;
                        return (
                          <div
                            key={ev.id}
                            draggable
                            onDragStart={(e) => handleDragStart(e, ev.id)}
                            onClick={() => {
                              setSelectedEvent(ev);
                              setIsDetailModalOpen(true);
                            }}
                            className={`p-2.5 rounded-xl border text-xs font-medium cursor-grab active:cursor-grabbing shadow-xs ${cfg.cardBg} ${cfg.border} hover:scale-[1.02] transition`}
                          >
                            <div className="flex items-center gap-1.5 mb-1">
                              <span>{cfg.icon}</span>
                              <span className="font-bold text-slate-900 truncate">{ev.title}</span>
                            </div>
                            {ev.startTime && (
                              <p className="text-[10px] text-slate-600 flex items-center gap-1">
                                <Clock className="w-3 h-3 text-slate-400" />
                                {ev.startTime} - {ev.endTime || 'End'}
                              </p>
                            )}
                            {ev.location && (
                              <p className="text-[10px] text-slate-500 flex items-center gap-1 truncate mt-0.5">
                                <MapPin className="w-3 h-3 text-slate-400" />
                                {ev.location}
                              </p>
                            )}
                          </div>
                        );
                      })}

                      {dayEvents.length === 0 && (
                        <p className="text-[11px] text-slate-400 italic text-center py-8">
                          No schedule
                        </p>
                      )}
                    </div>
                  </div>

                  <button
                    onClick={() => openAddForDate(dateStr)}
                    className="mt-3 w-full py-1.5 rounded-lg border border-dashed border-slate-300 text-[11px] font-bold text-slate-500 hover:bg-white hover:text-indigo-600 transition"
                  >
                    + Schedule
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Agenda / Chronological List View */}
      {viewMode === 'agenda' && (
        <div className="bg-white rounded-3xl border shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-black text-base text-slate-900">
                Term Chronological Agenda ({filteredEvents.length} Events)
              </h3>
              <p className="text-xs text-slate-500">
                Sorted by upcoming date. Click any entry to edit, shift dates, or view venue details.
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {filteredEvents
              .slice()
              .sort((a, b) => a.date.localeCompare(b.date))
              .map((ev) => {
                const cfg = EVENT_TYPE_CONFIG[ev.type] || EVENT_TYPE_CONFIG.Event;
                return (
                  <div
                    key={ev.id}
                    onClick={() => {
                      setSelectedEvent(ev);
                      setIsDetailModalOpen(true);
                    }}
                    className="py-3.5 px-3 rounded-2xl hover:bg-slate-50/80 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 cursor-pointer group"
                  >
                    <div className="flex items-start sm:items-center gap-3">
                      {/* Date Badge */}
                      <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white flex flex-col items-center justify-center shrink-0 font-mono shadow-sm">
                        <span className="text-[10px] uppercase font-bold text-slate-400">
                          {new Date(ev.date).toLocaleString('en-US', { month: 'short' })}
                        </span>
                        <span className="text-lg font-black leading-none">
                          {new Date(ev.date).getDate()}
                        </span>
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${cfg.badgeBg}`}>
                            {cfg.icon} {ev.type}
                          </span>
                          {ev.isNationalHoliday && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                              National Holiday
                            </span>
                          )}
                          {ev.classBatch && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] bg-slate-100 font-semibold text-slate-700">
                              {ev.classBatch}
                            </span>
                          )}
                        </div>

                        <h4 className="font-extrabold text-sm text-slate-900 mt-1 group-hover:text-indigo-600 transition">
                          {ev.title}
                        </h4>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                          {ev.startTime && (
                            <span className="flex items-center gap-1 font-mono">
                              <Clock className="w-3.5 h-3.5 text-slate-400" />
                              {ev.startTime} - {ev.endTime || 'End'}
                            </span>
                          )}
                          {ev.location && (
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3.5 h-3.5 text-slate-400" />
                              {ev.location}
                            </span>
                          )}
                          {ev.targetAudience && (
                            <span className="flex items-center gap-1">
                              <Users className="w-3.5 h-3.5 text-slate-400" />
                              Audience: {ev.targetAudience}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <span className="text-xs font-bold text-slate-400 group-hover:text-indigo-600 flex items-center gap-1">
                        <span>Details</span>
                        <ChevronRight className="w-4 h-4" />
                      </span>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Drag & Drop Quick Helper Bar */}
      <div className="p-4 bg-gradient-to-r from-indigo-50 to-slate-50 rounded-2xl border border-indigo-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <Move className="w-4 h-4 text-indigo-600" />
          <span className="font-bold text-slate-900">Drag & Drop Reschedule:</span>
          <span>
            Simply click & drag any event card across calendar days to automatically update exam & holiday dates.
          </span>
        </div>
        <div className="flex items-center gap-3 text-[11px] font-semibold text-slate-500">
          <span>Active Institution: {state.activeInstitutionId === 'inst-1' ? 'Kandhkot' : state.activeInstitutionId === 'inst-2' ? 'Sukkur' : 'Kashmore'} Campus</span>
        </div>
      </div>

      {/* Modal: Add New Academic Event / Exam */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Schedule Academic Event / Exam / Holiday"
      >
        <form onSubmit={handleSaveNewEvent} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Event / Examination Title *
            </label>
            <input
              type="text"
              required
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              placeholder="e.g. Physics Mid-Term Examination, Annual Sports Gala"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Event Type *</label>
              <select
                value={formType}
                onChange={(e) => setFormType(e.target.value as CalendarEventType)}
                className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs font-bold text-slate-800"
              >
                <option value="Exam">📝 Exam / Assessment</option>
                <option value="Holiday">🌴 Official Holiday</option>
                <option value="Event">🎪 Event / Gala</option>
                <option value="Meeting">👥 Meeting / PTM</option>
                <option value="Sports">🏅 Sports Activity</option>
                <option value="Ceremony">🎓 Award Ceremony</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Target Audience</label>
              <select
                value={formAudience}
                onChange={(e) => setFormAudience(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs font-bold text-slate-800"
              >
                <option value="All">All Institution</option>
                <option value="Students">Students Only</option>
                <option value="Faculty">Faculty & Staff</option>
                <option value="Parents">Parents & Guardians</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Date *</label>
              <input
                type="date"
                required
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">End Date (Multi-day)</label>
              <input
                type="date"
                value={formEndDate}
                onChange={(e) => setFormEndDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs font-mono font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Start Time</label>
              <input
                type="time"
                value={formStartTime}
                onChange={(e) => setFormStartTime(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">End Time</label>
              <input
                type="time"
                value={formEndTime}
                onChange={(e) => setFormEndTime(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Venue / Location</label>
              <input
                type="text"
                value={formLocation}
                onChange={(e) => setFormLocation(e.target.value)}
                placeholder="e.g. Exam Hall A, Science Lab"
                className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Class / Batch</label>
              <input
                type="text"
                value={formClassBatch}
                onChange={(e) => setFormClassBatch(e.target.value)}
                placeholder="e.g. Batch 2026-A, Class 10"
                className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Description & Guidelines</label>
            <textarea
              rows={2}
              value={formDescription}
              onChange={(e) => setFormDescription(e.target.value)}
              placeholder="Important instructions for candidates, syllabus scope, or dress code..."
              className="w-full px-3 py-2 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500"
            />
          </div>

          {formType === 'Holiday' && (
            <div className="flex items-center gap-2 pt-1">
              <input
                type="checkbox"
                id="isNationalHoliday"
                checked={formIsHoliday}
                onChange={(e) => setFormIsHoliday(e.target.checked)}
                className="w-4 h-4 text-emerald-600 rounded"
              />
              <label htmlFor="isNationalHoliday" className="text-xs text-slate-700 font-semibold cursor-pointer">
                Declare as Official Gazetted Holiday (Institution Closed)
              </label>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-md shadow-indigo-900/30"
            >
              Confirm Schedule
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal: View & Quick Reschedule Event */}
      {selectedEvent && (
        <Modal
          isOpen={isDetailModalOpen}
          onClose={() => setIsDetailModalOpen(false)}
          title={`Event Details: ${selectedEvent.title}`}
        >
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3.5 bg-slate-50 rounded-2xl border">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">
                  {EVENT_TYPE_CONFIG[selectedEvent.type]?.icon || '📅'}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] bg-slate-200 text-slate-700 px-2 py-0.5 rounded">
                      {selectedEvent.id}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                        EVENT_TYPE_CONFIG[selectedEvent.type]?.badgeBg
                      }`}
                    >
                      {selectedEvent.type}
                    </span>
                  </div>
                  <h4 className="font-extrabold text-sm text-slate-900 mt-1">
                    {selectedEvent.title}
                  </h4>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Scheduled Date</span>
                <span className="font-mono font-bold text-indigo-700 text-sm">
                  {selectedEvent.date}
                </span>
                {selectedEvent.endDate && (
                  <span className="block text-[10px] text-slate-500 font-mono">
                    to {selectedEvent.endDate}
                  </span>
                )}
              </div>

              <div className="p-3 bg-slate-50 rounded-xl border">
                <span className="text-[10px] font-bold text-slate-400 uppercase block">Timings</span>
                <span className="font-mono font-bold text-slate-800 text-sm">
                  {selectedEvent.startTime || 'Full Day'} {selectedEvent.endTime ? `- ${selectedEvent.endTime}` : ''}
                </span>
              </div>
            </div>

            {selectedEvent.location && (
              <div className="p-3 bg-slate-50 rounded-xl border text-xs flex items-center gap-2">
                <MapPin className="w-4 h-4 text-indigo-600" />
                <span className="font-bold text-slate-700">Location / Hall:</span>
                <span className="text-slate-900 font-medium">{selectedEvent.location}</span>
              </div>
            )}

            {selectedEvent.classBatch && (
              <div className="p-3 bg-slate-50 rounded-xl border text-xs flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-indigo-600" />
                <span className="font-bold text-slate-700">Batch / Target Class:</span>
                <span className="text-slate-900 font-medium">{selectedEvent.classBatch}</span>
              </div>
            )}

            {selectedEvent.description && (
              <div className="p-3.5 bg-slate-50 rounded-xl border text-xs">
                <span className="text-[10px] font-bold text-slate-400 uppercase block mb-1">
                  Description & Instructions
                </span>
                <p className="text-slate-700 leading-relaxed">{selectedEvent.description}</p>
              </div>
            )}

            {/* Quick Date Shift Buttons (Touch-friendly drag alternative) */}
            <div className="p-3 bg-indigo-50/70 border border-indigo-200 rounded-2xl">
              <p className="text-[11px] font-bold text-indigo-950 mb-2 flex items-center gap-1.5">
                <Move className="w-3.5 h-3.5 text-indigo-600" />
                Quick Reschedule (or Drag & Drop on Calendar Grid):
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleQuickShift(-1)}
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border transition cursor-pointer"
                >
                  -1 Day
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickShift(1)}
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border transition cursor-pointer"
                >
                  +1 Day
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickShift(7)}
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border transition cursor-pointer"
                >
                  +1 Week
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickShift(-7)}
                  className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border transition cursor-pointer"
                >
                  -1 Week
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t">
              <button
                type="button"
                onClick={handleDeleteSelected}
                className="px-3 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Event</span>
              </button>

              <button
                type="button"
                onClick={() => setIsDetailModalOpen(false)}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition"
              >
                Done
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Official Printable Academic Calendar Letterhead */}
      <Modal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        title="Official Academic Calendar Schedule (Print / PDF)"
        maxWidth="max-w-4xl"
      >
        <div className="space-y-4">
          <div className="flex justify-end gap-2 pb-2 border-b no-print">
            <button
              onClick={() => triggerBrowserPrint()}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow"
            >
              <Printer className="w-4 h-4" />
              <span>Print Official Notice</span>
            </button>
          </div>

          <div id="printable-calendar">
            <LetterheadPrint
              title="OFFICIAL ACADEMIC CALENDAR & EXAMINATION SCHEDULE"
              subtitle={`Academic Session 2026-2027 • Approved by Governing Body`}
              documentNo={`TAK-CAL-${currentYear}`}
            >
              <div className="space-y-6 text-xs text-slate-800">
                <div className="p-3 bg-slate-50 border rounded-xl flex items-center justify-between">
                  <div>
                    <p className="font-bold">Term Duration: September 2026 – January 2027</p>
                    <p className="text-[11px] text-slate-500">Applicable to all SSC, HSSC & IT Diploma Sections</p>
                  </div>
                  <span className="font-mono text-[11px] bg-slate-200 px-2.5 py-1 rounded-md font-bold">
                    Official Release
                  </span>
                </div>

                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead className="bg-slate-100">
                    <tr>
                      <th className="border border-slate-300 p-2 font-black">Date</th>
                      <th className="border border-slate-300 p-2 font-black">Day</th>
                      <th className="border border-slate-300 p-2 font-black">Category</th>
                      <th className="border border-slate-300 p-2 font-black">Description & Milestones</th>
                      <th className="border border-slate-300 p-2 font-black">Timings / Venue</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredEvents
                      .slice()
                      .sort((a, b) => a.date.localeCompare(b.date))
                      .map((e) => (
                        <tr key={e.id} className="border-b border-slate-200 hover:bg-slate-50">
                          <td className="border border-slate-300 p-2 font-mono font-bold whitespace-nowrap">
                            {e.date}
                            {e.endDate && <span className="block text-[10px] text-slate-500">to {e.endDate}</span>}
                          </td>
                          <td className="border border-slate-300 p-2 font-medium">
                            {new Date(e.date).toLocaleDateString('en-US', { weekday: 'short' })}
                          </td>
                          <td className="border border-slate-300 p-2 font-bold whitespace-nowrap">
                            [{e.type}]
                          </td>
                          <td className="border border-slate-300 p-2">
                            <span className="font-bold block">{e.title}</span>
                            {e.classBatch && (
                              <span className="text-[10px] text-slate-600 block">Class: {e.classBatch}</span>
                            )}
                            {e.description && (
                              <span className="text-[10px] text-slate-500 block italic">{e.description}</span>
                            )}
                          </td>
                          <td className="border border-slate-300 p-2 font-mono text-[11px]">
                            {e.startTime ? `${e.startTime} - ${e.endTime || ''}` : 'Full Day'}
                            {e.location && <span className="block text-[10px] text-slate-600">{e.location}</span>}
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>

                <div className="pt-8 grid grid-cols-3 gap-6 text-center text-xs">
                  <div className="border-t border-slate-400 pt-1">
                    <p className="font-bold">Controller of Examinations</p>
                    <p className="text-[10px] text-slate-500">Taleem Academy</p>
                  </div>
                  <div className="border-t border-slate-400 pt-1">
                    <p className="font-bold">Principal / Academic Head</p>
                    <p className="text-[10px] text-slate-500">Executive Signature</p>
                  </div>
                  <div className="border-t border-slate-400 pt-1">
                    <p className="font-bold">Director General</p>
                    <p className="text-[10px] text-slate-500">Institutional Seal</p>
                  </div>
                </div>
              </div>
            </LetterheadPrint>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default AcademicCalendarModule;
