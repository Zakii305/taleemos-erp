import React, { useState } from 'react';
import { UserCheck, Plus, Printer, Download, Clock, LogIn, LogOut, CheckCircle, AlertCircle } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type StaffAttendanceRecord } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const StaffAttendanceModule: React.FC = () => {
  const state = erpStorage.getState();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);

  // Form
  const [staffName, setStaffName] = useState('Prof. Ghulam Rasool');
  const [staffId, setStaffId] = useState('STF-01');
  const [role, setRole] = useState('Director / Senior Physics Faculty');
  const [checkIn, setCheckIn] = useState('08:00 AM');
  const [checkOut, setCheckOut] = useState('03:30 PM');
  const [status, setStatus] = useState<StaffAttendanceRecord['status']>('Present');
  const [overtimeHours, setOvertimeHours] = useState(0);

  const filtered = state.staffAttendance;

  const handleSaveAttendance = (e: React.FormEvent) => {
    e.preventDefault();
    const newRecord: StaffAttendanceRecord = {
      id: `SA-${Date.now().toString().slice(-4)}`,
      date: selectedDate,
      staffName,
      staffId,
      role,
      checkIn,
      checkOut,
      status,
      overtimeHours: Number(overtimeHours),
    };

    erpStorage.addItem('staffAttendance', newRecord);
    setIsLogModalOpen(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <UserCheck className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Staff & Faculty Attendance</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              BIOMETRIC LOGS
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Faculty check-in & check-out logs, punctuality metrics, late arrivals, and overtime calculations.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Staff Ledger
          </button>
          <button
            type="button"
            onClick={() => setIsLogModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Log Biometric Entry
          </button>
        </div>
      </div>

      {/* Staff Log Table */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
              <th className="p-3">Staff ID</th>
              <th className="p-3">Staff / Faculty Name</th>
              <th className="p-3">Designation</th>
              <th className="p-3">Check In</th>
              <th className="p-3">Check Out</th>
              <th className="p-3">Overtime</th>
              <th className="p-3 text-center">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((item) => (
              <tr key={item.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition-colors">
                <td className="p-3 font-mono font-bold text-indigo-700">{item.staffId}</td>
                <td className="p-3 font-bold text-slate-900">{item.staffName}</td>
                <td className="p-3 text-slate-600">{item.role}</td>
                <td className="p-3 font-mono text-emerald-700 font-bold">{item.checkIn}</td>
                <td className="p-3 font-mono text-indigo-700 font-bold">{item.checkOut}</td>
                <td className="p-3 font-mono text-slate-700">
                  {item.overtimeHours > 0 ? `+${item.overtimeHours} hrs` : '-'}
                </td>
                <td className="p-3 text-center">
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                      item.status === 'Present'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'Late'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {item.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* LOG MODAL */}
      <Modal
        isOpen={isLogModalOpen}
        onClose={() => setIsLogModalOpen(false)}
        title="Log Staff Check-In / Out Entry"
        subtitle="Record faculty presence or manual biometric override"
        badge="FACULTY LOG"
      >
        <form onSubmit={handleSaveAttendance} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Staff Member</label>
              <input
                type="text"
                required
                value={staffName}
                onChange={(e) => setStaffName(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Staff ID</label>
              <input
                type="text"
                value={staffId}
                onChange={(e) => setStaffId(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Check In Time</label>
              <input
                type="text"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Check Out Time</label>
              <input
                type="text"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as StaffAttendanceRecord['status'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Present">Present</option>
                <option value="Late">Late</option>
                <option value="Absent">Absent</option>
                <option value="On Leave">On Leave</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Overtime Hours Worked
            </label>
            <input
              type="number"
              step="0.5"
              min={0}
              value={overtimeHours}
              onChange={(e) => setOvertimeHours(Number(e.target.value))}
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
            />
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsLogModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Log Entry
            </button>
          </div>
        </form>
      </Modal>

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Staff Biometric Timecard Ledger</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('staff-attendance-print-table', 'TaleemOS_Staff_Timecard')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="staff-attendance-print-table">
              <LetterheadPrint
                title="FACULTY & ADMINISTRATIVE STAFF DAILY TIMECARD"
                documentNo="STF-TIMECARD-2026"
                summaryStats={[
                  { label: 'Staff Logged', value: filtered.length },
                  { label: 'Present Today', value: filtered.filter((s) => s.status === 'Present').length },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Staff ID</th>
                      <th className="border border-slate-300 p-2">Name</th>
                      <th className="border border-slate-300 p-2">Designation</th>
                      <th className="border border-slate-300 p-2">Check-In</th>
                      <th className="border border-slate-300 p-2">Check-Out</th>
                      <th className="border border-slate-300 p-2">Overtime</th>
                      <th className="border border-slate-300 p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((s) => (
                      <tr key={s.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-indigo-700">
                          {s.staffId}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold">{s.staffName}</td>
                        <td className="border border-slate-300 p-2">{s.role}</td>
                        <td className="border border-slate-300 p-2 font-mono">{s.checkIn}</td>
                        <td className="border border-slate-300 p-2 font-mono">{s.checkOut}</td>
                        <td className="border border-slate-300 p-2 font-mono">{s.overtimeHours} hrs</td>
                        <td className="border border-slate-300 p-2 font-bold">{s.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StaffAttendanceModule;
