import React, { useState } from 'react';
import { FileText, Plus, Printer, Download, Clock, CheckCircle, XCircle, AlertCircle, Calendar } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type LeaveRequest, type ApprovalRequest } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const LeavesModule: React.FC = () => {
  const state = erpStorage.getState();
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);

  // Form fields
  const [applicantType, setApplicantType] = useState<LeaveRequest['applicantType']>('Staff');
  const [applicantName, setApplicantName] = useState(state.userName);
  const [applicantId, setApplicantId] = useState('STF-03');
  const [leaveType, setLeaveType] = useState<LeaveRequest['leaveType']>('Casual');
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [totalDays, setTotalDays] = useState(1);
  const [reason, setReason] = useState('');

  const handleApplyLeave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reason.trim()) return;

    const leaveId = `LEV-${Date.now().toString().slice(-4)}`;
    const newLeave: LeaveRequest = {
      id: leaveId,
      applicantType,
      applicantName,
      applicantId,
      leaveType,
      startDate,
      endDate,
      totalDays: Number(totalDays),
      reason,
      status: 'Pending',
      appliedDate: new Date().toISOString().split('T')[0],
    };

    erpStorage.addItem('leaves', newLeave);

    // If staff leave, route to Principal approval queue
    const approvalReq: ApprovalRequest = {
      id: `APP-${Date.now().toString().slice(-4)}`,
      module: 'Staff Leave',
      recordId: leaveId,
      title: `${leaveType} Leave: ${applicantName} (${totalDays} Days)`,
      requestedBy: applicantName,
      requestedRole: state.activeRole,
      currentApproverRole: 'Principal',
      amountOrValue: `${totalDays} Days (${startDate} to ${endDate})`,
      status: 'Pending Approval',
      date: new Date().toISOString().split('T')[0],
      reason,
      history: [
        {
          actor: applicantName,
          role: state.activeRole,
          action: 'Created',
          timestamp: new Date().toLocaleString(),
        },
      ],
    };
    erpStorage.addItem('approvals', approvalReq);

    setIsApplyModalOpen(false);
    setReason('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <FileText className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Leave Management ERP</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              APPROVAL CHAIN
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Faculty & student leave applications, quota tracking, medical documents, and Principal authorization.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Leave Ledger
          </button>
          <button
            type="button"
            onClick={() => setIsApplyModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Apply For Leave
          </button>
        </div>
      </div>

      {/* Leave Requests list */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-500" />
          Leave Applications & Institutional Sanctions
        </h3>

        <div className="space-y-3">
          {state.leaves.map((l) => (
            <div
              key={l.id}
              className="p-4 bg-slate-50 hover:bg-white rounded-2xl border border-slate-200 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-black text-indigo-700">{l.id}</span>
                  <h4 className="font-bold text-slate-900 text-sm">{l.applicantName}</h4>
                  <span className="px-2 py-0.2 bg-slate-200 text-slate-700 text-[10px] font-bold rounded">
                    {l.applicantType}
                  </span>
                  <span
                    className={`px-2 py-0.2 rounded-full text-[10px] font-black uppercase ${
                      l.status === 'Approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : l.status === 'Pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {l.status}
                  </span>
                </div>

                <div className="mt-1 text-xs text-slate-600 flex items-center gap-3">
                  <span>Type: <strong className="text-slate-800">{l.leaveType}</strong></span>
                  <span>&bull;</span>
                  <span className="font-mono">{l.startDate} to {l.endDate} ({l.totalDays} days)</span>
                </div>

                <p className="mt-1 text-xs text-slate-700 italic bg-white p-2.5 rounded-xl border border-slate-100">
                  &ldquo;{l.reason}&rdquo;
                </p>
              </div>

              <div className="text-right text-xs shrink-0">
                <span className="text-slate-400 block font-semibold text-[10px]">SANCTION STATUS</span>
                <span className="font-bold text-slate-800">
                  {l.approvedBy ? l.approvedBy : 'Awaiting Principal Approval'}
                </span>
                <span className="text-[10px] text-slate-400 block font-mono">Applied: {l.appliedDate}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* APPLY FOR LEAVE MODAL */}
      <Modal
        isOpen={isApplyModalOpen}
        onClose={() => setIsApplyModalOpen(false)}
        title="Submit Institutional Leave Application"
        subtitle="Automatic escalation to Principal office for sanctioning"
        badge="LEAVE PORTAL"
      >
        <form onSubmit={handleApplyLeave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Applicant Type</label>
              <select
                value={applicantType}
                onChange={(e) => setApplicantType(e.target.value as LeaveRequest['applicantType'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Staff">Staff / Faculty</option>
                <option value="Student">Student</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Applicant Name</label>
              <input
                type="text"
                required
                value={applicantName}
                onChange={(e) => setApplicantName(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Leave Type</label>
              <select
                value={leaveType}
                onChange={(e) => setLeaveType(e.target.value as LeaveRequest['leaveType'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Sick">Sick Leave</option>
                <option value="Casual">Casual Leave</option>
                <option value="Emergency">Emergency Leave</option>
                <option value="Maternity / Paternity">Maternity / Paternity</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">From Date</label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">To Date</label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Total Days</label>
              <input
                type="number"
                min={1}
                value={totalDays}
                onChange={(e) => setTotalDays(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono font-bold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Reason / Medical Certificate Reference *
            </label>
            <textarea
              required
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="State reason clearly with dates and medical/official justification..."
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
            />
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsApplyModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Submit Application
            </button>
          </div>
        </form>
      </Modal>

      {/* PRINT ALL LEAVES */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Institutional Leaves Register (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('leaves-print-table', 'TaleemOS_Leaves_Register')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="leaves-print-table">
              <LetterheadPrint
                title="INSTITUTIONAL LEAVE APPLICATIONS & SANCTION LEDGER"
                documentNo="LEV-LEDGER-2026"
                summaryStats={[
                  { label: 'Total Leaves', value: state.leaves.length },
                  { label: 'Approved', value: state.leaves.filter((l) => l.status === 'Approved').length },
                  { label: 'Pending', value: state.leaves.filter((l) => l.status === 'Pending').length },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Ref</th>
                      <th className="border border-slate-300 p-2">Applicant</th>
                      <th className="border border-slate-300 p-2">Type</th>
                      <th className="border border-slate-300 p-2">Duration</th>
                      <th className="border border-slate-300 p-2">Days</th>
                      <th className="border border-slate-300 p-2">Sanctioned By</th>
                      <th className="border border-slate-300 p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.leaves.map((l) => (
                      <tr key={l.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-indigo-700">{l.id}</td>
                        <td className="border border-slate-300 p-2 font-bold">{l.applicantName}</td>
                        <td className="border border-slate-300 p-2">{l.leaveType}</td>
                        <td className="border border-slate-300 p-2 font-mono">
                          {l.startDate} to {l.endDate}
                        </td>
                        <td className="border border-slate-300 p-2 font-mono font-bold">{l.totalDays}</td>
                        <td className="border border-slate-300 p-2">{l.approvedBy || 'Pending'}</td>
                        <td className="border border-slate-300 p-2 font-bold">{l.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeavesModule;
