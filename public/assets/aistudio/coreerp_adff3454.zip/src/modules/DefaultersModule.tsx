import React, { useState } from 'react';
import { AlertTriangle, Printer, Download, Search, MessageSquare, Send, CheckCircle2, Phone } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const DefaultersModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [batchFilter, setBatchFilter] = useState('All');
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);
  const [sentAlert, setSentAlert] = useState<string | null>(null);

  // Unpaid or Partial fee vouchers
  const unpaidVouchers = state.fees.filter((f) => f.status === 'Unpaid' || f.status === 'Partial');

  const filtered = unpaidVouchers.filter((v) => {
    const matchSearch =
      v.studentName.toLowerCase().includes(search.toLowerCase()) ||
      v.rollNo.toLowerCase().includes(search.toLowerCase()) ||
      v.voucherNo.toLowerCase().includes(search.toLowerCase());
    const matchBatch = batchFilter === 'All' || v.batch === batchFilter;
    return matchSearch && matchBatch;
  });

  const totalDefaulterAmount = filtered.reduce((sum, v) => sum + v.netPayable, 0);

  const handleSendWhatsApp = (v: (typeof unpaidVouchers)[0]) => {
    const message = encodeURIComponent(
      `Assalam-o-Alaikum Respected Parent, this is an automated reminder from Taleem Academy Kandhkot. Tuition fee voucher ${v.voucherNo} for ${v.studentName} (${v.rollNo}) amounting to PKR ${v.netPayable} for ${v.month} is overdue. Kindly clear at your earliest convenience.`
    );
    window.open(`https://wa.me/?text=${message}`, '_blank');
    setSentAlert(`Dispatched WhatsApp notification for ${v.studentName}`);
    setTimeout(() => setSentAlert(null), 3500);
  };

  const handleSendSMS = (v: (typeof unpaidVouchers)[0]) => {
    setSentAlert(`Queued GSM Gateway SMS reminder for ${v.studentName} (${v.rollNo})`);
    setTimeout(() => setSentAlert(null), 3500);
  };

  const handleSendBulkSMS = () => {
    setSentAlert(`Dispatched batch SMS reminders to parents of all ${filtered.length} fee defaulters.`);
    setTimeout(() => setSentAlert(null), 4000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-rose-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-rose-600 rounded-xl">
              <AlertTriangle className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Tuition Fee Defaulters PRO</h1>
            <span className="px-2 py-0.5 bg-rose-500 text-white font-black text-[10px] rounded uppercase">
              ARREARS RECOVERY
            </span>
          </div>
          <p className="text-xs text-rose-200 mt-1">
            Real-time defaulter rosters, automated WhatsApp/SMS dispatch, and institutional recovery statistics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Defaulters List
          </button>
          <button
            type="button"
            onClick={handleSendBulkSMS}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            Bulk SMS All ({filtered.length})
          </button>
        </div>
      </div>

      {sentAlert && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl animate-in fade-in flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{sentAlert}</span>
        </div>
      )}

      {/* KPI */}
      <div className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-slate-500 uppercase">
            Total Outstanding Receivables Across Batches
          </span>
          <div className="text-2xl md:text-3xl font-black text-rose-600 font-mono mt-1">
            PKR {totalDefaulterAmount.toLocaleString()}
          </div>
        </div>
        <div className="text-right text-xs text-slate-400">
          <div>Defaulter Students: {filtered.length}</div>
          <div className="font-bold text-amber-600">Recovery Campaign Active</div>
        </div>
      </div>

      {/* Search & Batch Filters */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search defaulters by roll no, student name, or voucher..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Cohort Filter:</span>
          <select
            value={batchFilter}
            onChange={(e) => setBatchFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none"
          >
            <option value="All">All Batches</option>
            {state.batches.map((b) => (
              <option key={b.id} value={b.batchName}>
                {b.batchName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Defaulters Roster */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm overflow-x-auto">
        {filtered.length === 0 ? (
          <div className="py-12 text-center text-slate-400">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            <p className="text-sm font-semibold text-slate-700">Excellent! No overdue fee defaulters.</p>
            <p className="text-xs text-slate-400 mt-1">All issued student vouchers are up to date.</p>
          </div>
        ) : (
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Roll No</th>
                <th className="p-3">Student Name</th>
                <th className="p-3">Batch</th>
                <th className="p-3">Voucher Ref</th>
                <th className="p-3">Overdue Month</th>
                <th className="p-3 text-right">Pending Dues</th>
                <th className="p-3 text-center">Dispatch Reminders</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((item) => (
                <tr key={item.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition-colors">
                  <td className="p-3 font-mono font-bold text-indigo-700">{item.rollNo}</td>
                  <td className="p-3 font-bold text-slate-900">{item.studentName}</td>
                  <td className="p-3 text-slate-600">{item.batch}</td>
                  <td className="p-3 font-mono text-slate-500">{item.voucherNo}</td>
                  <td className="p-3 font-semibold text-slate-800">{item.month}</td>
                  <td className="p-3 text-right font-mono font-black text-rose-600 text-sm">
                    PKR {item.netPayable.toLocaleString()}
                  </td>
                  <td className="p-3 text-center">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleSendWhatsApp(item)}
                        className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-[10px] rounded-lg shadow-sm flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <MessageSquare className="w-3 h-3" />
                        WhatsApp
                      </button>
                      <button
                        type="button"
                        onClick={() => handleSendSMS(item)}
                        className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[10px] rounded-lg shadow-sm flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Phone className="w-3 h-3" />
                        SMS
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* PRINT ALL DEFAULTERS */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Official Fee Defaulters Notice (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('defaulters-print-table', 'TaleemOS_Defaulters_List')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="defaulters-print-table">
              <LetterheadPrint
                title="OFFICIAL INSTITUTIONAL FEE ARREARS & DEFAULTERS NOTICE"
                documentNo="DEFAULTER-NOTICE-2026"
                summaryStats={[
                  { label: 'Defaulter Students', value: filtered.length },
                  { label: 'Outstanding Arrears', value: `PKR ${totalDefaulterAmount.toLocaleString()}` },
                  { label: 'Clearing Deadline', value: '28th Oct 2026' },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Roll No</th>
                      <th className="border border-slate-300 p-2">Student Name</th>
                      <th className="border border-slate-300 p-2">Batch</th>
                      <th className="border border-slate-300 p-2">Voucher Ref</th>
                      <th className="border border-slate-300 p-2">Month</th>
                      <th className="border border-slate-300 p-2 text-right">Arrears Dues</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((v) => (
                      <tr key={v.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-rose-700">{v.rollNo}</td>
                        <td className="border border-slate-300 p-2 font-bold">{v.studentName}</td>
                        <td className="border border-slate-300 p-2">{v.batch}</td>
                        <td className="border border-slate-300 p-2 font-mono">{v.voucherNo}</td>
                        <td className="border border-slate-300 p-2">{v.month}</td>
                        <td className="border border-slate-300 p-2 text-right font-mono font-bold text-rose-700">
                          PKR {v.netPayable.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DefaultersModule;
