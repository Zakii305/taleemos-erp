import React, { useState } from 'react';
import { CreditCard, Plus, Printer, Download, Search, Upload, CheckCircle, Clock, Trash2 } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type Expense, type ApprovalRequest } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';
import { uploadToCloudinary } from '../lib/cloudinary';

export const ExpensesModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);
  const [isUploadingBill, setIsUploadingBill] = useState(false);

  // Form fields
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Expense['category']>('Utility');
  const [amount, setAmount] = useState(15000);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentMode, setPaymentMode] = useState<Expense['paymentMode']>('Bank');
  const [billUrl, setBillUrl] = useState('');
  const [remarks, setRemarks] = useState('');

  const totalExpense = state.expenses
    .filter((e) => e.status === 'Approved')
    .reduce((sum, e) => sum + e.amount, 0);

  const filtered = state.expenses.filter((e) => {
    const matchSearch =
      e.title.toLowerCase().includes(search.toLowerCase()) ||
      e.remarks.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === 'All' || e.category === categoryFilter;
    return matchSearch && matchCat;
  });

  const handleBillUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsUploadingBill(true);
      try {
        const url = await uploadToCloudinary(e.target.files[0]);
        setBillUrl(url);
      } catch (err) {
        console.error('Bill upload failed:', err);
      } finally {
        setIsUploadingBill(false);
      }
    }
  };

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    const numAmount = Number(amount);
    const expId = `EXP-${Date.now().toString().slice(-4)}`;

    // If amount > 5000, Accountant triggers Director approval queue
    const requiresApproval = numAmount > 5000;
    const initialStatus: Expense['status'] = requiresApproval ? 'Pending Approval' : 'Approved';

    const newExpense: Expense = {
      id: expId,
      title,
      category,
      amount: numAmount,
      date,
      paymentMode,
      receiptUrl: billUrl,
      status: initialStatus,
      approvedBy: requiresApproval ? 'Awaiting Director Sanction (> 5000)' : state.userName,
      recordedBy: state.userName,
      remarks,
    };

    erpStorage.addItem('expenses', newExpense);

    if (requiresApproval) {
      const approvalReq: ApprovalRequest = {
        id: `APP-${Date.now().toString().slice(-4)}`,
        module: 'Expense > 5000',
        recordId: expId,
        title: `Expense Requisition: ${title} (PKR ${numAmount.toLocaleString()})`,
        requestedBy: state.userName,
        requestedRole: state.activeRole,
        currentApproverRole: 'Director / Owner',
        amountOrValue: `PKR ${numAmount.toLocaleString()}`,
        status: 'Pending Approval',
        date,
        reason: remarks || 'Institutional operating expenditure exceeding PKR 5,000 threshold.',
        history: [
          {
            actor: state.userName,
            role: state.activeRole,
            action: 'Created',
            timestamp: new Date().toLocaleString(),
          },
        ],
      };
      erpStorage.addItem('approvals', approvalReq);
    }

    setIsAddModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setTitle('');
    setAmount(15000);
    setBillUrl('');
    setRemarks('');
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this expense voucher?')) {
      erpStorage.deleteItem('expenses', id);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-rose-600 rounded-xl">
              <CreditCard className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Institutional Expenses ERP</h1>
            <span className="px-2 py-0.5 bg-rose-500 text-white font-black text-[10px] rounded uppercase">
              DISBURSEMENTS
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Operational overheads, utility bills, Cloudinary receipts, and Director authorization workflow.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Ledger
          </button>
          <button
            type="button"
            onClick={() => {
              resetForm();
              setIsAddModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-rose-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Record Expense
          </button>
        </div>
      </div>

      {/* KPI */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-slate-500 uppercase">
            Total Approved Fiscal Disbursements
          </span>
          <div className="text-2xl md:text-3xl font-black text-rose-600 font-mono mt-1">
            PKR {totalExpense.toLocaleString()}
          </div>
        </div>
        <div className="text-right text-xs text-slate-400">
          <div>Strict Threshold: Expenses &gt; PKR 5,000</div>
          <div className="font-bold text-indigo-600">Routed to Director for Approval</div>
        </div>
      </div>

      {/* Search & Categories */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search expenses by invoice title, remarks..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
            Category:
          </span>
          {['All', 'Rent', 'Salary', 'Utility', 'Stationery', 'Maintenance'].map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategoryFilter(c)}
              className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                categoryFilter === c
                  ? 'bg-rose-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Expense Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="px-2.5 py-0.5 text-xs font-bold rounded-lg bg-rose-50 text-rose-700">
                  {item.category}
                </span>
                <span
                  className={`px-2.5 py-0.5 text-[10px] font-black rounded-full uppercase ${
                    item.status === 'Approved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {item.status}
                </span>
              </div>

              <h3 className="mt-2 text-base font-extrabold text-slate-900">{item.title}</h3>
              <div className="mt-1 text-xl font-black text-rose-600 font-mono">
                PKR {item.amount.toLocaleString()}
              </div>

              <div className="mt-3 space-y-1 text-xs text-slate-600">
                <div>Date: <span className="font-mono">{item.date}</span></div>
                <div>Payment Mode: <strong className="text-slate-800">{item.paymentMode}</strong></div>
                <div>Authorized By: <span className="text-slate-700">{item.approvedBy}</span></div>
                {item.remarks && (
                  <p className="text-[11px] text-slate-500 italic bg-slate-50 p-2 rounded-lg mt-1">
                    &ldquo;{item.remarks}&rdquo;
                  </p>
                )}
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono text-[10px]">{item.id}</span>
              <button
                type="button"
                onClick={(e) => handleDelete(item.id, e)}
                className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* RECORD EXPENSE MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Record Institutional Expenditure"
        subtitle="Automatic escalation for Director authorization if > PKR 5,000"
        badge="DISBURSEMENT"
      >
        <form onSubmit={handleCreateExpense} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Expense Title / Purpose *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Science Lab Reagent Restocking"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-rose-600"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Expense['category'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Rent">Campus Building Rent</option>
                <option value="Salary">Faculty / Staff Salary</option>
                <option value="Utility">PTCL / Electricity / Water</option>
                <option value="Stationery">Printing & Exam Papers</option>
                <option value="Maintenance">Lab & IT Maintenance</option>
                <option value="Marketing">Marketing / Prospectus</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Disbursement Amount (PKR) *
              </label>
              <input
                type="number"
                required
                min={1}
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs font-mono font-bold outline-none"
              />
              {amount > 5000 && (
                <span className="text-[10px] text-amber-700 font-bold block mt-1">
                  ⚠️ Amount exceeds PKR 5,000. Will require Director authorization before clearance.
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Disbursement Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Payment Mode</label>
              <select
                value={paymentMode}
                onChange={(e) => setPaymentMode(e.target.value as Expense['paymentMode'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Cash">Cash</option>
                <option value="Bank">Direct Bank Transfer</option>
                <option value="Cheque">Crossed Cheque</option>
              </select>
            </div>
          </div>

          {/* Cloudinary Bill Photo Upload */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Bill / Invoice Receipt (Cloudinary Direct Integration)
            </label>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer transition-colors">
                <Upload className="w-4 h-4 text-rose-600" />
                <span>{isUploadingBill ? 'Uploading to Cloudinary...' : 'Upload Bill Photo'}</span>
                <input type="file" accept="image/*" onChange={handleBillUpload} className="hidden" />
              </label>
              {billUrl && (
                <div className="flex items-center gap-2">
                  <img src={billUrl} alt="Bill" className="w-9 h-9 rounded-lg object-cover border" />
                  <span className="text-xs text-emerald-600 font-semibold">Bill Attached!</span>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Vendor & Invoice Remarks
            </label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="Vendor invoice number, voucher notes..."
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
            />
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-black rounded-xl shadow-lg shadow-rose-600/30 cursor-pointer"
            >
              Submit Voucher
            </button>
          </div>
        </form>
      </Modal>

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Institutional Expenses Ledger (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('expenses-print-table', 'TaleemOS_Expenses_Ledger')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="expenses-print-table">
              <LetterheadPrint
                title="INSTITUTIONAL OPERATING EXPENDITURES AUDIT LEDGER"
                documentNo="EXP-LEDGER-2026"
                summaryStats={[
                  { label: 'Total Vouchers', value: state.expenses.length },
                  { label: 'Approved Total', value: `PKR ${totalExpense.toLocaleString()}` },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Voucher</th>
                      <th className="border border-slate-300 p-2">Title</th>
                      <th className="border border-slate-300 p-2">Category</th>
                      <th className="border border-slate-300 p-2">Date</th>
                      <th className="border border-slate-300 p-2">Mode</th>
                      <th className="border border-slate-300 p-2 text-right">Amount</th>
                      <th className="border border-slate-300 p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((e) => (
                      <tr key={e.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-rose-700">{e.id}</td>
                        <td className="border border-slate-300 p-2 font-bold">{e.title}</td>
                        <td className="border border-slate-300 p-2">{e.category}</td>
                        <td className="border border-slate-300 p-2 font-mono">{e.date}</td>
                        <td className="border border-slate-300 p-2">{e.paymentMode}</td>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-right text-rose-700">
                          PKR {e.amount.toLocaleString()}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold">{e.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpensesModule;
