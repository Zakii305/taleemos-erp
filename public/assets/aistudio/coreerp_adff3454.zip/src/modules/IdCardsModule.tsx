import React, { useState } from 'react';
import { IdCard, Printer, Download, Filter, Search, QrCode } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const IdCardsModule: React.FC = () => {
  const state = erpStorage.getState();
  const [batchFilter, setBatchFilter] = useState('All');
  const [search, setSearch] = useState('');

  const filteredStudents = state.students.filter((s) => {
    const matchSearch =
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.rollNo.toLowerCase().includes(search.toLowerCase()) ||
      s.fatherName.toLowerCase().includes(search.toLowerCase());
    const matchBatch = batchFilter === 'All' || s.classBatch === batchFilter;
    return matchSearch && matchBatch;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <IdCard className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Student ID Cards Generator</h1>
            <span className="px-2 py-0.5 bg-amber-400 text-slate-950 font-black text-[10px] rounded uppercase">
              A4 8-UP PRO
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Printable 8 cards per standard A4 sheet with QR code, Cloudinary photos, and institutional barcodes.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => triggerBrowserPrint()}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print 8-Card Sheet (A4)
          </button>
          <button
            type="button"
            onClick={() => downloadElementAsPdf('id-cards-sheet', 'TaleemAcademy_Student_ID_Cards')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Download className="w-4 h-4" />
            Download PDF
          </button>
        </div>
      </div>

      {/* Filter row */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4 no-print">
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter cards by student name, roll number, or father..."
            className="w-full text-xs text-slate-800 placeholder-slate-400 outline-none"
          />
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Batch:</span>
          <select
            value={batchFilter}
            onChange={(e) => setBatchFilter(e.target.value)}
            className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none"
          >
            <option value="All">All Batches</option>
            {state.batches.map((b) => (
              <option key={b.id} value={b.batchName}>
                {b.batchName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 8-Card Printable Grid (A4 layout) */}
      <div id="id-cards-sheet" className="p-4 md:p-6 bg-slate-100 rounded-[22px] print:bg-white print:p-0">
        <div className="text-center mb-4 print:hidden">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Displaying {filteredStudents.length} cards (Rendered 2 columns x 4 rows per page)
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 print:grid-cols-2 print:gap-3 max-w-[800px] mx-auto">
          {filteredStudents.map((s) => (
            <div
              key={s.id}
              className="w-full bg-white rounded-2xl border-2 border-indigo-900/40 shadow-md p-4 flex flex-col justify-between overflow-hidden relative print:shadow-none print:border print:border-slate-800 print:page-break-inside-avoid print:rounded-xl"
            >
              {/* Card top banner */}
              <div className="flex items-center justify-between border-b border-indigo-900/20 pb-2">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-indigo-950 text-white font-black text-xs flex items-center justify-center">
                    TA
                  </div>
                  <div>
                    <h5 className="text-[11px] font-black tracking-tight text-slate-900 uppercase leading-none">
                      Taleem Academy
                    </h5>
                    <span className="text-[8px] font-semibold text-indigo-700">Kandhkot Campus</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 bg-indigo-50 border border-indigo-200 text-indigo-800 text-[8px] font-black rounded uppercase">
                  STUDENT ID
                </span>
              </div>

              {/* Card Body */}
              <div className="flex items-center gap-3 my-2.5">
                <img
                  src={s.photoUrl}
                  alt={s.name}
                  className="w-16 h-16 rounded-xl object-cover border-2 border-indigo-600 shadow shrink-0"
                />

                <div className="text-xs min-w-0 flex-1">
                  <h4 className="font-black text-slate-900 text-sm leading-snug truncate">{s.name}</h4>
                  <div className="text-[10px] text-slate-500 truncate">S/O {s.fatherName}</div>
                  <div className="text-[10px] text-indigo-800 font-bold mt-0.5 truncate">{s.classBatch}</div>
                  <div className="text-[10px] font-mono text-slate-700 flex items-center justify-between mt-1">
                    <span>
                      Roll: <strong className="text-indigo-900">{s.rollNo}</strong>
                    </span>
                    <span className="text-rose-600 font-bold">Blood: {s.bloodGroup}</span>
                  </div>
                </div>
              </div>

              {/* Card Footer with QR & Signature */}
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[8px] text-slate-500">
                {/* QR block */}
                <div className="flex items-center gap-1.5">
                  <div className="w-8 h-8 bg-slate-900 p-0.5 text-white flex items-center justify-center rounded">
                    <QrCode className="w-7 h-7 text-white" />
                  </div>
                  <div>
                    <div className="font-mono text-[8px] text-slate-700 font-bold">Session 2026-27</div>
                    <div className="text-[7px] text-slate-400">Valid: Jun 2027</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="w-16 border-b border-slate-400 border-dashed mb-0.5" />
                  <span className="font-bold text-slate-700">Principal Sign</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default IdCardsModule;
