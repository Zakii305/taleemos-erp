/**
 * Academy and User Management Service for Multi-Tenant Hierarchy
 * Collections:
 * - users/{userId}: { uid, email, name, role, academyId, academyName, status, createdAt, phone }
 * - academies/{academyId}: { academyId, academyName, code, address, phone, adminId, adminName, adminEmail, createdBy, createdAt, isActive }
 */

import { db } from './firebase';
import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  query,
  where,
  addDoc,
} from 'firebase/firestore';
import { type Academy, type AppUser, type UserRole } from '../types';

export const DEV_EMAILS = [
  'developer@hisaabkitaab.com',
  'socialman121@gmail.com',
  'sajjadaliqasmi@gmail.com',
];

// Initial seeded academies
export const DEFAULT_ACADEMIES: Academy[] = [
  {
    academyId: 'inst-1',
    academyName: 'Taleem Academy Main Campus (Kandhkot)',
    code: 'TAK-01',
    address: 'Station Road, Near Post Office, Kandhkot, Sindh',
    phone: '0300-1234567',
    adminId: 'usr-admin-1',
    adminName: 'Prof. Ghulam Rasool',
    adminEmail: 'admin.kandhkot@taleemacademy.edu.pk',
    createdBy: 'developer@hisaabkitaab.com',
    createdAt: Date.now() - 30 * 86400000,
    isActive: true,
  },
  {
    academyId: 'inst-2',
    academyName: 'Taleem Academy Sukkur City Campus',
    code: 'TSK-02',
    address: 'Military Road, Sukkur, Sindh',
    phone: '0301-9876543',
    adminId: 'usr-admin-2',
    adminName: 'Dr. Tariq Mehmood',
    adminEmail: 'admin.sukkur@taleemacademy.edu.pk',
    createdBy: 'developer@hisaabkitaab.com',
    createdAt: Date.now() - 20 * 86400000,
    isActive: true,
  },
  {
    academyId: 'inst-3',
    academyName: 'Taleem Academy Kashmore Campus',
    code: 'TGK-03',
    address: 'Indus Highway, Kashmore, Sindh',
    phone: '0302-5551234',
    adminId: 'usr-admin-3',
    adminName: 'Engr. Farhan Soomro',
    adminEmail: 'admin.kashmore@taleemacademy.edu.pk',
    createdBy: 'developer@hisaabkitaab.com',
    createdAt: Date.now() - 10 * 86400000,
    isActive: true,
  },
];

// Helper to get local stored academies
export function getLocalAcademies(): Academy[] {
  try {
    const saved = localStorage.getItem('taleemos_academies');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  localStorage.setItem('taleemos_academies', JSON.stringify(DEFAULT_ACADEMIES));
  return DEFAULT_ACADEMIES;
}

export function saveLocalAcademies(academies: Academy[]) {
  localStorage.setItem('taleemos_academies', JSON.stringify(academies));
}

// Helper to get local stored users
export function getLocalUsers(): AppUser[] {
  try {
    const saved = localStorage.getItem('taleemos_users_collection');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return [];
}

export function saveLocalUsers(users: AppUser[]) {
  localStorage.setItem('taleemos_users_collection', JSON.stringify(users));
}

/**
 * Fetch all active academies from Firestore (falls back to localStorage)
 */
export async function fetchActiveAcademies(): Promise<Academy[]> {
  const local = getLocalAcademies();
  if (!db) return local.filter((a) => a.isActive);

  try {
    const q = query(collection(db, 'academies'), where('isActive', '==', true));
    const snap = await getDocs(q);
    if (!snap.empty) {
      const remote = snap.docs.map((d) => ({ ...d.data(), academyId: d.id } as Academy));
      saveLocalAcademies(remote);
      return remote;
    }
  } catch (err) {
    console.warn('Firestore fetchActiveAcademies offline fallback:', err);
  }
  return local.filter((a) => a.isActive);
}

/**
 * Create a new Academy (Developer role only)
 */
export async function createAcademy(
  academyData: Omit<Academy, 'createdAt' | 'isActive'>,
  developerId: string
): Promise<Academy> {
  const newAcademy: Academy = {
    ...academyData,
    createdBy: developerId,
    createdAt: Date.now(),
    isActive: true,
  };

  // Save to Firestore
  if (db) {
    try {
      await setDoc(doc(db, 'academies', newAcademy.academyId), newAcademy);
    } catch (err) {
      console.warn('Firestore createAcademy offline:', err);
    }
  }

  // Save locally
  const current = getLocalAcademies();
  const updated = [newAcademy, ...current.filter((a) => a.academyId !== newAcademy.academyId)];
  saveLocalAcademies(updated);

  return newAcademy;
}

/**
 * Register a new User Account
 */
export async function registerUserAccount(user: {
  uid: string;
  email: string;
  name: string;
  role: UserRole;
  academyId: string | null;
  academyName: string;
  phone?: string;
  password?: string;
}): Promise<AppUser> {
  const isDev = DEV_EMAILS.includes(user.email.toLowerCase()) || user.role === 'developer';

  const newUser: AppUser = {
    uid: user.uid || `usr-${Date.now()}`,
    id: user.uid || `usr-${Date.now()}`,
    email: user.email.toLowerCase().trim(),
    name: user.name.trim(),
    role: isDev ? 'developer' : (user.role as any),
    academyId: isDev ? null : user.academyId,
    academyName: isDev ? 'Global Multi-Academy Network' : user.academyName,
    status: isDev ? 'approved' : 'pending',
    createdAt: Date.now(),
    phone: user.phone?.trim() || '',
  };

  // Sync with Firestore
  if (db) {
    try {
      await setDoc(doc(db, 'users', newUser.uid), newUser);
    } catch (err) {
      console.warn('Firestore registerUserAccount offline:', err);
    }
  }

  // Sync locally
  const localUsers = getLocalUsers();
  const updated = [...localUsers.filter((u) => u.email !== newUser.email), newUser];
  saveLocalUsers(updated);

  return newUser;
}

/**
 * Query user account by email
 */
export async function getUserAccountByEmail(email: string): Promise<AppUser | null> {
  const cleanEmail = email.toLowerCase().trim();

  // Check Developer hardcoded override
  if (DEV_EMAILS.includes(cleanEmail)) {
    return {
      uid: 'dev-master',
      id: 'dev-master',
      email: cleanEmail,
      name: 'Super Developer / Chief Architect',
      role: 'developer',
      academyId: null,
      academyName: 'All Academies Network',
      status: 'approved',
      createdAt: Date.now(),
    };
  }

  // Check Firestore
  if (db) {
    try {
      const q = query(collection(db, 'users'), where('email', '==', cleanEmail));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs[0].data() as AppUser;
      }
    } catch (err) {
      console.warn('Firestore getUserAccountByEmail offline:', err);
    }
  }

  // Check local users
  const localUsers = getLocalUsers();
  return localUsers.find((u) => u.email.toLowerCase() === cleanEmail) || null;
}

/**
 * Developer view: Get all pending Admin registrations
 */
export async function getPendingAdmins(): Promise<AppUser[]> {
  if (db) {
    try {
      const q = query(
        collection(db, 'users'),
        where('role', '==', 'admin'),
        where('status', '==', 'pending')
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map((d) => d.data() as AppUser);
      }
    } catch (err) {
      console.warn('Firestore getPendingAdmins offline:', err);
    }
  }

  const local = getLocalUsers();
  return local.filter((u) => u.role === 'admin' && u.status === 'pending');
}

/**
 * Admin view: Get all pending Teachers, Students, and Parents for his own academy
 */
export async function getPendingAcademyMembers(academyId: string): Promise<AppUser[]> {
  if (db) {
    try {
      const q = query(
        collection(db, 'users'),
        where('academyId', '==', academyId),
        where('status', '==', 'pending')
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs
          .map((d) => d.data() as AppUser)
          .filter((u) => u.role !== 'admin' && u.role !== 'developer');
      }
    } catch (err) {
      console.warn('Firestore getPendingAcademyMembers offline:', err);
    }
  }

  const local = getLocalUsers();
  return local.filter(
    (u) =>
      u.academyId === academyId &&
      u.role !== 'admin' &&
      u.role !== 'developer' &&
      u.status === 'pending'
  );
}

/**
 * Approve or Reject a user account
 */
export async function setUserApprovalStatus(
  userId: string,
  newStatus: 'approved' | 'rejected',
  allottedAcademyId?: string
): Promise<void> {
  const updates: Partial<AppUser> = { status: newStatus };
  if (allottedAcademyId) {
    updates.academyId = allottedAcademyId;
  }

  // Update Firestore
  if (db) {
    try {
      await updateDoc(doc(db, 'users', userId), updates);
    } catch (err) {
      console.warn('Firestore setUserApprovalStatus offline:', err);
    }
  }

  // Update local users
  const local = getLocalUsers();
  const updated = local.map((u) => (u.uid === userId || u.id === userId ? { ...u, ...updates } : u));
  saveLocalUsers(updated);
}
