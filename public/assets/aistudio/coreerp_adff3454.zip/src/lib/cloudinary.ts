/**
 * Cloudinary Unsigned Upload Flow
 * Cloud Name: h79njj6q
 * Primary Preset: TaleemOS (Unsigned)
 * Secondary Backup Preset: IskoolApp (Unsigned)
 * Unsigned upload endpoint: https://api.cloudinary.com/v1_1/h79njj6q/image/upload
 * No secret keys are exposed on the frontend.
 */

export const CLOUDINARY_CLOUD_NAME = 'h79njj6q';
export const CLOUDINARY_PRIMARY_PRESET = 'TaleemOS';
export const CLOUDINARY_BACKUP_PRESET = 'IskoolApp';
export const CLOUDINARY_UPLOAD_PRESET = CLOUDINARY_PRIMARY_PRESET;
export const CLOUDINARY_UPLOAD_URL = `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/image/upload`;

export interface CloudinaryUploadResult {
  secure_url: string;
  public_id: string;
  format: string;
  bytes: number;
  width?: number;
  height?: number;
}

/**
 * Upload an image file to Cloudinary using unsigned upload preset
 * Attempts primary preset 'TaleemOS', falls back to 'IskoolApp', and falls back to Base64 if offline.
 */
export async function uploadToCloudinary(file: File): Promise<string> {
  // Offline or network unavailable fallback to instant Base64 data URL
  if (!navigator.onLine) {
    return fileToBase64(file);
  }

  // Attempt 1: Primary preset 'TaleemOS'
  try {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', CLOUDINARY_PRIMARY_PRESET);

    const response = await fetch(CLOUDINARY_UPLOAD_URL, {
      method: 'POST',
      body: formData,
    });

    if (response.ok) {
      const data: CloudinaryUploadResult = await response.json();
      if (data.secure_url) {
        return data.secure_url;
      }
    }
  } catch (err) {
    console.warn(`Primary preset ${CLOUDINARY_PRIMARY_PRESET} upload issue, trying backup preset:`, err);
  }

  // Attempt 2: Secondary backup preset 'IskoolApp'
  try {
    const backupData = new FormData();
    backupData.append('file', file);
    backupData.append('upload_preset', CLOUDINARY_BACKUP_PRESET);

    const response = await fetch(CLOUDINARY_UPLOAD_URL, {
      method: 'POST',
      body: backupData,
    });

    if (response.ok) {
      const data: CloudinaryUploadResult = await response.json();
      if (data.secure_url) {
        return data.secure_url;
      }
    }
  } catch (err) {
    console.warn(`Secondary preset ${CLOUDINARY_BACKUP_PRESET} upload issue, falling back to local data URL:`, err);
  }

  // Fallback: Local Base64 preview
  return fileToBase64(file);
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      resolve(reader.result as string);
    };
    reader.readAsDataURL(file);
  });
}
