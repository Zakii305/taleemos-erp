import React, { useState } from 'react';
import {
  Users,
  Plus,
  Printer,
  Download,
  Search,
  Phone,
  FileText,
  Upload,
  CreditCard,
  ArrowUpRight,
  Trash2,
  Edit2,
  DollarSign,
  IdCard,
} from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type Student } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';
import { uploadToCloudinary } from '../lib/cloudinary';

interface StudentsModuleProps {
  onNavigate: (path: string) => void;
}

export const StudentsModule: React.FC<StudentsModuleProps> = ({ onNavigate }) => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [batchFilter, setBatchFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);

  // Form fields
  const [name, setName] = useState('');
  const [fatherName, setFatherName] = useState('');
  const [classBatch, setClassBatch] = useState('Batch 2026-A (Morning)');
  const [course, setCourse] = useState('F.Sc Pre-Engineering');
  const [phone, setPhone] = useState('');
  const [cnic, setCnic] = useState('');
  const [address, setAddress] = useState('');
  const [bloodGroup, setBloodGroup] = useState('B+');
  const [gender, setGender] = useState<Student['gender']>('Male');
  const [photoUrl, setPhotoUrl] = useState('');
  const [admissionDate, setAdmissionDate] = useState(new Date().toISOString().split('T')[0]);

  // KPIs
  const totalStudents = state.students.length;
  const activeStudents = state.students.filter((s) => s.status === 'Active').length;
  const maleCount = state.students.filter((s) => s.gender === 'Male').length;
  const femaleCount = state.students.filter((s) => s.gender === 'Female').length;

  const filtered = state.students.filter((s) => {
    const matchSearch =
      s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.rollNo.toLowerCase().includes(search.toLowerCase()) ||
      s.fatherName.toLowerCase().includes(search.toLowerCase()) ||
      s.cnic.includes(search) ||
      s.phone.includes(search);
    const matchBatch = batchFilter === 'All' || s.classBatch === batchFilter;
    const matchStatus = statusFilter === 'All' || s.status === statusFilter;
    return matchSearch && matchBatch && matchStatus;
  });

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setIsUploadingPhoto(true);
      try {
        const url = await uploadToCloudinary(e.target.files[0]);
        setPhotoUrl(url);
      } catch (err) {
        console.error('Photo upload failed:', err);
      } finally {
        setIsUploadingPhoto(false);
      }
    }
  };

  const handleCreateStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !fatherName.trim() || !phone.trim()) return;

    const nextRoll = `TAK-26-${String(state.students.length + 1).padStart(3, '0')}`;
    const newStudent: Student = {
      id: `STU-${Date.now().toString().slice(-4)}`,
      rollNo: nextRoll,
      name,
      fatherName,
      classBatch,
      course,
      phone,
      cnic: cnic || '43102-XXXXXXX-X',
      admissionDate,
      status: 'Active',
      photoUrl:
        photoUrl ||
        (gender === 'Female'
          ? 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80'
          : 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200&auto=format&fit=crop&q=80'),
      documents: [],
      address: address || 'Kandhkot, Sindh',
      bloodGroup,
      gender,
      feePaidTotal: 0,
      feePendingTotal: 0,
    };

    erpStorage.addItem('students', newStudent);
    setIsAddModalOpen(false);
    resetForm();
  };

  const resetForm = () => {
    setName('');
    setFatherName('');
    setPhone('');
    setCnic('');
    setAddress('');
    setPhotoUrl('');
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete student record from directory?')) {
      erpStorage.deleteItem('students', id);
      if (selectedStudent?.id === id) setSelectedStudent(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <Users className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Students Directory</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              REGISTRY
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Student master records, roll numbers, Cloudinary photo archive, and fee history linkages.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print All
          </button>
          <button
            type="button"
            onClick={() => onNavigate('id-cards')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-indigo-700 hover:bg-indigo-600 active:scale-95 text-white text-xs font-bold rounded-xl transition-all cursor-pointer"
          >
            <IdCard className="w-4 h-4" />
            Bulk ID Cards
          </button>
          <button
            type="button"
            onClick={() => {
              resetForm();
              setIsAddModalOpen(true);
            }}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add Student
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Total Registered</div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">{totalStudents}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-emerald-600 uppercase">Active Students</div>
          <div className="text-2xl font-black text-emerald-600 font-mono mt-1">{activeStudents}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-blue-500 uppercase">Male Students</div>
          <div className="text-2xl font-black text-blue-600 font-mono mt-1">{maleCount}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-purple-500 uppercase">Female Students</div>
          <div className="text-2xl font-black text-purple-600 font-mono mt-1">{femaleCount}</div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Roll No (TAK-26-001), name, father, phone, or CNIC..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
            Batch:
          </span>
          {['All', 'Batch 2026-A (Morning)', 'Batch 2026-B (Morning)', 'Batch 2026-C (Afternoon)'].map(
            (b) => (
              <button
                key={b}
                type="button"
                onClick={() => setBatchFilter(b)}
                className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                  batchFilter === b
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {b}
              </button>
            )
          )}
        </div>
      </div>

      {/* Student Cards (Tappable to Detail Modal) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((s) => (
          <div
            key={s.id}
            onClick={() => setSelectedStudent(s)}
            className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="px-2.5 py-0.5 text-xs font-mono font-black bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200">
                  {s.rollNo}
                </span>
                <span className="px-2 py-0.2 bg-emerald-100 text-emerald-800 text-[10px] font-black rounded-full uppercase">
                  {s.status}
                </span>
              </div>

              <div className="mt-3 flex items-start gap-3">
                <img
                  src={s.photoUrl}
                  alt={s.name}
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-indigo-100 shrink-0"
                />
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">{s.name}</h3>
                  <p className="text-xs text-slate-500 font-semibold">S/O {s.fatherName}</p>
                  <p className="text-[11px] text-slate-400 font-mono mt-0.5">{s.classBatch}</p>
                </div>
              </div>

              <div className="mt-3 pt-3 border-t border-slate-100 space-y-1 text-xs text-slate-600">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Phone:</span>
                  <span className="font-mono font-bold">{s.phone}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Blood Group:</span>
                  <span className="font-bold text-rose-600">{s.bloodGroup}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Fee Status:</span>
                  <span className="font-bold text-emerald-600">PKR {s.feePaidTotal} Paid</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onNavigate('fees');
                }}
                className="text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1"
              >
                <DollarSign className="w-3.5 h-3.5" />
                <span>Fees History</span>
              </button>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={(e) => handleDelete(s.id, e)}
                  className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                  title="Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* ADD STUDENT MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Student Directory Record"
        subtitle="Generates unique institutional Roll Number (TAK-26-XXX)"
        badge="DIRECTORY"
        maxWidth="max-w-4xl"
      >
        <form onSubmit={handleCreateStudent} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Student Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Student name"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Father Name *
              </label>
              <input
                type="text"
                required
                value={fatherName}
                onChange={(e) => setFatherName(e.target.value)}
                placeholder="Father / Guardian name"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Class / Batch *
              </label>
              <select
                value={classBatch}
                onChange={(e) => setClassBatch(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                {state.batches.map((b) => (
                  <option key={b.id} value={b.batchName}>
                    {b.batchName}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Course</label>
              <select
                value={course}
                onChange={(e) => setCourse(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                {state.courses.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as Student['gender'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Contact Phone *
              </label>
              <input
                type="tel"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+92 300 0000000"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                CNIC / B-Form
              </label>
              <input
                type="text"
                value={cnic}
                onChange={(e) => setCnic(e.target.value)}
                placeholder="43102-XXXXXXX-X"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Blood Group
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                  <option key={bg} value={bg}>
                    {bg}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Residential Address
            </label>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="Full address in Kandhkot or surrounding areas"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
            />
          </div>

          {/* Cloudinary Student Photo upload */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Student Photo (Cloudinary Direct Integration)
            </label>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold cursor-pointer transition-colors">
                <Upload className="w-4 h-4 text-indigo-600" />
                <span>{isUploadingPhoto ? 'Uploading to Cloudinary...' : 'Upload Student Photo'}</span>
                <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
              </label>
              {photoUrl && (
                <div className="flex items-center gap-2">
                  <img src={photoUrl} alt="Preview" className="w-9 h-9 rounded-lg object-cover border" />
                  <span className="text-xs text-emerald-600 font-semibold">Photo Attached!</span>
                </div>
              )}
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Register Student
            </button>
          </div>
        </form>
      </Modal>

      {/* DETAIL MODAL + Single ID Card Print */}
      {selectedStudent && (
        <Modal
          isOpen={Boolean(selectedStudent)}
          onClose={() => setSelectedStudent(null)}
          title={`Student Profile: ${selectedStudent.name}`}
          subtitle={`Roll No: ${selectedStudent.rollNo} • Batch: ${selectedStudent.classBatch}`}
          badge={selectedStudent.status}
          maxWidth="max-w-3xl"
        >
          <div className="space-y-4">
            <div id="single-student-profile" className="p-5 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex flex-col sm:flex-row items-center gap-4 pb-4 border-b border-slate-200">
                <img
                  src={selectedStudent.photoUrl}
                  alt={selectedStudent.name}
                  className="w-20 h-20 rounded-2xl object-cover border-2 border-indigo-600 shadow-md"
                />
                <div className="text-center sm:text-left">
                  <h4 className="text-lg font-black text-slate-900">{selectedStudent.name}</h4>
                  <div className="text-xs text-slate-500 font-semibold">
                    Father: <span className="text-slate-800">{selectedStudent.fatherName}</span>
                  </div>
                  <div className="text-xs text-indigo-700 font-mono font-bold mt-1">
                    Roll No: {selectedStudent.rollNo} &bull; Blood: {selectedStudent.bloodGroup}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs mt-4">
                <div>
                  <span className="text-slate-400 block font-semibold">Course:</span>
                  <span className="font-bold text-slate-800">{selectedStudent.course}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Phone:</span>
                  <span className="font-mono font-bold text-slate-800">{selectedStudent.phone}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">CNIC:</span>
                  <span className="font-mono text-slate-800">{selectedStudent.cnic}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Address:</span>
                  <span className="text-slate-800">{selectedStudent.address}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Admitted On:</span>
                  <span className="font-mono text-slate-800">{selectedStudent.admissionDate}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Gender:</span>
                  <span className="font-bold text-slate-800">{selectedStudent.gender}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Printer className="w-4 h-4" />
                  Print Student Card
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedStudent(null);
                    onNavigate('promote');
                  }}
                  className="px-3.5 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 flex items-center gap-1 cursor-pointer"
                >
                  <ArrowUpRight className="w-3.5 h-3.5" />
                  Promote
                </button>
              </div>

              <button
                type="button"
                onClick={() => setSelectedStudent(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* PRINT ALL STUDENTS MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Students Master Directory (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('students-print-table', 'TaleemOS_Students_Directory')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="students-print-table">
              <LetterheadPrint
                title="Institutional Master Student Directory"
                documentNo="STU-DIR-2026"
                summaryStats={[
                  { label: 'Total Registered', value: totalStudents },
                  { label: 'Active Students', value: activeStudents },
                  { label: 'Male', value: maleCount },
                  { label: 'Female', value: femaleCount },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Roll No</th>
                      <th className="border border-slate-300 p-2">Student Name</th>
                      <th className="border border-slate-300 p-2">Father Name</th>
                      <th className="border border-slate-300 p-2">Batch</th>
                      <th className="border border-slate-300 p-2">Course</th>
                      <th className="border border-slate-300 p-2">Phone</th>
                      <th className="border border-slate-300 p-2">Blood</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((s) => (
                      <tr key={s.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-indigo-700">
                          {s.rollNo}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold">{s.name}</td>
                        <td className="border border-slate-300 p-2">{s.fatherName}</td>
                        <td className="border border-slate-300 p-2">{s.classBatch}</td>
                        <td className="border border-slate-300 p-2">{s.course}</td>
                        <td className="border border-slate-300 p-2 font-mono">{s.phone}</td>
                        <td className="border border-slate-300 p-2 font-bold text-rose-600">{s.bloodGroup}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
