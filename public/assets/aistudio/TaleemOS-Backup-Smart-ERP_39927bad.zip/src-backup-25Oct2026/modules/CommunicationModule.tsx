import React, { useState } from 'react';
import { MessageSquare, Plus, Printer, Download, Send, Phone, Bell, Radio, CheckCircle2 } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type CommunicationMessage } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const CommunicationModule: React.FC = () => {
  const state = erpStorage.getState();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);
  const [sentNotice, setSentNotice] = useState<string | null>(null);

  // Form fields
  const [channel, setChannel] = useState<CommunicationMessage['channel']>('WhatsApp');
  const [audience, setAudience] = useState<CommunicationMessage['audience']>('All Students');
  const [targetBatch, setTargetBatch] = useState('Batch 2026-A (Morning)');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;

    const newMsg: CommunicationMessage = {
      id: `COM-${Date.now().toString().slice(-4)}`,
      channel,
      audience,
      targetBatch: audience === 'Selected Batch' ? targetBatch : undefined,
      title,
      message,
      sentDate: new Date().toISOString().split('T')[0],
      sentBy: state.userName,
      deliveryStatus: 'Delivered',
    };

    erpStorage.addItem('communications', newMsg);
    setIsAddModalOpen(false);

    // If channel is WhatsApp, open wa.me
    if (channel === 'WhatsApp') {
      window.open(`https://wa.me/?text=${encodeURIComponent(`*${title}*\n\n${message}\n\n- Taleem Academy Kandhkot`)}`, '_blank');
    }

    setSentNotice(`Successfully broadcasted message via ${channel} to ${audience}!`);
    setTimeout(() => setSentNotice(null), 4000);

    setTitle('');
    setMessage('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <MessageSquare className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Institutional Communication Hub</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              MULTI-CHANNEL
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Bulk SMS gateways, official WhatsApp broadcasts, digital notice board, and mobile push notifications.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Dispatch Log
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            Compose Broadcast
          </button>
        </div>
      </div>

      {sentNotice && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl animate-in fade-in flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{sentNotice}</span>
        </div>
      )}

      {/* Broadcast Feed */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
          <Radio className="w-4 h-4 text-indigo-600" />
          Broadcast Outbox & Delivery Status
        </h3>

        <div className="space-y-3">
          {state.communications.map((c) => (
            <div
              key={c.id}
              className="p-4 bg-slate-50 hover:bg-white rounded-2xl border border-slate-200 transition-all flex flex-col md:flex-row md:items-start justify-between gap-3"
            >
              <div className="flex items-start gap-3">
                <div
                  className={`p-2.5 rounded-xl text-white font-black shrink-0 ${
                    c.channel === 'WhatsApp'
                      ? 'bg-emerald-600'
                      : c.channel === 'SMS'
                      ? 'bg-indigo-600'
                      : 'bg-amber-600'
                  }`}
                >
                  {c.channel === 'WhatsApp' ? (
                    <MessageSquare className="w-5 h-5" />
                  ) : c.channel === 'SMS' ? (
                    <Phone className="w-5 h-5" />
                  ) : (
                    <Bell className="w-5 h-5" />
                  )}
                </div>

                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-slate-900 text-sm">{c.title}</span>
                    <span className="px-2 py-0.2 bg-slate-200 text-slate-700 text-[10px] font-bold rounded">
                      {c.audience} {c.targetBatch ? `(${c.targetBatch})` : ''}
                    </span>
                    <span className="px-2 py-0.2 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">
                      {c.deliveryStatus}
                    </span>
                  </div>

                  <p className="mt-1.5 text-xs text-slate-700 bg-white p-3 rounded-xl border border-slate-100 leading-relaxed font-medium">
                    {c.message}
                  </p>

                  <div className="mt-2 text-[10px] text-slate-400 font-mono">
                    Channel: {c.channel} &bull; Dispatched by {c.sentBy} on {c.sentDate}
                  </div>
                </div>
              </div>

              {c.channel === 'WhatsApp' && (
                <button
                  type="button"
                  onClick={() =>
                    window.open(
                      `https://wa.me/?text=${encodeURIComponent(`*${c.title}*\n\n${c.message}\n\n- Taleem Academy Kandhkot`)}`,
                      '_blank'
                    )
                  }
                  className="px-3 py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold hover:bg-emerald-100 shrink-0 cursor-pointer"
                >
                  Re-share WhatsApp
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* COMPOSE BROADCAST MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Compose Communication Broadcast"
        subtitle="Dispatches notifications via SMS gateway or WhatsApp"
        badge="BROADCAST DISPATCH"
      >
        <form onSubmit={handleBroadcast} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Channel *</label>
              <select
                value={channel}
                onChange={(e) => setChannel(e.target.value as CommunicationMessage['channel'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="WhatsApp">WhatsApp Message</option>
                <option value="SMS">SMS Gateway</option>
                <option value="Notice Board">Digital Notice Board</option>
                <option value="Push Notification">Push Notification</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Target Audience</label>
              <select
                value={audience}
                onChange={(e) => setAudience(e.target.value as CommunicationMessage['audience'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="All Students">All Students</option>
                <option value="Selected Batch">Selected Batch Only</option>
                <option value="All Parents">All Parents</option>
                <option value="Faculty">Faculty & Staff</option>
              </select>
            </div>
          </div>

          {audience === 'Selected Batch' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Choose Batch</label>
              <select
                value={targetBatch}
                onChange={(e) => setTargetBatch(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                {state.batches.map((b) => (
                  <option key={b.id} value={b.batchName}>
                    {b.batchName}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Notice Headline *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Schedule for Science Exhibition 2026"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Message Content *</label>
            <textarea
              required
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type official notification message here..."
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
            />
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Send Broadcast
            </button>
          </div>
        </form>
      </Modal>

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Communication Dispatch Log (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('communication-print-table', 'TaleemOS_Communication_Log')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="communication-print-table">
              <LetterheadPrint
                title="INSTITUTIONAL BROADCAST & COMMUNICATION DISPATCH LOG"
                documentNo="COMM-LOG-2026"
                summaryStats={[{ label: 'Total Messages', value: state.communications.length }]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Date</th>
                      <th className="border border-slate-300 p-2">Channel</th>
                      <th className="border border-slate-300 p-2">Audience</th>
                      <th className="border border-slate-300 p-2">Headline</th>
                      <th className="border border-slate-300 p-2">Dispatched By</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.communications.map((c) => (
                      <tr key={c.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold">{c.sentDate}</td>
                        <td className="border border-slate-300 p-2 font-bold">{c.channel}</td>
                        <td className="border border-slate-300 p-2">{c.audience}</td>
                        <td className="border border-slate-300 p-2">{c.title}</td>
                        <td className="border border-slate-300 p-2">{c.sentBy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
