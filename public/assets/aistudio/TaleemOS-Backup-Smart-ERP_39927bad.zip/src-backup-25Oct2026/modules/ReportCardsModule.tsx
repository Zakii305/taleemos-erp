import React, { useState } from 'react';
import { FileCheck, Plus, Printer, Download, Search, Award, Star, User, Trash2 } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type ReportCard } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const ReportCardsModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedReport, setSelectedReport] = useState<ReportCard | null>(null);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);

  // Form
  const [studentId, setStudentId] = useState(state.students[0]?.id || '');
  const [examType, setExamType] = useState('Mid-Term Examination');
  const [sub1Name, setSub1Name] = useState('Physics');
  const [sub1Marks, setSub1Marks] = useState(85);
  const [sub2Name, setSub2Name] = useState('Mathematics');
  const [sub2Marks, setSub2Marks] = useState(90);
  const [sub3Name, setSub3Name] = useState('Chemistry');
  const [sub3Marks, setSub3Marks] = useState(80);
  const [sub4Name, setSub4Name] = useState('English');
  const [sub4Marks, setSub4Marks] = useState(78);
  const [remarks, setRemarks] = useState('Commendable performance across all disciplines.');

  const targetStudent = state.students.find((s) => s.id === studentId);

  // Auto grade helper
  const calcGrade = (pct: number): ReportCard['grade'] => {
    if (pct >= 85) return 'A+';
    if (pct >= 75) return 'A';
    if (pct >= 65) return 'B';
    if (pct >= 50) return 'C';
    if (pct >= 40) return 'D';
    return 'F';
  };

  const handleCreateReport = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetStudent) return;

    const subjectsBreakdown = [
      { subject: sub1Name, marks: Number(sub1Marks), max: 100, grade: calcGrade(Number(sub1Marks)) },
      { subject: sub2Name, marks: Number(sub2Marks), max: 100, grade: calcGrade(Number(sub2Marks)) },
      { subject: sub3Name, marks: Number(sub3Marks), max: 100, grade: calcGrade(Number(sub3Marks)) },
      { subject: sub4Name, marks: Number(sub4Marks), max: 100, grade: calcGrade(Number(sub4Marks)) },
    ];

    const totalObtained = subjectsBreakdown.reduce((sum, s) => sum + s.marks, 0);
    const maxMarks = subjectsBreakdown.length * 100;
    const percentage = Math.round((totalObtained / maxMarks) * 1000) / 10;
    const grade = calcGrade(percentage);

    const newReport: ReportCard = {
      id: `REP-${Date.now().toString().slice(-4)}`,
      rollNo: targetStudent.rollNo,
      studentName: targetStudent.name,
      fatherName: targetStudent.fatherName,
      classBatch: targetStudent.classBatch,
      examType,
      marksObtained: totalObtained,
      maxMarks,
      percentage,
      grade,
      rank: state.reportCards.length + 1,
      remarks,
      subjectsBreakdown,
    };

    erpStorage.addItem('reportCards', newReport);
    setIsAddModalOpen(false);
  };

  const filtered = state.reportCards.filter(
    (r) =>
      r.studentName.toLowerCase().includes(search.toLowerCase()) ||
      r.rollNo.toLowerCase().includes(search.toLowerCase()) ||
      r.classBatch.toLowerCase().includes(search.toLowerCase())
  );

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this official transcript?')) {
      erpStorage.deleteItem('reportCards', id);
      if (selectedReport?.id === id) setSelectedReport(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <FileCheck className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Report Cards & Transcripts PRO</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              TRANSCRIPTS
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Automated grading, percentage calculators, institutional ranks, and printable official transcripts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Ledger
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Create Transcript
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search report cards by student, roll number, or class batch..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none"
          />
        </div>
      </div>

      {/* Results Cards (Tappable to Detail Transcript) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedReport(item)}
            className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="px-2.5 py-0.5 font-mono text-xs font-black bg-indigo-50 text-indigo-700 rounded-lg">
                  {item.rollNo}
                </span>
                <span
                  className={`px-2.5 py-0.5 text-xs font-black rounded-full ${
                    item.grade === 'A+' || item.grade === 'A'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-indigo-100 text-indigo-800'
                  }`}
                >
                  Grade: {item.grade}
                </span>
              </div>

              <h3 className="mt-2 text-base font-extrabold text-slate-900">{item.studentName}</h3>
              <p className="text-xs text-slate-500">{item.classBatch}</p>

              <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200/80 grid grid-cols-3 gap-1 text-center font-mono">
                <div>
                  <span className="text-[9px] text-slate-400 uppercase block font-sans">Marks</span>
                  <span className="text-xs font-bold text-slate-800">
                    {item.marksObtained}/{item.maxMarks}
                  </span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 uppercase block font-sans">Percentage</span>
                  <span className="text-xs font-bold text-indigo-700">{item.percentage}%</span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 uppercase block font-sans">Position</span>
                  <span className="text-xs font-black text-amber-600">Rank #{item.rank}</span>
                </div>
              </div>

              <div className="mt-3 text-[11px] text-slate-500 italic bg-white p-2 rounded-lg border border-slate-100 line-clamp-2">
                &ldquo;{item.remarks}&rdquo;
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-[11px] text-slate-400 font-semibold">{item.examType}</span>
              <button
                type="button"
                onClick={(e) => handleDelete(item.id, e)}
                className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* CREATE REPORT CARD MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Generate Academic Performance Transcript"
        subtitle="Auto calculates cumulative marks, percentage, and letter grade"
        badge="AUTO GRADING"
        maxWidth="max-w-3xl"
      >
        <form onSubmit={handleCreateReport} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Candidate Student *
              </label>
              <select
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                {state.students.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.rollNo}) - {s.classBatch}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Assessment Term
              </label>
              <input
                type="text"
                value={examType}
                onChange={(e) => setExamType(e.target.value)}
                placeholder="e.g. Mid-Term Examination 2026"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
            <span className="text-xs font-bold text-slate-700 uppercase">
              Subject Papers Marks (Out of 100)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">{sub1Name}</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={sub1Marks}
                  onChange={(e) => setSub1Marks(Number(e.target.value))}
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">{sub2Name}</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={sub2Marks}
                  onChange={(e) => setSub2Marks(Number(e.target.value))}
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">{sub3Name}</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={sub3Marks}
                  onChange={(e) => setSub3Marks(Number(e.target.value))}
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 mb-1">{sub4Name}</label>
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={sub4Marks}
                  onChange={(e) => setSub4Marks(Number(e.target.value))}
                  className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Teacher / Principal Remarks
            </label>
            <input
              type="text"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Excellent problem solving skills in Mathematics."
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
            />
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Compile Transcript
            </button>
          </div>
        </form>
      </Modal>

      {/* DETAIL MODAL + OFFICIAL TRANSCRIPT PRINT */}
      {selectedReport && (
        <Modal
          isOpen={Boolean(selectedReport)}
          onClose={() => setSelectedReport(null)}
          title={`Official Transcript: ${selectedReport.studentName}`}
          subtitle={`Roll No: ${selectedReport.rollNo} • Examination: ${selectedReport.examType}`}
          badge={`Grade ${selectedReport.grade}`}
          maxWidth="max-w-4xl"
        >
          <div className="space-y-4">
            <div id="single-report-card">
              <LetterheadPrint
                title="OFFICIAL INSTITUTIONAL ACADEMIC TRANSCRIPT"
                documentNo={selectedReport.id}
                signatures={[
                  'Class Incharge / Teacher',
                  'Controller of Examinations',
                  'Principal Dr. Qureshi (Authorized)',
                ]}
              >
                <div className="space-y-4 text-xs">
                  {/* Candidate header box */}
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">CANDIDATE NAME</span>
                      <strong className="text-slate-900 text-sm uppercase">{selectedReport.studentName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">FATHER'S NAME</span>
                      <strong className="text-slate-900">{selectedReport.fatherName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">ROLL NUMBER</span>
                      <strong className="text-indigo-700 font-mono text-sm">{selectedReport.rollNo}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">CLASS / BATCH</span>
                      <strong className="text-slate-900">{selectedReport.classBatch}</strong>
                    </div>
                  </div>

                  {/* Grades Table */}
                  <table className="w-full border-collapse border border-slate-300 text-left">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-bold">
                        <th className="border border-slate-300 p-2">Subject Paper</th>
                        <th className="border border-slate-300 p-2 text-center">Maximum Marks</th>
                        <th className="border border-slate-300 p-2 text-center">Marks Obtained</th>
                        <th className="border border-slate-300 p-2 text-center">Subject Grade</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedReport.subjectsBreakdown.map((sub, i) => (
                        <tr key={i}>
                          <td className="border border-slate-300 p-2 font-bold">{sub.subject}</td>
                          <td className="border border-slate-300 p-2 text-center font-mono">{sub.max}</td>
                          <td className="border border-slate-300 p-2 text-center font-mono font-bold">
                            {sub.marks}
                          </td>
                          <td className="border border-slate-300 p-2 text-center font-bold text-indigo-700">
                            {sub.grade}
                          </td>
                        </tr>
                      ))}
                      <tr className="bg-slate-50 font-bold">
                        <td className="border border-slate-300 p-2 uppercase">Aggregate Summary</td>
                        <td className="border border-slate-300 p-2 text-center font-mono">{selectedReport.maxMarks}</td>
                        <td className="border border-slate-300 p-2 text-center font-mono font-black text-indigo-900">
                          {selectedReport.marksObtained}
                        </td>
                        <td className="border border-slate-300 p-2 text-center font-black text-emerald-700">
                          {selectedReport.grade} ({selectedReport.percentage}%)
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  {/* Remarks & Position */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">EVALUATION REMARKS</span>
                      <span className="text-slate-800 font-medium italic">&ldquo;{selectedReport.remarks}&rdquo;</span>
                    </div>
                    <div className="px-3 py-1.5 bg-amber-100 border border-amber-300 text-amber-900 font-black rounded-lg text-xs shrink-0">
                      Institutional Standing: Rank #{selectedReport.rank}
                    </div>
                  </div>
                </div>
              </LetterheadPrint>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Printer className="w-4 h-4" />
                  Print Transcript
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('single-report-card', `Transcript_${selectedReport.rollNo}`)}
                  className="px-3.5 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-700 flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Download className="w-4 h-4" />
                  Download PDF
                </button>
              </div>

              <button
                type="button"
                onClick={() => setSelectedReport(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* PRINT ALL REPORT CARDS MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Academic Results Ledger (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('reportcards-print-table', 'TaleemOS_Results_Ledger')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="reportcards-print-table">
              <LetterheadPrint
                title="Consolidated Academic Evaluation Master Sheet"
                documentNo="ACAD-GAZETTE-2026"
                summaryStats={[
                  { label: 'Transcripts Issued', value: state.reportCards.length },
                  { label: 'Academic Session', value: '2026-2027' },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Roll No</th>
                      <th className="border border-slate-300 p-2">Student Name</th>
                      <th className="border border-slate-300 p-2">Class / Batch</th>
                      <th className="border border-slate-300 p-2">Exam Term</th>
                      <th className="border border-slate-300 p-2">Marks</th>
                      <th className="border border-slate-300 p-2">Percentage</th>
                      <th className="border border-slate-300 p-2">Grade</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((r) => (
                      <tr key={r.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-indigo-700">
                          {r.rollNo}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold">{r.studentName}</td>
                        <td className="border border-slate-300 p-2">{r.classBatch}</td>
                        <td className="border border-slate-300 p-2">{r.examType}</td>
                        <td className="border border-slate-300 p-2 font-mono">
                          {r.marksObtained}/{r.maxMarks}
                        </td>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-indigo-700">
                          {r.percentage}%
                        </td>
                        <td className="border border-slate-300 p-2 font-black text-emerald-700">{r.grade}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
