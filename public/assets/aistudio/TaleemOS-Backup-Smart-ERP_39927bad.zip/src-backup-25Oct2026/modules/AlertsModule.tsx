import React, { useState } from 'react';
import {
  Bell,
  Plus,
  Printer,
  Download,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  User,
  Send,
  Eye,
  Trash2,
} from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type AlertNotification } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const AlertsModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedAlert, setSelectedAlert] = useState<AlertNotification | null>(null);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);

  // New form fields (9 fields as required)
  const [formTitle, setFormTitle] = useState('');
  const [formType, setFormType] = useState<AlertNotification['type']>('General');
  const [formPriority, setFormPriority] = useState<AlertNotification['priority']>('Medium');
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [formAudience, setFormAudience] = useState<AlertNotification['audience']>('All');
  const [formStatus, setFormStatus] = useState<AlertNotification['status']>('New');
  const [formMessage, setFormMessage] = useState('');
  const [formAssignedTo, setFormAssignedTo] = useState('');
  const [formActionTaken, setFormActionTaken] = useState('');

  // Stats
  const totalAlerts = state.alerts.length;
  const criticalCount = state.alerts.filter((a) => a.priority === 'Critical').length;
  const pendingCount = state.alerts.filter((a) => a.status === 'Pending' || a.status === 'New').length;
  const resolvedCount = state.alerts.filter((a) => a.status === 'Resolved').length;

  // Filtered
  const filteredAlerts = state.alerts.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(search.toLowerCase()) ||
      item.message.toLowerCase().includes(search.toLowerCase()) ||
      item.assignedTo.toLowerCase().includes(search.toLowerCase());
    const matchesPriority = priorityFilter === 'All' || item.priority === priorityFilter;
    const matchesType = typeFilter === 'All' || item.type === typeFilter;
    const matchesStatus = statusFilter === 'All' || item.status === statusFilter;
    return matchesSearch && matchesPriority && matchesType && matchesStatus;
  });

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formMessage.trim()) return;

    const newAlert: AlertNotification = {
      id: `ALT-${Date.now().toString().slice(-4)}`,
      title: formTitle,
      type: formType,
      priority: formPriority,
      date: formDate,
      audience: formAudience,
      status: formStatus,
      message: formMessage,
      assignedTo: formAssignedTo || 'General Administration',
      actionTaken: formActionTaken || 'Pending review',
    };

    erpStorage.addItem('alerts', newAlert);
    setIsAddModalOpen(false);
    // Reset form
    setFormTitle('');
    setFormMessage('');
    setFormAssignedTo('');
    setFormActionTaken('');
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to remove this alert?')) {
      erpStorage.deleteItem('alerts', id);
      if (selectedAlert?.id === id) setSelectedAlert(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Gradient Header with KPIs */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <Bell className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Alerts & Notifications PRO</h1>
            <span className="px-2 py-0.5 bg-amber-400 text-slate-950 font-black text-[10px] rounded uppercase">
              PRO
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Institutional broadcast center, priority escalations, fee dues, exam notices, and staff tasks.
          </p>
        </div>

        {/* Action buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print All
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Add New
          </button>
        </div>
      </div>

      {/* KPI Stats Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Total Alerts</div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">{totalAlerts}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-rose-500 uppercase">Critical Priority</div>
          <div className="text-2xl font-black text-rose-600 font-mono mt-1">{criticalCount}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-amber-500 uppercase">Pending Actions</div>
          <div className="text-2xl font-black text-amber-600 font-mono mt-1">{pendingCount}</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-emerald-500 uppercase">Resolved</div>
          <div className="text-2xl font-black text-emerald-600 font-mono mt-1">{resolvedCount}</div>
        </div>
      </div>

      {/* Search & Smart Filter Pills */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search alerts by title, assignee, or message..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-indigo-500"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
            Priority:
          </span>
          {['All', 'Critical', 'High', 'Medium', 'Low'].map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPriorityFilter(p)}
              className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                priorityFilter === p
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {p}
            </button>
          ))}

          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider ml-2 mr-1">
            Type:
          </span>
          {['All', 'Fee Due', 'Exam', 'Admission', 'HR', 'Library', 'General'].map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTypeFilter(t)}
              className={`px-2.5 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                typeFilter === t
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {t}
            </button>
          ))}

          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider ml-2 mr-1">
            Status:
          </span>
          {['All', 'New', 'Pending', 'Scheduled', 'Resolved'].map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setStatusFilter(s)}
              className={`px-2.5 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                statusFilter === s
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Results Cards (Tappable to detail modal) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAlerts.length === 0 ? (
          <div className="col-span-full p-12 text-center bg-white rounded-[22px] border border-slate-200 text-slate-400">
            <Bell className="w-10 h-10 mx-auto text-slate-300 mb-2 stroke-1" />
            <p className="text-sm font-semibold">No alerts found matching your criteria</p>
          </div>
        ) : (
          filteredAlerts.map((item) => (
            <div
              key={item.id}
              onClick={() => setSelectedAlert(item)}
              className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span
                      className={`px-2 py-0.5 text-[10px] font-black rounded-full uppercase ${
                        item.priority === 'Critical'
                          ? 'bg-rose-100 text-rose-700'
                          : item.priority === 'High'
                          ? 'bg-orange-100 text-orange-700'
                          : item.priority === 'Medium'
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {item.priority}
                    </span>
                    <span className="px-2 py-0.5 text-[10px] font-bold rounded-md bg-indigo-50 text-indigo-700">
                      {item.type}
                    </span>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">{item.date}</span>
                </div>

                <h3 className="mt-2 text-base font-bold text-slate-900 line-clamp-1">{item.title}</h3>
                <p className="mt-1 text-xs text-slate-600 line-clamp-2">{item.message}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <div className="flex items-center gap-1 truncate max-w-[180px]">
                  <User className="w-3.5 h-3.5 text-slate-400" />
                  <span className="truncate">{item.assignedTo}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                      item.status === 'Resolved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : item.status === 'Scheduled'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {item.status}
                  </span>
                  <button
                    type="button"
                    onClick={(e) => handleDelete(item.id, e)}
                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"
                    title="Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* ADD NEW MODAL (Form with 9 fields as strictly required by prompt) */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Add New Alert / Notification"
        subtitle="Broadcast institutional alert, notice, or task assignment"
        badge="ERP ALERT"
      >
        <form onSubmit={handleCreateAlert} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Title *
            </label>
            <input
              type="text"
              required
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              placeholder="e.g. October Fee Collection Deadline"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Type</label>
              <select
                value={formType}
                onChange={(e) => setFormType(e.target.value as AlertNotification['type'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Fee Due">Fee Due</option>
                <option value="Exam">Exam</option>
                <option value="Admission">Admission</option>
                <option value="HR">HR</option>
                <option value="Library">Library</option>
                <option value="General">General</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Priority</label>
              <select
                value={formPriority}
                onChange={(e) => setFormPriority(e.target.value as AlertNotification['priority'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Critical">Critical</option>
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Date</label>
              <input
                type="date"
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
              </input>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Audience</label>
              <select
                value={formAudience}
                onChange={(e) => setFormAudience(e.target.value as AlertNotification['audience'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="All">All</option>
                <option value="Teachers">Teachers</option>
                <option value="Students">Students</option>
                <option value="Parents">Parents</option>
                <option value="Staff">Staff</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Status</label>
              <select
                value={formStatus}
                onChange={(e) => setFormStatus(e.target.value as AlertNotification['status'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="New">New</option>
                <option value="Pending">Pending</option>
                <option value="Scheduled">Scheduled</option>
                <option value="Resolved">Resolved</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Message Content *
            </label>
            <textarea
              required
              rows={3}
              value={formMessage}
              onChange={(e) => setFormMessage(e.target.value)}
              placeholder="Enter comprehensive notice text..."
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Assigned To
              </label>
              <input
                type="text"
                value={formAssignedTo}
                onChange={(e) => setFormAssignedTo(e.target.value)}
                placeholder="e.g. Accountant (M. Ali)"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Action Taken
              </label>
              <input
                type="text"
                value={formActionTaken}
                onChange={(e) => setFormActionTaken(e.target.value)}
                placeholder="e.g. Notice pinned on board, SMS queued"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Publish Alert
            </button>
          </div>
        </form>
      </Modal>

      {/* DETAIL MODAL with Single Print */}
      {selectedAlert && (
        <Modal
          isOpen={Boolean(selectedAlert)}
          onClose={() => setSelectedAlert(null)}
          title={selectedAlert.title}
          subtitle={`Alert ID: ${selectedAlert.id} • ${selectedAlert.date}`}
          badge={selectedAlert.priority}
        >
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs mb-3">
                <div>
                  <span className="text-slate-400 block font-semibold">Type:</span>
                  <strong className="text-slate-800">{selectedAlert.type}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Priority:</span>
                  <strong className="text-slate-800">{selectedAlert.priority}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Audience:</span>
                  <strong className="text-slate-800">{selectedAlert.audience}</strong>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Status:</span>
                  <strong className="text-slate-800">{selectedAlert.status}</strong>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200">
                <span className="text-slate-400 block text-xs font-semibold mb-1">Message:</span>
                <p className="text-xs text-slate-800 leading-relaxed bg-white p-3 rounded-xl border border-slate-100 font-medium">
                  {selectedAlert.message}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs mt-3">
                <div>
                  <span className="text-slate-400 block font-semibold">Assigned To:</span>
                  <span className="text-slate-800 font-medium">{selectedAlert.assignedTo}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">Action Taken:</span>
                  <span className="text-slate-800 font-medium">{selectedAlert.actionTaken}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <button
                type="button"
                onClick={() => {
                  triggerBrowserPrint();
                }}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 flex items-center gap-1.5 cursor-pointer shadow-md"
              >
                <Printer className="w-4 h-4" />
                Print Single Notice
              </button>
              <button
                type="button"
                onClick={() => setSelectedAlert(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Official Alerts Ledger (A4 Table)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('alerts-print-table', 'TaleemOS_Alerts_Ledger')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="alerts-print-table">
              <LetterheadPrint
                title="Institutional Alerts & Priority Communications Ledger"
                documentNo="NOTIF-LEDGER-2026"
                summaryStats={[
                  { label: 'Total Alerts', value: totalAlerts },
                  { label: 'Critical Alerts', value: criticalCount },
                  { label: 'Pending Action', value: pendingCount },
                  { label: 'Resolved', value: resolvedCount },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Ref ID</th>
                      <th className="border border-slate-300 p-2">Title</th>
                      <th className="border border-slate-300 p-2">Type</th>
                      <th className="border border-slate-300 p-2">Priority</th>
                      <th className="border border-slate-300 p-2">Date</th>
                      <th className="border border-slate-300 p-2">Assigned To</th>
                      <th className="border border-slate-300 p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAlerts.map((a) => (
                      <tr key={a.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold">{a.id}</td>
                        <td className="border border-slate-300 p-2 font-bold">{a.title}</td>
                        <td className="border border-slate-300 p-2">{a.type}</td>
                        <td className="border border-slate-300 p-2 font-semibold">{a.priority}</td>
                        <td className="border border-slate-300 p-2 font-mono">{a.date}</td>
                        <td className="border border-slate-300 p-2">{a.assignedTo}</td>
                        <td className="border border-slate-300 p-2 font-bold">{a.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
