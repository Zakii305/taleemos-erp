import React, { useState } from 'react';
import { TrendingUp, CheckCircle, Clock, ShieldCheck, ArrowRight, UserCheck, AlertCircle } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type PromotionRecord, type ApprovalRequest } from '../types';
import { Modal } from '../components/common/Modal';

export const PromoteModule: React.FC = () => {
  const state = erpStorage.getState();
  const [selectedStudentId, setSelectedStudentId] = useState(state.students[0]?.id || '');
  const [targetBatch, setTargetBatch] = useState('2nd Year F.Sc Engineering');
  const [academicYear, setAcademicYear] = useState('2026-2027');
  const [remarks, setRemarks] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);

  const selectedStudent = state.students.find((s) => s.id === selectedStudentId);

  const handleCreatePromotion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedStudent) return;

    const promoId = `PRO-${Date.now().toString().slice(-4)}`;
    const newPromo: PromotionRecord = {
      id: promoId,
      studentId: selectedStudent.id,
      studentName: selectedStudent.name,
      currentClass: selectedStudent.classBatch,
      targetClass: targetBatch,
      academicYear,
      status: 'Pending',
      date: new Date().toISOString().split('T')[0],
      approver: 'Principal Office',
      remarks: remarks || 'Eligible for session advancement.',
    };

    erpStorage.addItem('promotions', newPromo);

    // Queue in approvals
    const approvalReq: ApprovalRequest = {
      id: `APP-${Date.now().toString().slice(-4)}`,
      module: 'Student Promotion',
      recordId: promoId,
      title: `Promotion Approval: ${selectedStudent.name} (${selectedStudent.rollNo})`,
      requestedBy: state.userName,
      requestedRole: state.activeRole,
      currentApproverRole: 'Principal',
      amountOrValue: `Promote to ${targetBatch}`,
      status: 'Pending Approval',
      date: new Date().toISOString().split('T')[0],
      reason: remarks || 'Annual examination qualification.',
      history: [
        {
          actor: state.userName,
          role: state.activeRole,
          action: 'Created',
          timestamp: new Date().toLocaleString(),
        },
      ],
    };
    erpStorage.addItem('approvals', approvalReq);

    setIsModalOpen(false);
    setRemarks('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <TrendingUp className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Student Promotion Workflow</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              PRINCIPAL APPROVAL
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Institutional cohort progression, academic prerequisites validation, and multi-tier approval governance.
          </p>
        </div>

        <button
          type="button"
          onClick={() => setIsModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
        >
          <UserCheck className="w-4 h-4" />
          Request Promotion
        </button>
      </div>

      {/* Promotion requests list */}
      <div className="p-6 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-500" />
          Promotion Queues & Historical Records
        </h3>

        <div className="space-y-3">
          {state.promotions.map((p) => (
            <div
              key={p.id}
              className="p-4 bg-slate-50 hover:bg-white rounded-2xl border border-slate-200 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-black text-indigo-700">{p.id}</span>
                  <h4 className="font-bold text-slate-900 text-sm">{p.studentName}</h4>
                  <span
                    className={`px-2 py-0.2 rounded-full text-[10px] font-black uppercase ${
                      p.status === 'Approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : p.status === 'Pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {p.status}
                  </span>
                </div>
                <div className="mt-1 flex items-center gap-2 text-xs text-slate-600">
                  <span className="text-slate-500">{p.currentClass}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                  <span className="font-bold text-indigo-900">{p.targetClass}</span>
                  <span className="text-slate-400 font-mono">({p.academicYear})</span>
                </div>
                {p.remarks && <p className="text-xs text-slate-500 mt-1 italic">&ldquo;{p.remarks}&rdquo;</p>}
              </div>

              <div className="text-right text-xs">
                <span className="text-slate-400 block font-semibold">Authorized By</span>
                <span className="font-bold text-slate-800">{p.approver}</span>
                <span className="text-[10px] text-slate-400 block font-mono">{p.date}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* REQUEST PROMOTION MODAL */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Submit Student Promotion Proposal"
        subtitle="Routes to Principal Approval Queue before updating academic batch"
        badge="APPROVAL QUEUE"
      >
        <form onSubmit={handleCreatePromotion} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Select Candidate Student *
            </label>
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
            >
              {state.students.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.rollNo}) - Current: {s.classBatch}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Target Progression Class / Batch *
              </label>
              <input
                type="text"
                required
                value={targetBatch}
                onChange={(e) => setTargetBatch(e.target.value)}
                placeholder="e.g. 2nd Year F.Sc Engineering"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Target Academic Year
              </label>
              <input
                type="text"
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                placeholder="2026-2027"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Academic Justification & Prerequisites
            </label>
            <textarea
              rows={3}
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              placeholder="e.g. Scored 88% in 1st year board exams; cleared all compulsory papers."
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
            />
          </div>

          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-800 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              Per TaleemOS RBAC policy, promotions must be formally approved by Principal or Director.
            </span>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Submit to Principal
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
