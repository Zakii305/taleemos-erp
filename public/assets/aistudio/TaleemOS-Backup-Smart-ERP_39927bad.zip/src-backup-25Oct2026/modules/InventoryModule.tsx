import React, { useState } from 'react';
import { Package, Plus, Printer, Download, Search, AlertTriangle, ArrowUpRight, ArrowDownLeft, Trash2 } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type InventoryItem } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const InventoryModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);

  // Form fields
  const [name, setName] = useState('');
  const [category, setCategory] = useState<InventoryItem['category']>('Stationery');
  const [currentStock, setCurrentStock] = useState(50);
  const [minimumThreshold, setMinimumThreshold] = useState(20);
  const [unit, setUnit] = useState('Pieces');
  const [costPerUnit, setCostPerUnit] = useState(150);
  const [location, setLocation] = useState('Main Store Cupboard B');

  const filtered = state.inventory.filter((item) => {
    const matchSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.location.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === 'All' || item.category === categoryFilter;
    return matchSearch && matchCat;
  });

  const lowStockItems = state.inventory.filter((i) => i.currentStock <= i.minimumThreshold);

  const handleCreateItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newItem: InventoryItem = {
      id: `INV-${Date.now().toString().slice(-4)}`,
      name,
      category,
      currentStock: Number(currentStock),
      minimumThreshold: Number(minimumThreshold),
      unit,
      costPerUnit: Number(costPerUnit),
      location,
      lastUpdated: new Date().toISOString().split('T')[0],
    };

    erpStorage.addItem('inventory', newItem);
    setIsAddModalOpen(false);
  };

  const handleStockAdjust = (id: string, delta: number) => {
    const item = state.inventory.find((i) => i.id === id);
    if (!item) return;
    const newStock = Math.max(0, item.currentStock + delta);
    erpStorage.updateItem('inventory', id, {
      currentStock: newStock,
      lastUpdated: new Date().toISOString().split('T')[0],
    });
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this inventory item?')) {
      erpStorage.deleteItem('inventory', id);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <Package className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Institutional Inventory & Stationery</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              STOCK AUDIT
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Stationery reams, examination answer sheets, IT hardware, lab reagents, and automated low-stock warnings.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Stock Ledger
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Stock In Item
          </button>
        </div>
      </div>

      {/* Low stock alert banner */}
      {lowStockItems.length > 0 && (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-center justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
            <div>
              <span className="font-bold">Low Stock Warning: </span>
              {lowStockItems.map((i) => `${i.name} (${i.currentStock} ${i.unit})`).join(', ')}
            </div>
          </div>
          <span className="px-2.5 py-1 bg-amber-200 text-amber-900 font-bold rounded-lg shrink-0">
            Reorder Suggested
          </span>
        </div>
      )}

      {/* Search & Categories */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search items by name, category, or store location..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
            Category:
          </span>
          {['All', 'Stationery', 'IT Equipment', 'Furniture', 'Lab Consumable'].map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategoryFilter(c)}
              className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                categoryFilter === c
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Item Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => {
          const isLow = item.currentStock <= item.minimumThreshold;
          return (
            <div
              key={item.id}
              className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-0.5 text-xs font-bold bg-indigo-50 text-indigo-700 rounded-lg">
                    {item.category}
                  </span>
                  <span
                    className={`px-2 py-0.2 rounded-full text-[10px] font-black uppercase ${
                      isLow ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {isLow ? 'Low Stock' : 'In Stock'}
                  </span>
                </div>

                <h3 className="mt-2 text-base font-extrabold text-slate-900">{item.name}</h3>
                <p className="text-xs text-slate-500 font-mono mt-0.5">Location: {item.location}</p>

                <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs font-mono">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-sans">Current Balance</span>
                    <span className={`text-base font-black ${isLow ? 'text-rose-600' : 'text-slate-900'}`}>
                      {item.currentStock} {item.unit}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block font-sans">Unit Price</span>
                    <span className="font-bold text-slate-700">PKR {item.costPerUnit}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                {/* Stock In / Stock Out Quick Action Buttons */}
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleStockAdjust(item.id, 5)}
                    className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-lg text-[10px] flex items-center gap-0.5 cursor-pointer"
                    title="+5 Quick Stock In"
                  >
                    <ArrowDownLeft className="w-3 h-3" />
                    +5 In
                  </button>
                  <button
                    type="button"
                    onClick={() => handleStockAdjust(item.id, -5)}
                    className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-lg text-[10px] flex items-center gap-0.5 cursor-pointer"
                    title="-5 Quick Issue Out"
                  >
                    <ArrowUpRight className="w-3 h-3" />
                    -5 Out
                  </button>
                </div>

                <button
                  type="button"
                  onClick={(e) => handleDelete(item.id, e)}
                  className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* STOCK IN MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Stock In New Inventory Item"
        subtitle="Catalog supply consumables and threshold alert limits"
        badge="INVENTORY ENTRY"
      >
        <form onSubmit={handleCreateItem} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Item Title *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. A4 Paper Box"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as InventoryItem['category'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Stationery">Stationery</option>
                <option value="IT Equipment">IT Equipment</option>
                <option value="Furniture">Furniture</option>
                <option value="Sports">Sports Equipment</option>
                <option value="Lab Consumable">Lab Consumable</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Quantity Stocked</label>
              <input
                type="number"
                min={1}
                value={currentStock}
                onChange={(e) => setCurrentStock(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Low Threshold</label>
              <input
                type="number"
                min={1}
                value={minimumThreshold}
                onChange={(e) => setMinimumThreshold(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono font-bold text-rose-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Unit of Measure</label>
              <input
                type="text"
                value={unit}
                onChange={(e) => setUnit(e.target.value)}
                placeholder="Reams, Pieces, Packs"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Cost Per Unit (PKR)</label>
              <input
                type="number"
                min={0}
                value={costPerUnit}
                onChange={(e) => setCostPerUnit(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Storage Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Admin Store Cupboard A1"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Catalog Inventory
            </button>
          </div>
        </form>
      </Modal>

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Inventory Stock Audit Ledger (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('inventory-print-table', 'TaleemOS_Inventory_Stock')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="inventory-print-table">
              <LetterheadPrint
                title="INSTITUTIONAL ASSET & INVENTORY STOCK REPORT"
                documentNo="INV-AUDIT-2026"
                summaryStats={[
                  { label: 'Stock Items', value: state.inventory.length },
                  { label: 'Low Stock Alerts', value: lowStockItems.length },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Item Name</th>
                      <th className="border border-slate-300 p-2">Category</th>
                      <th className="border border-slate-300 p-2">Location</th>
                      <th className="border border-slate-300 p-2 text-right">Current Stock</th>
                      <th className="border border-slate-300 p-2 text-right">Threshold</th>
                      <th className="border border-slate-300 p-2 text-right">Unit Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((item) => (
                      <tr key={item.id}>
                        <td className="border border-slate-300 p-2 font-bold">{item.name}</td>
                        <td className="border border-slate-300 p-2">{item.category}</td>
                        <td className="border border-slate-300 p-2">{item.location}</td>
                        <td className="border border-slate-300 p-2 text-right font-mono font-bold">
                          {item.currentStock} {item.unit}
                        </td>
                        <td className="border border-slate-300 p-2 text-right font-mono text-rose-600">
                          {item.minimumThreshold}
                        </td>
                        <td className="border border-slate-300 p-2 text-right font-mono">PKR {item.costPerUnit}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
