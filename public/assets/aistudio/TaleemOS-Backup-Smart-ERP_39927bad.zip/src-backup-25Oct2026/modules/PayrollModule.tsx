import React, { useState } from 'react';
import { DollarSign, Plus, Printer, Download, Search, UserCheck, ShieldCheck, Trash2 } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type PayrollRecord, type ApprovalRequest } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const PayrollModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedPayRecord, setSelectedPayRecord] = useState<PayrollRecord | null>(null);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);

  // Form fields
  const [staffName, setStaffName] = useState('Prof. Ghulam Rasool');
  const [designation, setDesignation] = useState('Director & Academic Dean');
  const [month, setMonth] = useState('October 2026');
  const [basicSalary, setBasicSalary] = useState(75000);
  const [allowances, setAllowances] = useState(10000);
  const [deductions, setDeductions] = useState(2000);
  const [paymentMethod, setPaymentMethod] = useState('Direct Bank Transfer');

  const netPay = Math.max(0, basicSalary + allowances - deductions);

  const totalPayroll = state.payroll.reduce((sum, p) => sum + p.netPay, 0);

  const filtered = state.payroll.filter(
    (p) =>
      p.staffName.toLowerCase().includes(search.toLowerCase()) ||
      p.designation.toLowerCase().includes(search.toLowerCase()) ||
      p.month.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreatePayroll = (e: React.FormEvent) => {
    e.preventDefault();
    const payId = `PAY-${Date.now().toString().slice(-4)}`;

    const newPay: PayrollRecord = {
      id: payId,
      staffName,
      designation,
      month,
      basicSalary: Number(basicSalary),
      allowances: Number(allowances),
      deductions: Number(deductions),
      netPay,
      status: 'Paid',
      paymentDate: new Date().toISOString().split('T')[0],
      paymentMethod,
    };

    erpStorage.addItem('payroll', newPay);
    setIsAddModalOpen(false);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this payroll record?')) {
      erpStorage.deleteItem('payroll', id);
      if (selectedPayRecord?.id === id) setSelectedPayRecord(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <DollarSign className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Staff Salary & Payroll PRO</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              PAYROLL SLIPS
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Faculty remuneration, basic pay structures, allowances, tax deductions, and official pay slips.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Master Payroll
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Process Salary
          </button>
        </div>
      </div>

      {/* KPI */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-slate-500 uppercase">Total Net Staff Remuneration</span>
          <div className="text-2xl md:text-3xl font-black text-indigo-700 font-mono mt-1">
            PKR {totalPayroll.toLocaleString()}
          </div>
        </div>
        <div className="text-right text-xs text-slate-400">
          <div>Disbursement Status: 100% Processed</div>
          <div className="font-bold text-emerald-600">Audited via TaleemOS Hub</div>
        </div>
      </div>

      {/* Search */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search salary records by staff name, designation, or month..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none"
          />
        </div>
      </div>

      {/* Cards (Tappable to Detail Pay Slip) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedPayRecord(item)}
            className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="px-2.5 py-0.5 font-bold text-xs bg-indigo-50 text-indigo-700 rounded-lg">
                  {item.month}
                </span>
                <span
                  className={`px-2 py-0.2 rounded-full text-[10px] font-black uppercase ${
                    item.status === 'Paid'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {item.status}
                </span>
              </div>

              <h3 className="mt-2 text-base font-extrabold text-slate-900">{item.staffName}</h3>
              <p className="text-xs text-slate-500">{item.designation}</p>

              <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400 font-sans">Basic Pay:</span>
                  <span>PKR {item.basicSalary.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-emerald-700">
                  <span className="text-slate-400 font-sans">Allowances:</span>
                  <span>+PKR {item.allowances.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-rose-600">
                  <span className="text-slate-400 font-sans">Deductions:</span>
                  <span>-PKR {item.deductions.toLocaleString()}</span>
                </div>
                <div className="pt-1.5 border-t border-slate-200 flex justify-between font-bold text-slate-900">
                  <span className="font-sans">Net Salary:</span>
                  <span className="text-indigo-700 font-black">PKR {item.netPay.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono text-[10px]">{item.paymentMethod}</span>
              <button
                type="button"
                onClick={(e) => handleDelete(item.id, e)}
                className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* PROCESS SALARY MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Process Staff Salary Disbursement"
        subtitle="Calculates gross compensation, tax/provident deductions, and net credit"
        badge="PAYROLL"
      >
        <form onSubmit={handleCreatePayroll} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Staff / Faculty Member *
              </label>
              <input
                type="text"
                required
                value={staffName}
                onChange={(e) => setStaffName(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Designation *
              </label>
              <input
                type="text"
                required
                value={designation}
                onChange={(e) => setDesignation(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Salary Month</label>
              <input
                type="text"
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                placeholder="October 2026"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Payment Channel
              </label>
              <input
                type="text"
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                placeholder="Direct Bank Transfer"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Basic Salary (PKR)</label>
              <input
                type="number"
                min={0}
                value={basicSalary}
                onChange={(e) => setBasicSalary(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Allowances (PKR)</label>
              <input
                type="number"
                min={0}
                value={allowances}
                onChange={(e) => setAllowances(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-emerald-700"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Deductions (PKR)</label>
              <input
                type="number"
                min={0}
                value={deductions}
                onChange={(e) => setDeductions(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-rose-600"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Net Pay (PKR)</label>
              <div className="w-full px-3 py-1.5 bg-indigo-50 border border-indigo-200 rounded-lg text-xs font-mono font-black text-indigo-900">
                PKR {netPay.toLocaleString()}
              </div>
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 cursor-pointer"
            >
              Issue Pay Record
            </button>
          </div>
        </form>
      </Modal>

      {/* DETAIL MODAL + OFFICIAL PAY SLIP PRINT */}
      {selectedPayRecord && (
        <Modal
          isOpen={Boolean(selectedPayRecord)}
          onClose={() => setSelectedPayRecord(null)}
          title={`Official Salary Slip: ${selectedPayRecord.staffName}`}
          subtitle={`Month: ${selectedPayRecord.month} • Designation: ${selectedPayRecord.designation}`}
          badge={selectedPayRecord.status}
          maxWidth="max-w-4xl"
        >
          <div className="space-y-4">
            <div id="single-pay-slip">
              <LetterheadPrint
                title="OFFICIAL FACULTY & STAFF CONFIDENTIAL PAY SLIP"
                documentNo={selectedPayRecord.id}
                signatures={[
                  'Staff Signature / Acknowledgment',
                  'Accounts Officer (Prepared By)',
                  'Director Prof. Ghulam Rasool (Approved By)',
                ]}
              >
                <div className="space-y-4 text-xs">
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">EMPLOYEE NAME</span>
                      <strong className="text-slate-900 text-sm uppercase">{selectedPayRecord.staffName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">DESIGNATION</span>
                      <strong className="text-slate-900">{selectedPayRecord.designation}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">PAYROLL MONTH</span>
                      <strong className="text-indigo-700 font-bold">{selectedPayRecord.month}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">DISBURSEMENT METHOD</span>
                      <strong className="text-slate-900">{selectedPayRecord.paymentMethod}</strong>
                    </div>
                  </div>

                  <table className="w-full border-collapse border border-slate-300 text-left">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-bold">
                        <th className="border border-slate-300 p-2">Earnings Head</th>
                        <th className="border border-slate-300 p-2 text-right">Amount (PKR)</th>
                        <th className="border border-slate-300 p-2">Deductions Head</th>
                        <th className="border border-slate-300 p-2 text-right">Amount (PKR)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="border border-slate-300 p-2 font-semibold">Basic Pay</td>
                        <td className="border border-slate-300 p-2 text-right font-mono">
                          PKR {selectedPayRecord.basicSalary.toLocaleString()}
                        </td>
                        <td className="border border-slate-300 p-2 text-rose-700 font-semibold">Income Tax / Provident</td>
                        <td className="border border-slate-300 p-2 text-right font-mono text-rose-700">
                          PKR {selectedPayRecord.deductions.toLocaleString()}
                        </td>
                      </tr>
                      <tr>
                        <td className="border border-slate-300 p-2 font-semibold text-emerald-700">
                          Special & Medical Allowances
                        </td>
                        <td className="border border-slate-300 p-2 text-right font-mono text-emerald-700">
                          PKR {selectedPayRecord.allowances.toLocaleString()}
                        </td>
                        <td className="border border-slate-300 p-2 text-slate-400">Other Deductions</td>
                        <td className="border border-slate-300 p-2 text-right font-mono text-slate-400">PKR 0</td>
                      </tr>
                      <tr className="bg-slate-50 font-bold">
                        <td className="border border-slate-300 p-2 uppercase">Total Gross Remuneration</td>
                        <td className="border border-slate-300 p-2 text-right font-mono text-indigo-900 font-black">
                          PKR {(selectedPayRecord.basicSalary + selectedPayRecord.allowances).toLocaleString()}
                        </td>
                        <td className="border border-slate-300 p-2 uppercase">Net Bank Credit Amount</td>
                        <td className="border border-slate-300 p-2 text-right font-mono text-emerald-800 font-black text-sm">
                          PKR {selectedPayRecord.netPay.toLocaleString()}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </LetterheadPrint>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Printer className="w-4 h-4" />
                  Print Salary Slip
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('single-pay-slip', `PaySlip_${selectedPayRecord.staffName}`)}
                  className="px-3.5 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-700 flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Download className="w-4 h-4" />
                  Download PDF
                </button>
              </div>

              <button
                type="button"
                onClick={() => setSelectedPayRecord(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Institutional Master Payroll Ledger (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('payroll-print-table', 'TaleemOS_Payroll_Ledger')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="payroll-print-table">
              <LetterheadPrint
                title="INSTITUTIONAL FACULTY & STAFF MASTER PAYROLL REGISTER"
                documentNo="PAY-REGISTER-2026"
                summaryStats={[
                  { label: 'Staff Count', value: state.payroll.length },
                  { label: 'Total Payroll', value: `PKR ${totalPayroll.toLocaleString()}` },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Staff Member</th>
                      <th className="border border-slate-300 p-2">Designation</th>
                      <th className="border border-slate-300 p-2">Month</th>
                      <th className="border border-slate-300 p-2 text-right">Basic</th>
                      <th className="border border-slate-300 p-2 text-right">Allowances</th>
                      <th className="border border-slate-300 p-2 text-right">Deductions</th>
                      <th className="border border-slate-300 p-2 text-right">Net Pay</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((p) => (
                      <tr key={p.id}>
                        <td className="border border-slate-300 p-2 font-bold">{p.staffName}</td>
                        <td className="border border-slate-300 p-2">{p.designation}</td>
                        <td className="border border-slate-300 p-2">{p.month}</td>
                        <td className="border border-slate-300 p-2 text-right font-mono">
                          PKR {p.basicSalary.toLocaleString()}
                        </td>
                        <td className="border border-slate-300 p-2 text-right font-mono text-emerald-700">
                          PKR {p.allowances.toLocaleString()}
                        </td>
                        <td className="border border-slate-300 p-2 text-right font-mono text-rose-700">
                          PKR {p.deductions.toLocaleString()}
                        </td>
                        <td className="border border-slate-300 p-2 text-right font-mono font-black text-indigo-900">
                          PKR {p.netPay.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
