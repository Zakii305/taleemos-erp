import React, { useState } from 'react';
import { DollarSign, Plus, Printer, Download, Search, Receipt, CheckCircle, AlertTriangle, User, QrCode, Trash2 } from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type FeeVoucher } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

export const FeesModule: React.FC = () => {
  const state = erpStorage.getState();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [monthFilter, setMonthFilter] = useState('All');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedVoucher, setSelectedVoucher] = useState<FeeVoucher | null>(null);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);

  // Form fields
  const [studentRoll, setStudentRoll] = useState(state.students[0]?.rollNo || 'TAK-26-001');
  const [month, setMonth] = useState('October 2026');
  const [feeHead, setFeeHead] = useState<FeeVoucher['feeHead']>('Monthly');
  const [amount, setAmount] = useState(4500);
  const [discount, setDiscount] = useState(0);
  const [fine, setFine] = useState(0);
  const [status, setStatus] = useState<FeeVoucher['status']>('Paid');
  const [paymentMethod, setPaymentMethod] = useState<FeeVoucher['paymentMethod']>('Cash');

  const targetStudent = state.students.find((s) => s.rollNo === studentRoll);
  const netPayable = Math.max(0, amount - discount + fine);

  // KPIs
  const totalVouchers = state.fees.length;
  const totalPaidRevenue = state.fees
    .filter((f) => f.status === 'Paid')
    .reduce((sum, f) => sum + f.netPayable, 0);
  const totalUnpaidDues = state.fees
    .filter((f) => f.status === 'Unpaid' || f.status === 'Partial')
    .reduce((sum, f) => sum + f.netPayable, 0);

  const filtered = state.fees.filter((f) => {
    const matchSearch =
      f.studentName.toLowerCase().includes(search.toLowerCase()) ||
      f.rollNo.toLowerCase().includes(search.toLowerCase()) ||
      f.voucherNo.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'All' || f.status === statusFilter;
    const matchMonth = monthFilter === 'All' || f.month === monthFilter;
    return matchSearch && matchStatus && matchMonth;
  });

  const handleCreateVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetStudent) return;

    const voucherNum = `VCH-26-${String(800 + state.fees.length + 1)}`;
    const newVoucher: FeeVoucher = {
      id: `FEE-${Date.now().toString().slice(-4)}`,
      voucherNo: voucherNum,
      studentName: targetStudent.name,
      rollNo: targetStudent.rollNo,
      batch: targetStudent.classBatch,
      month,
      feeHead,
      amount: Number(amount),
      discount: Number(discount),
      fine: Number(fine),
      netPayable,
      status,
      paymentMethod,
      paidDate: status === 'Paid' ? new Date().toISOString().split('T')[0] : undefined,
      collectedBy: state.userName,
    };

    erpStorage.addItem('fees', newVoucher);
    setIsAddModalOpen(false);
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Delete this fee voucher record?')) {
      erpStorage.deleteItem('fees', id);
      if (selectedVoucher?.id === id) setSelectedVoucher(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-emerald-600 rounded-xl">
              <DollarSign className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Fee Vouchers & Collections</h1>
            <span className="px-2 py-0.5 bg-emerald-500 text-white font-black text-[10px] rounded uppercase">
              FINANCE ERP
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Student tuition invoices, bank challans, discount waivers, fines, and automated defaulter tracking.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Ledger
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-emerald-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Issue Voucher
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Total Issued Vouchers</div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">{totalVouchers} Invoices</div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-emerald-600 uppercase">Total Verified Revenue</div>
          <div className="text-2xl font-black text-emerald-600 font-mono mt-1">
            PKR {totalPaidRevenue.toLocaleString()}
          </div>
        </div>
        <div className="p-4 bg-white rounded-[20px] border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-rose-600 uppercase">Outstanding Defaulter Dues</div>
          <div className="text-2xl font-black text-rose-600 font-mono mt-1">
            PKR {totalUnpaidDues.toLocaleString()}
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by Voucher No (VCH-26-801), student name, or roll no..."
            className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
            Status:
          </span>
          {['All', 'Paid', 'Unpaid', 'Partial'].map((st) => (
            <button
              key={st}
              type="button"
              onClick={() => setStatusFilter(st)}
              className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                statusFilter === st
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Results Cards (Tappable to Detail Voucher Receipt) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            onClick={() => setSelectedVoucher(item)}
            className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="px-2.5 py-0.5 font-mono text-xs font-black bg-indigo-50 text-indigo-700 rounded-lg">
                  {item.voucherNo}
                </span>
                <span
                  className={`px-2.5 py-0.5 text-[10px] font-black rounded-full uppercase ${
                    item.status === 'Paid'
                      ? 'bg-emerald-100 text-emerald-800'
                      : item.status === 'Unpaid'
                      ? 'bg-rose-100 text-rose-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {item.status}
                </span>
              </div>

              <h3 className="mt-2 text-base font-extrabold text-slate-900">{item.studentName}</h3>
              <p className="text-xs text-slate-500 font-mono">Roll: {item.rollNo} &bull; {item.batch}</p>

              <div className="mt-4 p-3 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400">Fee Head / Month:</span>
                  <span className="font-bold text-slate-800">{item.feeHead} ({item.month})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Payment Mode:</span>
                  <span className="font-medium text-slate-700">{item.paymentMethod}</span>
                </div>
                <div className="pt-1.5 border-t border-slate-200 flex justify-between font-mono">
                  <span className="text-slate-500 font-sans font-semibold">Net Payable:</span>
                  <span className="font-black text-emerald-700 text-sm">PKR {item.netPayable.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
              <span className="truncate max-w-[160px]">Officer: {item.collectedBy}</span>
              <button
                type="button"
                onClick={(e) => handleDelete(item.id, e)}
                className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ISSUE VOUCHER MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Issue Fee Voucher / Bank Challan"
        subtitle="Generates institutional voucher reference VCH-26-XXX"
        badge="FEE VOUCHER"
        maxWidth="max-w-3xl"
      >
        <form onSubmit={handleCreateVoucher} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Candidate Student *
              </label>
              <select
                value={studentRoll}
                onChange={(e) => setStudentRoll(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white font-mono"
              >
                {state.students.map((s) => (
                  <option key={s.id} value={s.rollNo}>
                    {s.rollNo} - {s.name} ({s.classBatch})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Billing Month *
              </label>
              <input
                type="text"
                required
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                placeholder="e.g. October 2026"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Fee Head</label>
              <select
                value={feeHead}
                onChange={(e) => setFeeHead(e.target.value as FeeVoucher['feeHead'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Monthly">Monthly Tuition</option>
                <option value="Admission">Admission Fee</option>
                <option value="Exam">Exam Fee</option>
                <option value="Library">Library Caution</option>
                <option value="Lab">Lab Practical Fee</option>
                <option value="Annual">Annual Sports/Gala</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Payment Method</label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as FeeVoucher['paymentMethod'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Cash">Cash at Counter</option>
                <option value="Bank Transfer">Bank Deposit / Transfer</option>
                <option value="EasyPaisa">EasyPaisa</option>
                <option value="JazzCash">JazzCash</option>
                <option value="Cheque">Bank Cheque</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Initial Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as FeeVoucher['status'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Paid">Paid</option>
                <option value="Unpaid">Unpaid</option>
                <option value="Partial">Partial</option>
              </select>
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Base Amount (PKR)</label>
              <input
                type="number"
                min={0}
                value={amount}
                onChange={(e) => setAmount(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Discount (PKR)</label>
              <input
                type="number"
                min={0}
                value={discount}
                onChange={(e) => setDiscount(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-rose-600"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Late Fine (PKR)</label>
              <input
                type="number"
                min={0}
                value={fine}
                onChange={(e) => setFine(Number(e.target.value))}
                className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs font-mono font-bold text-amber-600"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">Net Total (PKR)</label>
              <div className="w-full px-3 py-1.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs font-mono font-black text-emerald-800">
                PKR {netPayable.toLocaleString()}
              </div>
            </div>
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl shadow-lg shadow-emerald-600/30 cursor-pointer"
            >
              Generate Voucher
            </button>
          </div>
        </form>
      </Modal>

      {/* DETAIL MODAL + OFFICIAL SINGLE VOUCHER PRINT */}
      {selectedVoucher && (
        <Modal
          isOpen={Boolean(selectedVoucher)}
          onClose={() => setSelectedVoucher(null)}
          title={`Official Fee Voucher: ${selectedVoucher.voucherNo}`}
          subtitle={`Student: ${selectedVoucher.studentName} • ${selectedVoucher.month}`}
          badge={selectedVoucher.status}
          maxWidth="max-w-4xl"
        >
          <div className="space-y-4">
            <div id="single-fee-voucher">
              <LetterheadPrint
                title="OFFICIAL INSTITUTIONAL TUITION FEE RECEIPT"
                documentNo={selectedVoucher.voucherNo}
                signatures={[
                  'Accounts Officer (Cashier)',
                  'Student / Guardian Copy',
                  'Auditor / Principal Seal',
                ]}
              >
                <div className="space-y-4 text-xs">
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 grid grid-cols-2 sm:grid-cols-4 gap-3">
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">STUDENT NAME</span>
                      <strong className="text-slate-900 text-sm uppercase">{selectedVoucher.studentName}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">ROLL NUMBER</span>
                      <strong className="text-indigo-700 font-mono text-sm">{selectedVoucher.rollNo}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">CLASS / BATCH</span>
                      <strong className="text-slate-900">{selectedVoucher.batch}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-semibold text-[10px]">FEE HEAD / MONTH</span>
                      <strong className="text-slate-900">{selectedVoucher.feeHead} ({selectedVoucher.month})</strong>
                    </div>
                  </div>

                  {/* Fee Breakdown Table */}
                  <table className="w-full border-collapse border border-slate-300 text-left">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-bold">
                        <th className="border border-slate-300 p-2">Item Description</th>
                        <th className="border border-slate-300 p-2 text-right">Amount (PKR)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="border border-slate-300 p-2 font-semibold">Base Tuition Charge</td>
                        <td className="border border-slate-300 p-2 text-right font-mono">
                          PKR {selectedVoucher.amount.toLocaleString()}
                        </td>
                      </tr>
                      {selectedVoucher.discount > 0 && (
                        <tr>
                          <td className="border border-slate-300 p-2 text-rose-700 font-semibold">
                            Scholarship / Sibling Concession
                          </td>
                          <td className="border border-slate-300 p-2 text-right font-mono text-rose-700 font-bold">
                            -PKR {selectedVoucher.discount.toLocaleString()}
                          </td>
                        </tr>
                      )}
                      {selectedVoucher.fine > 0 && (
                        <tr>
                          <td className="border border-slate-300 p-2 text-amber-700 font-semibold">
                            Late Deposit Fine
                          </td>
                          <td className="border border-slate-300 p-2 text-right font-mono text-amber-700 font-bold">
                            +PKR {selectedVoucher.fine.toLocaleString()}
                          </td>
                        </tr>
                      )}
                      <tr className="bg-slate-50 font-bold">
                        <td className="border border-slate-300 p-2 uppercase">Net Amount Deposited</td>
                        <td className="border border-slate-300 p-2 text-right font-mono font-black text-emerald-800 text-sm">
                          PKR {selectedVoucher.netPayable.toLocaleString()}
                        </td>
                      </tr>
                    </tbody>
                  </table>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex justify-between items-center text-[11px]">
                    <div>
                      Payment Instrument: <strong>{selectedVoucher.paymentMethod}</strong> &bull; Received by:{' '}
                      <strong>{selectedVoucher.collectedBy}</strong>
                    </div>
                    <div className="font-mono text-slate-500">
                      Status:{' '}
                      <span className="font-bold text-emerald-700 uppercase">{selectedVoucher.status}</span>
                    </div>
                  </div>
                </div>
              </LetterheadPrint>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700 flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Printer className="w-4 h-4" />
                  Print Fee Voucher
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('single-fee-voucher', `Voucher_${selectedVoucher.voucherNo}`)}
                  className="px-3.5 py-2 bg-slate-800 text-white rounded-xl text-xs font-bold hover:bg-slate-700 flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <Download className="w-4 h-4" />
                  Download PDF
                </button>
              </div>

              <button
                type="button"
                onClick={() => setSelectedVoucher(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* PRINT ALL MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Fee Invoices & Collection Ledger (A4)</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('fees-print-table', 'TaleemOS_Fee_Collection_Report')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="fees-print-table">
              <LetterheadPrint
                title="INSTITUTIONAL FEE INVOICES & COLLECTION AUDIT LEDGER"
                documentNo="FEE-AUDIT-2026"
                summaryStats={[
                  { label: 'Total Invoices', value: state.fees.length },
                  { label: 'Collected Revenue', value: `PKR ${totalPaidRevenue.toLocaleString()}` },
                  { label: 'Pending Dues', value: `PKR ${totalUnpaidDues.toLocaleString()}` },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Voucher No</th>
                      <th className="border border-slate-300 p-2">Roll No</th>
                      <th className="border border-slate-300 p-2">Student Name</th>
                      <th className="border border-slate-300 p-2">Month</th>
                      <th className="border border-slate-300 p-2">Head</th>
                      <th className="border border-slate-300 p-2">Net Amount</th>
                      <th className="border border-slate-300 p-2">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtered.map((f) => (
                      <tr key={f.id}>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-indigo-700">
                          {f.voucherNo}
                        </td>
                        <td className="border border-slate-300 p-2 font-mono">{f.rollNo}</td>
                        <td className="border border-slate-300 p-2 font-bold">{f.studentName}</td>
                        <td className="border border-slate-300 p-2">{f.month}</td>
                        <td className="border border-slate-300 p-2">{f.feeHead}</td>
                        <td className="border border-slate-300 p-2 font-mono font-bold text-emerald-800">
                          PKR {f.netPayable.toLocaleString()}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold">{f.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
