import { useState, useEffect } from 'react';
import { AuthSystem, getCurrentUser, User, logout } from './components/auth/AuthSystem';
import * as DashboardMod from './modules/DashboardModule';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [showLogout, setShowLogout] = useState(false);

  useEffect(() => {
    const u = getCurrentUser();
    setUser(u);
    setLoading(false);
  }, []);

  if(loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if(!user) return <AuthSystem onLogin={(u)=>setUser(u)} />;

  const DashboardComponent = (DashboardMod as any).default || (DashboardMod as any).DashboardModule || (DashboardMod as any).Dashboard || DashboardMod;

  return (
    <div className="relative">
      {/* Top bar with logout + drawer toggle */}
      <div className="fixed top-0 right-0 z-[100] p-2 flex gap-2">
        <button onClick={()=>setShowLogout(!showLogout)} className="bg-white shadow-lg px-3 py-1 rounded-full text-xs font-bold">
          {user.name} ▾
        </button>
      </div>
      {showLogout && (
        <div className="fixed top-10 right-2 z-[101] bg-white shadow-xl rounded-xl p-3 w-48 border">
          <div className="text-xs font-bold">{user.email}</div>
          <div className="text-[10px] text-gray-500">{user.role} - {user.institutionName}</div>
          <button onClick={()=>{logout();}} className="mt-2 w-full bg-red-500 text-white text-xs py-2 rounded">Logout (Clear Login)</button>
          <button onClick={()=>setShowLogout(false)} className="mt-1 w-full bg-gray-100 text-xs py-1 rounded">Close</button>
        </div>
      )}
      {/* @ts-ignore */}
      <DashboardComponent user={user} />
    </div>
  );
}

export default App;
