import React, { useState, useEffect } from 'react';
import {
  Menu,
  Search,
  Bell,
  Shield,
  Building2,
  Download,
  Calendar,
  Clock,
  CheckCircle,
  Database,
} from 'lucide-react';
import { erpStorage, INSTITUTIONS } from '../../lib/storage';
import { type UserRole } from '../../types';

interface HeaderProps {
  onToggleMobileDrawer: () => void;
  onOpenSearch: () => void;
  onOpenApprovals: () => void;
  onOpenExportZip: () => void;
  onNavigate: (path: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onToggleMobileDrawer,
  onOpenSearch,
  onOpenApprovals,
  onOpenExportZip,
  onNavigate,
}) => {
  const state = erpStorage.getState();
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const roles: UserRole[] = [
    'Super Admin',
    'Director / Owner',
    'Principal',
    'Accountant',
    'Teacher',
    'Receptionist / Front Desk',
    'Student',
    'Parent',
  ];

  const pendingApprovalsCount = state.approvals.filter(
    (a) => a.status === 'Pending Approval'
  ).length;

  const currentInstitution =
    INSTITUTIONS.find((i) => i.id === state.activeInstitutionId) || INSTITUTIONS[0];

  const handleRoleChange = (newRole: UserRole) => {
    erpStorage.setActiveRole(newRole);
  };

  const handleInstitutionChange = (instId: string) => {
    erpStorage.setActiveInstitution(instId);
  };

  const formattedDate = currentTime.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  const formattedTime = currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <header className="sticky top-0 z-20 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white border-b border-indigo-900/40 shadow-lg no-print">
      {/* Top Header Row */}
      <div className="px-4 md:px-6 py-2.5 flex items-center justify-between gap-2 md:gap-4">
        {/* Left side: Hamburger (mobile) + Campus selector */}
        <div className="flex items-center gap-2 md:gap-4">
          <button
            type="button"
            onClick={onToggleMobileDrawer}
            className="md:hidden p-2 text-slate-300 hover:text-white rounded-xl hover:bg-white/10 cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Campus Multi-Tenant Switcher */}
          <div className="flex items-center gap-2 bg-white/10 hover:bg-white/15 backdrop-blur-md px-3 py-1.5 rounded-xl border border-white/10 transition-colors">
            <Building2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <select
              value={state.activeInstitutionId}
              onChange={(e) => handleInstitutionChange(e.target.value)}
              className="bg-transparent text-xs font-bold text-white focus:outline-none cursor-pointer pr-1"
            >
              {INSTITUTIONS.map((inst) => (
                <option key={inst.id} value={inst.id} className="bg-slate-900 text-white">
                  {inst.campusName} ({inst.code})
                </option>
              ))}
            </select>
          </div>

          {/* Live Date / Time */}
          <div className="hidden lg:flex items-center gap-3 text-xs text-slate-300 border-l border-white/10 pl-3">
            <div className="flex items-center gap-1.5 font-medium">
              <Calendar className="w-3.5 h-3.5 text-indigo-400" />
              <span>{formattedDate}</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-indigo-200 bg-white/5 px-2 py-0.5 rounded">
              <Clock className="w-3 h-3 text-indigo-400" />
              <span>{formattedTime}</span>
            </div>
          </div>
        </div>

        {/* Center / Right side: Search, Role Switcher, Approvals, ZIP Export */}
        <div className="flex items-center gap-2 md:gap-3">
          {/* Spotlight Search Trigger */}
          <button
            type="button"
            onClick={onOpenSearch}
            className="flex items-center gap-2 px-3 py-1.5 bg-white/10 hover:bg-white/15 backdrop-blur-md border border-white/10 rounded-xl text-xs text-slate-300 hover:text-white transition-all cursor-pointer"
          >
            <Search className="w-3.5 h-3.5 text-indigo-300" />
            <span className="hidden sm:inline">Search Hub</span>
            <kbd className="hidden sm:inline-block px-1.5 py-0.2 bg-black/30 text-[10px] font-mono rounded text-slate-300">
              Ctrl+K
            </kbd>
          </button>

          {/* RBAC Role Switcher */}
          <div className="flex items-center gap-1.5 bg-indigo-600/30 hover:bg-indigo-600/40 backdrop-blur-md px-2.5 py-1.5 rounded-xl border border-indigo-400/30">
            <Shield className="w-3.5 h-3.5 text-amber-300 shrink-0" />
            <div className="flex flex-col text-left">
              <span className="text-[9px] uppercase font-bold text-indigo-200 leading-none">
                Active Role
              </span>
              <select
                value={state.activeRole}
                onChange={(e) => handleRoleChange(e.target.value as UserRole)}
                className="bg-transparent text-xs font-bold text-amber-300 focus:outline-none cursor-pointer"
              >
                {roles.map((r) => (
                  <option key={r} value={r} className="bg-slate-900 text-white">
                    {r}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Approvals Center Bell Trigger */}
          <button
            type="button"
            onClick={onOpenApprovals}
            title="Open Approvals Center"
            className="relative p-2 bg-white/10 hover:bg-white/15 text-slate-200 hover:text-white rounded-xl border border-white/10 transition-colors cursor-pointer"
          >
            <Bell className="w-4 h-4" />
            {pendingApprovalsCount > 0 && (
              <span className="absolute -top-1 -right-1 px-1.5 py-0.2 bg-rose-500 text-white font-black text-[10px] rounded-full animate-bounce shadow">
                {pendingApprovalsCount}
              </span>
            )}
          </button>

          {/* Termux ZIP Export Button */}
          <button
            type="button"
            onClick={onOpenExportZip}
            title="Download ZIP for Termux"
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-black rounded-xl shadow-md shadow-emerald-900/30 active:scale-95 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export ZIP</span>
          </button>
        </div>
      </div>

      {/* Header Embedded KPIs Row */}
      <div className="px-4 md:px-6 py-2 bg-black/25 border-t border-white/5 flex items-center justify-between overflow-x-auto text-xs whitespace-nowrap gap-4 scrollbar-none">
        <div className="flex items-center gap-6">
          <div
            onClick={() => onNavigate('students')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Students:</span>
            <span className="font-extrabold text-white font-mono">{state.students.length}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          </div>

          <div
            onClick={() => onNavigate('admissions')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Confirmed Adm:</span>
            <span className="font-extrabold text-emerald-300 font-mono">
              {state.admissions.filter((a) => a.status === 'Confirmed').length}
            </span>
          </div>

          <div
            onClick={() => onNavigate('batches')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Active Batches:</span>
            <span className="font-extrabold text-indigo-300 font-mono">
              {state.batches.filter((b) => b.status === 'Active').length}
            </span>
          </div>

          <div
            onClick={() => onNavigate('fees')}
            className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          >
            <span className="text-[11px] text-slate-400 uppercase font-semibold">October Fee Col:</span>
            <span className="font-extrabold text-amber-300 font-mono">
              PKR{' '}
              {state.fees
                .filter((f) => f.status === 'Paid')
                .reduce((acc, curr) => acc + curr.netPayable, 0)
                .toLocaleString()}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-slate-400 text-[11px]">
          <Database className="w-3 h-3 text-cyan-400" />
          <span>Storage: Local + Firebase Sync</span>
        </div>
      </div>
    </header>
  );
};
