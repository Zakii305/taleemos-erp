import React, { useState } from 'react';
import { INSTITUTIONS } from '../../data/institutions';
import { db } from '../../lib/firebase';
import { collection, query, where, getDocs, addDoc, doc, setDoc } from 'firebase/firestore';

export type Role = 'developer' | 'admin' | 'teacher' | 'student' | 'parent';
export interface User {
  id: string; name: string; email: string; password?: string; role: Role;
  institutionId: string; institutionName: string; institutionType?: string;
  phone?: string; status: 'pending' | 'approved' | 'rejected'; createdAt?: number;
}
const DEV_EMAILS = ['sajjadaliqasmi@gmail.com','socialman121@gmail.com'];
export const getCurrentUser = (): User | null => { try { return JSON.parse(localStorage.getItem('taleemos_current_user_v5')||'null'); } catch { return null; } };
export const logout = () => { localStorage.clear(); location.reload(); };

export const AuthSystem = ({ onLogin }: { onLogin: (u: User) => void }) => {
  const [mode, setMode] = useState<'login'|'signup'>('login');
  const [form, setForm] = useState({ name:'', email:'', phone:'', password:'', confirm:'', role:'admin' as Role, institutionId: INSTITUTIONS[0].id, institutionName:'', institutionType:'Academy' });
  const [error, setError] = useState(''); const [loading, setLoading] = useState(false);
  const [remember, setRemember] = useState(true);
  const [showPending, setShowPending] = useState(false); const [pendingData, setPendingData] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault(); setError('');
    if(mode==='signup' && form.password!==form.confirm){ setError('Passwords do not match'); return; }
    setLoading(true);
    const email = form.email.toLowerCase().trim();
    const isDev = DEV_EMAILS.includes(email);
    const inst = INSTITUTIONS.find(i=>i.id===form.institutionId);
    try{
      if(mode==='signup'){
        if(db){
          const s1 = await getDocs(query(collection(db,"users"), where("email","==",email)));
          if(!s1.empty){ setError('Email already registered. Please login.'); setLoading(false); return; }
          const s2 = await getDocs(query(collection(db,"approval_requests"), where("email","==",email)));
          if(!s2.empty){ setError('Request already pending approval.'); setLoading(false); return; }
        }
        if(isDev){
          const dev:User={ id: Date.now().toString(), name: form.name||'Developer', email, password: form.password, role:'developer', institutionId:'all', institutionName:'ALL INSTITUTIONS', status:'approved', createdAt: Date.now() };
          if(db) await setDoc(doc(db,"users", dev.id), dev);
          localStorage.setItem('taleemos_current_user_v5', JSON.stringify(dev)); onLogin(dev);
        } else {
          const req = { id: Date.now().toString(), name: form.name.trim(), email, phone: form.phone.trim(), password: form.password, role: form.role, institutionId: inst?.id||'custom', institutionName: form.institutionName||inst?.name||'', institutionType: form.institutionType, status:'pending', createdAt: Date.now() };
          if(db) await addDoc(collection(db,"approval_requests"), req);
          setPendingData(req); setShowPending(true); setLoading(false); return;
        }
      } else {
        let found:User|null=null;
        if(db){
          const snap = await getDocs(query(collection(db,"users"), where("email","==",email)));
          if(!snap.empty) found = snap.docs[0].data() as User;
          else { const s2 = await getDocs(query(collection(db,"approval_requests"), where("email","==",email))); if(!s2.empty) throw new Error('PENDING'); }
        }
        if(!found && isDev) found={ id:'dev', name:'Developer', email, role:'developer', institutionId:'all', institutionName:'ALL INSTITUTIONS', status:'approved', createdAt: Date.now() } as User;
        if(!found) throw new Error('No account found. Please sign up first.');
        localStorage.setItem('taleemos_current_user_v5', JSON.stringify(found)); onLogin(found);
      }
    }catch(err:any){
      if(err.message==='PENDING'){ setPendingData({ email }); setShowPending(true); }
      else setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-[#E9BCB3] flex items-center justify-center p-5 relative">
      {/* Pending Modal - same palette */}
      {showPending && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-5">
          <div onClick={()=>setShowPending(false)} className="absolute inset-0 bg-[#4a5a6a]/60 backdrop-blur-sm"/>
          <div className="relative bg-white rounded-[32px] w-full max-w-[380px] p-8 text-center shadow-2xl">
            <div className="w-16 h-16 bg-[#4a5a6a] rounded-full flex items-center justify-center mx-auto text-white text-2xl">✓</div>
            <h3 className="text-[20px] font-bold tracking-wide text-[#4a5a6a] mt-4">REQUEST SENT</h3>
            <p className="text-[13px] text-[#7a8a9a] mt-2">Your account for <b>{pendingData?.email}</b> is pending approval.</p>
            <button onClick={()=>{ setShowPending(false); setMode('login'); }} className="w-full mt-6 h-[48px] rounded-full bg-[#4a5a6a] text-white font-semibold">OKAY</button>
          </div>
        </div>
      )}

      <div className="w-full max-w-[380px] flex flex-col items-center">
        {/* Avatar - Reference exact */}
        <div className="relative mb-8">
          <div className="w-[108px] h-[108px] rounded-full border-[3px] border-white flex items-center justify-center p-1.5">
            <div className="w-full h-full rounded-full bg-[#4A5A6B] flex items-center justify-center">
              <svg width="56" height="56" viewBox="0 0 24 24" fill="white"><circle cx="12" cy="8" r="4.5"/><path d="M4 20c0-4.4 3.6-8 8-8s8 3.6 8 8v1H4v-1z"/></svg>
            </div>
          </div>
        </div>

        <h1 className="text-white text-[24px] font-[300] tracking-[0.2em] mb-8">{mode==='login' ? 'USER SIGN IN' : 'USER SIGN UP'}</h1>

        {error && <div className="w-full mb-4 bg-white/90 text-[#4a5a6a] text-[12px] px-4 py-3 rounded-full text-center font-semibold">{error}</div>}

        <form onSubmit={handleSubmit} className="w-full flex flex-col gap-4">
          {mode==='login' ? (
            <>
              {/* Username - Reference style */}
              <div className="flex items-center gap-3 w-full">
                <div className="w-10 h-10 flex items-center justify-center shrink-0">
                  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#4A5A6B" strokeWidth="1.2"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.5-7 8-7s8 3 8 7"/></svg>
                </div>
                <div className="flex-1 h-[46px] rounded-full border border-white p-[3px] bg-transparent">
                  <input value={form.email} onChange={e=>setForm({...form, email:e.target.value})} placeholder="Username" type="text" className="w-full h-full rounded-full bg-[#4A5A6B] text-white placeholder:text-white/80 text-[14px] text-center outline-none px-4" required />
                </div>
              </div>

              {/* Password - Reference style */}
              <div className="flex items-center gap-3 w-full">
                <div className="w-10 h-10 flex items-center justify-center shrink-0">
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#4A5A6B" strokeWidth="1.2"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="16" r="1.5" fill="#4A5A6B"/></svg>
                </div>
                <div className="flex-1 h-[46px] rounded-full border border-white p-[3px]">
                  <input value={form.password} onChange={e=>setForm({...form, password:e.target.value})} placeholder="Password" type="password" className="w-full h-full rounded-full bg-[#4A5A6B] text-white placeholder:text-white/80 text-[14px] text-center outline-none px-4" required />
                </div>
              </div>

              <div className="flex items-center justify-between px-2 mt-1 mb-1 w-full">
                <label className="flex items-center gap-2 cursor-pointer">
                  <button type="button" onClick={()=>setRemember(!remember)} className={`w-7 h-7 rounded-full flex items-center justify-center border-2 transition ${remember?'bg-[#4A5A6B] border-[#4A5A6B] text-white':'bg-transparent border-white'}`}>
                    {remember && <span className="text-[12px]">✓</span>}
                  </button>
                  <span className="text-white text-[12px] font-light tracking-wide">Remember me</span>
                </label>
                <button type="button" className="text-[#4A5A6B] text-[12px] italic">Forgot Password?</button>
              </div>

              <div className="flex justify-center mt-2">
                <button disabled={loading} className="w-[72%] h-[46px] rounded-full bg-[#4A5A6B] text-white text-[16px] tracking-widest font-[400] shadow-sm disabled:opacity-60">
                  {loading ? '...' : 'LOGIN'}
                </button>
              </div>
            </>
          ) : (
            <>
              {/* SIGN UP - Detailed but same colour */}
              <div className="flex items-center gap-3"><div className="w-8 h-8 flex items-center justify-center"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#4A5A6B" strokeWidth="1.2"><circle cx="12" cy="8" r="3.5"/><path d="M4 20c0-3.5 3.5-6 8-6s8 2.5 8 6"/></svg></div><div className="flex-1 h-[42px] rounded-full border border-white p-[3px]"><input value={form.name} onChange={e=>setForm({...form, name:e.target.value})} placeholder="Full Name" className="w-full h-full rounded-full bg-[#4A5A6B] text-white placeholder:text-white/70 text-[13px] text-center outline-none px-3" required /></div></div>
              <div className="flex items-center gap-3"><div className="w-8 h-8 flex items-center justify-center text-[#4A5A6B] text-[12px]">@</div><div className="flex-1 h-[42px] rounded-full border border-white p-[3px]"><input value={form.email} onChange={e=>setForm({...form, email:e.target.value})} placeholder="Work Email" type="email" className="w-full h-full rounded-full bg-[#4A5A6B] text-white placeholder:text-white/70 text-[13px] text-center outline-none px-3" required /></div></div>
              <div className="flex items-center gap-3"><div className="w-8 h-8 flex items-center justify-center"><span className="text-[#4A5A6B] text-[14px]">📞</span></div><div className="flex-1 h-[42px] rounded-full border border-white p-[3px]"><input value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} placeholder="Phone Number" className="w-full h-full rounded-full bg-[#4A5A6B] text-white placeholder:text-white/70 text-[13px] text-center outline-none px-3" /></div></div>
              <div className="flex items-center gap-3"><div className="w-8 h-8 flex items-center justify-center"><span className="text-[#4A5A6B] text-[14px]">🏫</span></div><div className="flex-1 h-[42px] rounded-full border border-white p-[3px]"><input value={form.institutionName} onChange={e=>setForm({...form, institutionName:e.target.value})} placeholder="Institution Name" className="w-full h-full rounded-full bg-[#4A5A6B] text-white placeholder:text-white/70 text-[13px] text-center outline-none px-3" required /></div></div>

              <div className="grid grid-cols-2 gap-3 ml-11">
                <div className="h-[40px] rounded-full border border-white p-[3px]"><select value={form.institutionType} onChange={e=>setForm({...form, institutionType:e.target.value})} className="w-full h-full rounded-full bg-[#4A5A6B] text-white text-[12px] text-center outline-none"><option>Academy</option><option>School</option><option>College</option><option>Institute</option></select></div>
                <div className="h-[40px] rounded-full border border-white p-[3px]"><select value={form.role} onChange={e=>setForm({...form, role:e.target.value as any})} className="w-full h-full rounded-full bg-[#4A5A6B] text-white text-[12px] text-center outline-none"><option value="admin">Admin</option><option value="teacher">Teacher</option></select></div>
              </div>

              <div className="flex items-center gap-3"><div className="w-8 h-8 flex items-center justify-center"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4A5A6B" strokeWidth="1.2"><rect x="4" y="11" width="16" height="8" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg></div><div className="flex-1 h-[42px] rounded-full border border-white p-[3px]"><input value={form.password} onChange={e=>setForm({...form, password:e.target.value})} placeholder="Password" type="password" className="w-full h-full rounded-full bg-[#4A5A6B] text-white placeholder:text-white/70 text-[13px] text-center outline-none px-3" required /></div></div>
              <div className="flex items-center gap-3"><div className="w-8 h-8 flex items-center justify-center"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4A5A6B" strokeWidth="1.2"><rect x="4" y="11" width="16" height="8" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg></div><div className="flex-1 h-[42px] rounded-full border border-white p-[3px]"><input value={form.confirm} onChange={e=>setForm({...form, confirm:e.target.value})} placeholder="Confirm Password" type="password" className="w-full h-full rounded-full bg-[#4A5A6B] text-white placeholder:text-white/70 text-[13px] text-center outline-none px-3" required /></div></div>

              <div className="flex justify-center mt-2"><button disabled={loading} className="w-[72%] h-[46px] rounded-full bg-[#4A5A6B] text-white text-[14px] tracking-widest">{loading ? 'SUBMITTING...' : 'SIGN UP'}</button></div>
            </>
          )}

          <div className="flex justify-center mt-6 gap-3">
            <button type="button" onClick={()=>setMode(mode==='login'?'signup':'login')} className="text-[12px] text-white/90 underline underline-offset-4 tracking-wide">
              {mode==='login' ? 'New user? Create account' : 'Already have account? Sign in'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
