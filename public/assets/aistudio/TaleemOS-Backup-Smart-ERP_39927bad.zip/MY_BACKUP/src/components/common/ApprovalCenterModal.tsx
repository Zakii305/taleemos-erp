import React, { useState } from 'react';
import { CheckCircle, XCircle, Clock, ShieldCheck, AlertCircle } from 'lucide-react';
import { Modal } from './Modal';
import { erpStorage } from '../../lib/storage';
import { type UserRole, type ApprovalRequest } from '../../types';

interface ApprovalCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeRole: UserRole;
}

export const ApprovalCenterModal: React.FC<ApprovalCenterModalProps> = ({
  isOpen,
  onClose,
  activeRole,
}) => {
  const [rejectingId, setRejectingId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const state = erpStorage.getState();

  // Role permissions check
  const canApprove = (req: ApprovalRequest): boolean => {
    if (activeRole === 'Super Admin') return true;
    if (activeRole === 'Director / Owner') {
      return (
        req.module === 'Admission Confirmed' ||
        req.module === 'Fee Discount > 500' ||
        req.module === 'Expense > 5000'
      );
    }
    if (activeRole === 'Principal') {
      return (
        req.module === 'Staff Leave' ||
        req.module === 'Student Promotion' ||
        req.module === 'Marks Final Submit'
      );
    }
    return false;
  };

  const handleApprove = (req: ApprovalRequest) => {
    erpStorage.approveRequest(req.id, 'Approved via TaleemOS Approval Center');
  };

  const handleConfirmReject = (req: ApprovalRequest) => {
    if (!rejectReason.trim()) return;
    erpStorage.rejectRequest(req.id, rejectReason.trim());
    setRejectingId(null);
    setRejectReason('');
  };

  const pendingApprovals = state.approvals.filter((a) => a.status === 'Pending Approval');
  const pastApprovals = state.approvals.filter((a) => a.status !== 'Pending Approval');

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Enterprise Approval Center"
      subtitle={`Review and authorize pending institution requests. Active Role: ${activeRole}`}
      badge="HIERARCHICAL RBAC"
      maxWidth="max-w-4xl"
    >
      <div className="space-y-6">
        {/* Pending approvals section */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-500" />
              Pending Requests Queue ({pendingApprovals.length})
            </h4>
            <span className="text-xs text-slate-500">
              Only authorized roles can authorize actions
            </span>
          </div>

          {pendingApprovals.length === 0 ? (
            <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200">
              <ShieldCheck className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-700">All clear! No pending approvals.</p>
              <p className="text-xs text-slate-500 mt-0.5">Requests will automatically appear here.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {pendingApprovals.map((req) => {
                const userCanAuthorize = canApprove(req);
                return (
                  <div
                    key={req.id}
                    className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="px-2.5 py-0.5 bg-amber-100 text-amber-800 text-[10px] font-black rounded-full uppercase">
                            {req.module}
                          </span>
                          <span className="text-xs font-mono font-bold text-slate-400">
                            {req.id}
                          </span>
                          <span className="text-xs text-slate-500">
                            Requested by: <strong className="text-slate-800">{req.requestedBy}</strong> ({req.requestedRole})
                          </span>
                        </div>
                        <h5 className="font-bold text-slate-900 text-sm mt-1">{req.title}</h5>
                        {req.amountOrValue && (
                          <div className="text-xs font-mono text-indigo-700 font-bold mt-0.5">
                            Value: {req.amountOrValue}
                          </div>
                        )}
                        {req.reason && (
                          <p className="text-xs text-slate-600 mt-1 italic bg-slate-50 p-2 rounded-lg border border-slate-100">
                            &ldquo;{req.reason}&rdquo;
                          </p>
                        )}
                      </div>

                      {/* Approval Buttons */}
                      <div className="flex items-center gap-2 shrink-0">
                        {userCanAuthorize ? (
                          <>
                            <button
                              type="button"
                              onClick={() => handleApprove(req)}
                              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-600/30 flex items-center gap-1.5 cursor-pointer transition-all"
                            >
                              <CheckCircle className="w-4 h-4" />
                              Authorize
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setRejectingId(req.id);
                                setRejectReason('');
                              }}
                              className="px-3.5 py-2 bg-rose-100 hover:bg-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                            >
                              <XCircle className="w-4 h-4" />
                              Reject
                            </button>
                          </>
                        ) : (
                          <div className="px-3 py-1.5 bg-slate-100 text-slate-500 text-xs rounded-xl flex items-center gap-1.5 font-medium">
                            <AlertCircle className="w-4 h-4 text-slate-400" />
                            <span>Requires: {req.currentApproverRole}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Rejection reason inline form */}
                    {rejectingId === req.id && (
                      <div className="mt-3 p-3 bg-rose-50 rounded-xl border border-rose-200 animate-in fade-in">
                        <label className="block text-xs font-bold text-rose-800 mb-1">
                          Specify reason for rejection (mandatory):
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            value={rejectReason}
                            onChange={(e) => setRejectReason(e.target.value)}
                            placeholder="e.g. Budget exceeded, missing supporting documents..."
                            className="flex-1 px-3 py-1.5 bg-white border border-rose-300 rounded-lg text-xs outline-none focus:ring-2 focus:ring-rose-500"
                          />
                          <button
                            type="button"
                            onClick={() => handleConfirmReject(req)}
                            className="px-3 py-1.5 bg-rose-600 text-white text-xs font-bold rounded-lg hover:bg-rose-700 cursor-pointer"
                          >
                            Confirm Reject
                          </button>
                          <button
                            type="button"
                            onClick={() => setRejectingId(null)}
                            className="px-2 py-1.5 text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Audit history of processed approvals */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-2 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-slate-500" />
            Decision History
          </h4>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {pastApprovals.map((req) => (
              <div
                key={req.id}
                className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex items-center justify-between"
              >
                <div>
                  <span className="font-bold text-slate-800">{req.title}</span>
                  <div className="text-[11px] text-slate-500 font-mono">
                    {req.date} &bull; Requested by {req.requestedBy}
                  </div>
                </div>
                <span
                  className={`px-2 py-0.5 font-bold rounded-full text-[10px] ${
                    req.status === 'Approved'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-rose-100 text-rose-800'
                  }`}
                >
                  {req.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
};
