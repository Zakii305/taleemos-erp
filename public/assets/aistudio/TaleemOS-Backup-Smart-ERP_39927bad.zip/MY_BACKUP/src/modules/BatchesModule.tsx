import React, { useState } from 'react';
import { GraduationCap, Plus, Printer, Search, Trash2, X, Users, Clock } from 'lucide-react';

type Batch = {
  id: string; batchName: string; course: string; teacher: string;
  room: string; capacity: number; enrolled: number;
  timing: string; status: 'Active'|'Upcoming'|'Completed'; startDate: string; endDate: string;
  feeStructure: string; remarks: string;
};

const INITIAL: Batch[] = [
  { id:'BAT-01', batchName:'Batch 2026-A (Morning)', course:'F.Sc Pre-Engineering', teacher:'Sir Sajjad Ahmed', room:'Room 101', capacity:40, enrolled:32, timing:'08:00 AM - 12:00 PM', status:'Active', startDate:'2026-03-01', endDate:'2027-05-30', feeStructure:'PKR 4000/month', remarks:'Board preparation batch' },
  { id:'BAT-02', batchName:'Batch 2026-B (Morning)', course:'F.Sc Pre-Medical', teacher:'Miss Ayesha Khan', room:'Room 102', capacity:40, enrolled:28, timing:'08:00 AM - 12:00 PM', status:'Active', startDate:'2026-03-01', endDate:'2027-05-30', feeStructure:'PKR 4000/month', remarks:'Medical entry test included' },
  { id:'BAT-03', batchName:'Batch 2026-C (Afternoon)', course:'ICS', teacher:'Dr. Usman Ali', room:'Lab 12', capacity:30, enrolled:22, timing:'02:00 PM - 06:00 PM', status:'Active', startDate:'2026-04-01', endDate:'2027-05-30', feeStructure:'PKR 3500/month', remarks:'Computer lab batch' },
  { id:'BAT-04', batchName:'Batch 2025-A (Morning)', course:'9th Standard', teacher:'Sir Bilal Raza', room:'Room 103', capacity:35, enrolled:35, timing:'08:00 AM - 01:00 PM', status:'Completed', startDate:'2025-03-01', endDate:'2026-02-28', feeStructure:'PKR 3000/month', remarks:'Completed session' },
  { id:'BAT-05', batchName:'Batch 2026-D (Evening)', course:'Commerce', teacher:'Sir Ghulam Rasool', room:'Room 104', capacity:25, enrolled:12, timing:'04:00 PM - 07:00 PM', status:'Upcoming', startDate:'2026-05-01', endDate:'2027-05-30', feeStructure:'PKR 3000/month', remarks:'New admissions open' },
];

export default function BatchesModule() {
  const [batches, setBatches] = useState<Batch[]>(INITIAL);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selected, setSelected] = useState<Batch | null>(null);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [form, setForm] = useState({ batchName:'', course:'F.Sc Pre-Engineering', teacher:'Sir Sajjad Ahmed', room:'Room 101', capacity:40, enrolled:0, timing:'08:00 AM - 12:00 PM', status:'Active' as any, startDate:'2026-03-01', endDate:'2027-05-30', fee:'PKR 4000/month', remarks:'' });

  const filtered = batches.filter(b=>{
    const ms = b.batchName.toLowerCase().includes(search.toLowerCase()) || b.course.toLowerCase().includes(search.toLowerCase()) || b.teacher.toLowerCase().includes(search.toLowerCase());
    const mst = statusFilter==='All' || b.status===statusFilter;
    return ms && mst;
  });

  const totalCapacity = batches.reduce((s,b)=>s+b.capacity,0);
  const totalEnrolled = batches.reduce((s,b)=>s+b.enrolled,0);

  const handleSave = (e: React.FormEvent)=>{
    e.preventDefault();
    if(!form.batchName.trim()) return;
    if(isEdit && selected){
      setBatches(batches.map(b=> b.id===selected.id ? { ...b, batchName:form.batchName, course:form.course, teacher:form.teacher, room:form.room, capacity:Number(form.capacity), enrolled:Number(form.enrolled), timing:form.timing, status:form.status, startDate:form.startDate, endDate:form.endDate, feeStructure:form.fee, remarks:form.remarks } : b));
    } else {
      const nb: Batch = { id:`BAT-0${batches.length+1}`, batchName:form.batchName, course:form.course, teacher:form.teacher, room:form.room, capacity:Number(form.capacity), enrolled:Number(form.enrolled), timing:form.timing, status:form.status, startDate:form.startDate, endDate:form.endDate, feeStructure:form.fee, remarks:form.remarks };
      setBatches([...batches, nb]);
    }
    setIsAddOpen(false); setIsEdit(false); setSelected(null);
    setForm({ batchName:'', course:'F.Sc Pre-Engineering', teacher:'Sir Sajjad Ahmed', room:'Room 101', capacity:40, enrolled:0, timing:'08:00 AM - 12:00 PM', status:'Active', startDate:'2026-03-01', endDate:'2027-05-30', fee:'PKR 4000/month', remarks:'' });
  };

  const plusOne = (b: Batch, e: React.MouseEvent)=>{
    e.stopPropagation();
    if(b.enrolled < b.capacity){
      setBatches(batches.map(x=> x.id===b.id ? { ...x, enrolled: x.enrolled+1 } : x));
    } else alert(`Batch ${b.batchName} has reached full capacity of ${b.capacity} students.`);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><GraduationCap className="w-5 h-5" /></span><h1 className="text-xl font-black">Academic Batches & Cohorts</h1><span className="px-2 py-0.5 bg-indigo-500 text-[10px] font-black rounded uppercase">12 FIELDS • ORIGINAL SAFE</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Batch scheduling, instructor assignment, capacity quotas, timing & fee structure</p></div>
        <div className="flex gap-2"><button onClick={()=>window.print()} className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-xl border border-white/20 flex items-center gap-1.5"><Printer className="w-4 h-4" />Print All Batches</button><button onClick={()=>{ setIsEdit(false); setForm({ batchName:'', course:'F.Sc Pre-Engineering', teacher:'Sir Sajjad Ahmed', room:'Room 101', capacity:40, enrolled:0, timing:'08:00 AM - 12:00 PM', status:'Active', startDate:'2026-03-01', endDate:'2027-05-30', fee:'PKR 4000/month', remarks:'' }); setIsAddOpen(true); }} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4" />Add New Batch</button></div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="p-4 bg-white rounded-[20px] border"><div className="text-[10px] font-bold text-slate-400 uppercase">Total Batches</div><div className="text-2xl font-black font-mono">{batches.length}</div></div>
        <div className="p-4 bg-white rounded-[20px] border"><div className="text-[10px] font-bold text-indigo-600 uppercase">Total Capacity</div><div className="text-2xl font-black text-indigo-600 font-mono">{totalCapacity}</div></div>
        <div className="p-4 bg-white rounded-[20px] border"><div className="text-[10px] font-bold text-emerald-600 uppercase">Total Enrolled</div><div className="text-2xl font-black text-emerald-600 font-mono">{totalEnrolled}</div></div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm space-y-3">
        <div className="relative"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" /><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search batches by name, course, or instructor..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500" /></div>
        <div className="flex flex-wrap gap-2 text-xs"><span className="text-[10px] font-bold text-slate-400 uppercase">Status:</span>{['All','Active','Upcoming','Completed'].map(s=><button key={s} onClick={()=>setStatusFilter(s)} className={`px-3 py-1 rounded-full text-[11px] font-bold ${statusFilter===s?'bg-indigo-600 text-white':'bg-slate-100 text-slate-600'}`}>{s}</button>)}</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(b=>(
          <div key={b.id} onClick={()=>setSelected(b)} className="p-5 bg-white rounded-[22px] border shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between">
            <div>
              <div className="flex justify-between items-start gap-2"><span className="px-2.5 py-0.5 text-xs font-mono font-black bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200">{b.id}</span><span className={`px-2 py-0.2 rounded-full text-[10px] font-black uppercase ${b.status==='Active'?'bg-emerald-100 text-emerald-800':b.status==='Upcoming'?'bg-amber-100 text-amber-800':'bg-slate-100 text-slate-600'}`}>{b.status}</span></div>
              <h3 className="mt-3 text-base font-extrabold leading-snug">{b.batchName}</h3><p className="text-xs text-slate-500 font-medium">{b.course}</p>
              <div className="mt-3 p-3 bg-slate-50 rounded-xl border grid grid-cols-2 gap-2 text-xs"><div><span className="text-[10px] text-slate-400 uppercase block">Teacher</span><span className="font-bold">{b.teacher}</span></div><div><span className="text-[10px] text-slate-400 uppercase block">Room</span><span className="font-bold">{b.room}</span></div><div><span className="text-[10px] text-slate-400 uppercase block flex items-center gap-1"><Clock className="w-3 h-3" />Timing</span><span className="font-mono font-bold text-[11px]">{b.timing}</span></div><div><span className="text-[10px] text-slate-400 uppercase block">Fee</span><span className="font-bold text-indigo-700">{b.feeStructure}</span></div></div>
              <div className="mt-3 p-2.5 bg-indigo-50 rounded-xl border border-indigo-200 flex items-center justify-between"><div className="flex items-center gap-1.5"><Users className="w-4 h-4 text-indigo-600" /><span className="text-xs font-bold text-indigo-900">{b.enrolled} / {b.capacity} Students</span></div><div className="w-16 h-1.5 bg-indigo-200 rounded-full overflow-hidden"><div className="h-full bg-indigo-600 rounded-full" style={{width:`${(b.enrolled/b.capacity)*100}%`}} /></div></div>
            </div>
            <div className="mt-4 pt-3 border-t flex justify-between text-xs"><button onClick={(e)=>plusOne(b,e)} className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full text-[10px] font-bold">+1 Enroll</button><div className="flex gap-1"><button onClick={(e)=>{ e.stopPropagation(); setSelected(b); setForm({ batchName:b.batchName, course:b.course, teacher:b.teacher, room:b.room, capacity:b.capacity, enrolled:b.enrolled, timing:b.timing, status:b.status, startDate:b.startDate, endDate:b.endDate, fee:b.feeStructure, remarks:b.remarks }); setIsEdit(true); setIsAddOpen(true); }} className="p-1 text-slate-400 hover:text-indigo-600">Edit</button><button onClick={(e)=>{ e.stopPropagation(); setBatches(batches.filter(x=>x.id!==b.id)); }} className="p-1 text-slate-400 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button></div></div>
          </div>
        ))}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[720px] p-6 max-h-[90vh] overflow-y-auto"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">{isEdit?'Edit Batch Cohort':'Add New Academic Batch'}</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><p className="text-xs text-slate-500 mb-4">Configure schedule, instructor assignment, and capacity quotas — 12 FIELDS ORIGINAL</p><form onSubmit={handleSave} className="space-y-4"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Batch Name *</label><input required value={form.batchName} onChange={e=>setForm({...form, batchName:e.target.value})} placeholder="Batch 2026-A (Morning)" className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none focus:border-indigo-600" /></div><div><label className="block text-xs font-bold uppercase mb-1">Course *</label><input required value={form.course} onChange={e=>setForm({...form, course:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div></div><div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Teacher</label><input value={form.teacher} onChange={e=>setForm({...form, teacher:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div><div><label className="block text-xs font-bold uppercase mb-1">Room</label><input value={form.room} onChange={e=>setForm({...form, room:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono" /></div></div><div className="grid grid-cols-3 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Capacity</label><input type="number" value={form.capacity} onChange={e=>setForm({...form, capacity:Number(e.target.value)})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono font-bold" /></div><div><label className="block text-xs font-bold uppercase mb-1">Enrolled</label><input type="number" value={form.enrolled} onChange={e=>setForm({...form, enrolled:Number(e.target.value)})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono" /></div><div><label className="block text-xs font-bold uppercase mb-1">Status</label><select value={form.status} onChange={e=>setForm({...form, status:e.target.value as any})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white"><option>Active</option><option>Upcoming</option><option>Completed</option></select></div></div><div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Timing</label><input value={form.timing} onChange={e=>setForm({...form, timing:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono" /></div><div><label className="block text-xs font-bold uppercase mb-1">Fee Structure</label><input value={form.fee} onChange={e=>setForm({...form, fee:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div></div><div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Start Date</label><input type="date" value={form.startDate} onChange={e=>setForm({...form, startDate:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div><div><label className="block text-xs font-bold uppercase mb-1">End Date</label><input type="date" value={form.endDate} onChange={e=>setForm({...form, endDate:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div></div><div><label className="block text-xs font-bold uppercase mb-1">Remarks</label><textarea value={form.remarks} onChange={e=>setForm({...form, remarks:e.target.value})} rows={2} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div><div className="pt-3 flex justify-end gap-2 border-t"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-4 py-2 border rounded-xl text-xs font-bold">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-black">{isEdit?'Update Batch':'Save Batch'}</button></div></form></div></div>
      )}

      {selected && !isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setSelected(null)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[560px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">{selected.batchName}</h3><button onClick={()=>setSelected(null)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><div className="p-4 bg-slate-50 rounded-xl border grid grid-cols-2 gap-3 text-xs"><div><span className="text-slate-400 block text-[10px]">COURSE</span><strong>{selected.course}</strong></div><div><span className="text-slate-400 block text-[10px]">TEACHER</span><strong>{selected.teacher}</strong></div><div><span className="text-slate-400 block text-[10px]">ROOM</span><strong>{selected.room}</strong></div><div><span className="text-slate-400 block text-[10px]">TIMING</span><strong className="font-mono">{selected.timing}</strong></div><div><span className="text-slate-400 block text-[10px]">CAPACITY</span><strong className="font-mono">{selected.enrolled} / {selected.capacity}</strong></div><div><span className="text-slate-400 block text-[10px]">FEE</span><strong>{selected.feeStructure}</strong></div></div><p className="text-xs text-slate-600 mt-3 italic">"{selected.remarks}"</p><div className="mt-4 flex gap-2"><button onClick={()=>window.print()} className="flex-1 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1"><Printer className="w-4 h-4" />Print Batch Roster</button><button onClick={()=>setSelected(null)} className="px-5 py-2 bg-zinc-100 rounded-xl text-xs font-bold">Close</button></div></div></div>
      )}
    </div>
  );
}
