import React, { useState } from 'react';
import { GraduationCap, Plus, Printer, Search, Mail, Phone, Layers, Trash2, X } from 'lucide-react';

type Teacher = {
  id: string; name: string; email: string; phone: string;
  qualification: string; specialization: string; department: string;
  assignedBatches: string[]; status: string; photoUrl: string;
};

const INITIAL_TEACHERS: Teacher[] = [
  { id:'TCH-01', name:'Sir Sajjad Ahmed', email:'sajjad.ahmed@taleemacademy.edu.pk', phone:'+92 300 1111111', qualification:'M.Sc Mathematics', specialization:'Mathematics', department:'Faculty of Science', assignedBatches:['Batch 2026-A (Morning)'], status:'Active', photoUrl:'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80' },
  { id:'TCH-02', name:'Miss Ayesha Khan', email:'ayesha.khan@taleemacademy.edu.pk', phone:'+92 301 2222222', qualification:'M.Sc Physics', specialization:'Physics', department:'Faculty of Science', assignedBatches:['Batch 2026-B (Evening)'], status:'Active', photoUrl:'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80' },
  { id:'TCH-03', name:'Sir Bilal Raza', email:'bilal.raza@taleemacademy.edu.pk', phone:'+92 302 3333333', qualification:'MA English', specialization:'English', department:'Faculty of Arts', assignedBatches:['Batch 2026-A (Morning)'], status:'Active', photoUrl:'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80' },
  { id:'TCH-04', name:'Dr. Usman Ali', email:'usman.ali@taleemacademy.edu.pk', phone:'+92 303 4444444', qualification:'Ph.D Computer Science', specialization:'Computer', department:'Faculty of IT', assignedBatches:['Batch 2026-C'], status:'Active', photoUrl:'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80' },
];

export default function TeachersModule() {
  const [teachers, setTeachers] = useState<Teacher[]>(INITIAL_TEACHERS);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Teacher | null>(null);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [form, setForm] = useState({ name:'', email:'', phone:'', qualification:'M.Sc Physics', specialization:'Physics', department:'Faculty of Science', batch:'Batch 2026-A (Morning)' });

  const filtered = teachers.filter(t => 
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.department.toLowerCase().includes(search.toLowerCase()) ||
    t.specialization.toLowerCase().includes(search.toLowerCase())
  );

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if(!form.name.trim()) return;
    const nt: Teacher = {
      id:`TCH-0${teachers.length+1}`, name:form.name, email:form.email || `${form.name.toLowerCase().replace(/\s+/g,'.')}`+'@taleemacademy.edu.pk',
      phone:form.phone || '+92 300 0000000', qualification:form.qualification, specialization:form.specialization,
      department:form.department, assignedBatches:[form.batch], status:'Active',
      photoUrl:'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80'
    };
    setTeachers([...teachers, nt]); setIsAddOpen(false); setForm({ name:'', email:'', phone:'', qualification:'M.Sc Physics', specialization:'Physics', department:'Faculty of Science', batch:'Batch 2026-A (Morning)' });
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl"><GraduationCap className="w-5 h-5" /></span>
            <h1 className="text-xl font-black">Faculty & Teacher Zone PRO</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">FACULTY DOSSIER • ORIGINAL</span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip data • Instructor credentials, subject specializations, timetable grids</p>
        </div>
        <div className="flex gap-2">
          <button onClick={()=>window.print()} className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl border border-white/20"><Printer className="w-4 h-4" />Print Roster</button>
          <button onClick={()=>setIsAddOpen(true)} className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl shadow-lg"><Plus className="w-4 h-4" />Add Faculty</button>
        </div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm">
        <div className="relative"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" /><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search faculty by name, department, or qualification..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none" /></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item=>(
          <div key={item.id} onClick={()=>setSelected(item)} className="p-5 bg-white rounded-[22px] border shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between"><span className="px-2.5 py-0.5 text-xs font-bold bg-indigo-50 text-indigo-700 rounded-lg">{item.department}</span><span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800">{item.status}</span></div>
              <div className="mt-3 flex items-start gap-3"><img src={item.photoUrl} alt={item.name} className="w-14 h-14 rounded-2xl object-cover border-2 border-indigo-200" /><div><h3 className="text-base font-extrabold">{item.name}</h3><p className="text-xs text-slate-500 font-semibold">{item.qualification}</p><p className="text-[11px] text-indigo-700 font-mono">{item.specialization}</p></div></div>
              <div className="mt-4 pt-3 border-t space-y-1.5 text-xs text-slate-600"><div className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5 text-slate-400" /><span className="truncate">{item.email}</span></div><div className="flex items-center gap-1.5 font-mono"><Phone className="w-3.5 h-3.5 text-slate-400" /><span>{item.phone}</span></div><div className="flex items-center gap-1.5"><Layers className="w-3.5 h-3.5 text-indigo-500" /><span className="font-semibold">Batches: {item.assignedBatches.join(', ')}</span></div></div>
            </div>
            <div className="mt-4 pt-3 border-t flex items-center justify-between text-xs text-slate-400"><span className="text-[10px] text-indigo-600 font-bold">Tap to view Timetable →</span><button onClick={(e)=>{e.stopPropagation(); setTeachers(teachers.filter(t=>t.id!==item.id));}} className="p-1 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button></div>
          </div>
        ))}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[560px] p-6 shadow-2xl"><div className="flex justify-between items-center mb-4"><h3 className="font-black text-lg">Register Faculty Member</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><form onSubmit={handleAdd} className="space-y-4"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Full Name *</label><input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} placeholder="Prof. / Dr. Full Name" className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none focus:border-indigo-600" /></div><div><label className="block text-xs font-bold uppercase mb-1">Email</label><input value={form.email} onChange={e=>setForm({...form, email:e.target.value})} placeholder="faculty@taleemacademy.edu.pk" className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none" /></div><div><label className="block text-xs font-bold uppercase mb-1">Phone</label><input value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} placeholder="+92 300..." className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none" /></div><div><label className="block text-xs font-bold uppercase mb-1">Specialization</label><input value={form.specialization} onChange={e=>setForm({...form, specialization:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none" /></div></div><div className="flex gap-2 justify-end"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-5 py-2 bg-zinc-100 rounded-xl text-xs font-bold">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-black">Add Faculty Profile</button></div></form></div></div>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setSelected(null)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[720px] p-6 max-h-[90vh] overflow-y-auto"><div className="flex justify-between"><h3 className="font-black">Faculty Dossier: {selected.name}</h3><button onClick={()=>setSelected(null)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><div className="mt-4 p-4 bg-slate-50 rounded-2xl border flex gap-4"><img src={selected.photoUrl} className="w-20 h-20 rounded-2xl object-cover" /><div><p className="font-bold">{selected.name}</p><p className="text-xs text-slate-600">{selected.qualification} • {selected.department}</p><p className="text-xs font-mono text-indigo-700 mt-1">{selected.specialization} • {selected.email}</p><p className="text-xs mt-1">Batches: {selected.assignedBatches.join(', ')}</p></div></div><div className="mt-4 border rounded-xl overflow-hidden"><table className="w-full text-xs"><thead className="bg-slate-100"><tr><th className="p-2.5 text-left">Batch</th><th className="p-2.5 text-left">Day</th><th className="p-2.5 text-left">Period & Timing</th><th className="p-2.5 text-left">Subject</th></tr></thead><tbody><tr><td className="p-2.5" colSpan={4}>No timetable slots assigned yet. Use Timetable GRID module to allocate periods.</td></tr></tbody></table></div></div></div>
      )}
    </div>
  );
}
