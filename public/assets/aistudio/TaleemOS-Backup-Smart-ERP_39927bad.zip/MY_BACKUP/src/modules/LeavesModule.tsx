import React, { useState } from 'react';
import { FileText, Plus, Printer, Clock, X } from 'lucide-react';

type LeaveRequest = {
  id: string; applicantType: 'Staff'|'Student'; applicantName: string; applicantId: string;
  leaveType: string; startDate: string; endDate: string; totalDays: number;
  reason: string; status: 'Pending'|'Approved'|'Rejected'; appliedDate: string; approvedBy?: string;
};

const INITIAL: LeaveRequest[] = [
  { id:'LEV-0001', applicantType:'Staff', applicantName:'Sir Sajjad Ahmed', applicantId:'STF-03', leaveType:'Casual', startDate:'2026-10-20', endDate:'2026-10-21', totalDays:2, reason:'Family function at Sukkur, need 2 days leave', status:'Pending', appliedDate:'2026-10-19' },
  { id:'LEV-0002', applicantType:'Staff', applicantName:'Miss Ayesha Khan', applicantId:'STF-02', leaveType:'Sick', startDate:'2026-10-18', endDate:'2026-10-18', totalDays:1, reason:'Fever and cold, medical certificate attached', status:'Approved', appliedDate:'2026-10-18', approvedBy:'Principal Ahmed' },
  { id:'LEV-0003', applicantType:'Student', applicantName:'Ahmed Ali Qasmi', applicantId:'TAK-26-001', leaveType:'Emergency', startDate:'2026-10-22', endDate:'2026-10-24', totalDays:3, reason:'Urgent travel to Karachi', status:'Pending', appliedDate:'2026-10-21' },
  { id:'LEV-0004', applicantType:'Staff', applicantName:'Sir Bilal Raza', applicantId:'STF-01', leaveType:'Casual', startDate:'2026-10-25', endDate:'2026-10-25', totalDays:1, reason:'Personal work', status:'Approved', appliedDate:'2026-10-24', approvedBy:'Principal' },
];

export default function LeavesModule() {
  const [leaves, setLeaves] = useState<LeaveRequest[]>(INITIAL);
  const [isApplyOpen, setIsApplyOpen] = useState(false);
  const [form, setForm] = useState({ type:'Staff' as any, name:'Developer', leaveType:'Casual', start:new Date().toISOString().split('T')[0], end:new Date().toISOString().split('T')[0], days:1, reason:'' });

  const handleApply = (e: React.FormEvent)=>{
    e.preventDefault();
    if(!form.reason.trim()) return;
    const nl: LeaveRequest = { id:`LEV-${Date.now().toString().slice(-4)}`, applicantType:form.type, applicantName:form.name, applicantId:'STF-03', leaveType:form.leaveType, startDate:form.start, endDate:form.end, totalDays:Number(form.days), reason:form.reason, status:'Pending', appliedDate:new Date().toISOString().split('T')[0] };
    setLeaves([nl, ...leaves]); setIsApplyOpen(false); setForm({ type:'Staff', name:'Developer', leaveType:'Casual', start:new Date().toISOString().split('T')[0], end:new Date().toISOString().split('T')[0], days:1, reason:'' });
  };
  const approve = (id:string)=> setLeaves(leaves.map(l=> l.id===id ? { ...l, status:'Approved', approvedBy:'Principal (Auto)' } : l));
  const reject = (id:string)=> setLeaves(leaves.map(l=> l.id===id ? { ...l, status:'Rejected', approvedBy:'Principal' } : l));

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><FileText className="w-5 h-5" /></span><h1 className="text-xl font-black">Leave Management ERP</h1><span className="px-2 py-0.5 bg-indigo-500 text-[10px] font-black rounded uppercase">APPROVAL CHAIN • ORIGINAL</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Faculty & student leave applications, quota tracking, medical documents, Principal authorization</p></div>
        <div className="flex gap-2"><button onClick={()=>window.print()} className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-xl border border-white/20 flex items-center gap-1.5"><Printer className="w-4 h-4" />Print Leave Ledger</button><button onClick={()=>setIsApplyOpen(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4" />Apply For Leave</button></div>
      </div>

      <div className="p-6 bg-white rounded-[24px] border shadow-sm space-y-4">
        <h3 className="font-extrabold text-base flex items-center gap-2"><Clock className="w-4 h-4 text-amber-500" />Leave Applications & Institutional Sanctions</h3>
        <div className="space-y-3">
          {leaves.map(l=>(
            <div key={l.id} className="p-4 bg-slate-50 hover:bg-white rounded-2xl border transition-all flex flex-col md:flex-row justify-between gap-4">
              <div className="flex-1"><div className="flex items-center gap-2 flex-wrap"><span className="font-mono text-xs font-black text-indigo-700">{l.id}</span><h4 className="font-bold text-sm">{l.applicantName}</h4><span className="px-2 py-0.5 bg-slate-200 text-slate-700 text-[10px] font-bold rounded">{l.applicantType}</span><span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${l.status==='Approved'?'bg-emerald-100 text-emerald-800':l.status==='Pending'?'bg-amber-100 text-amber-800':'bg-rose-100 text-rose-800'}`}>{l.status}</span></div><div className="mt-1 text-xs text-slate-600 flex items-center gap-3"><span>Type: <strong>{l.leaveType}</strong></span><span>•</span><span className="font-mono">{l.startDate} to {l.endDate} ({l.totalDays} days)</span></div><p className="mt-1 text-xs text-slate-700 italic bg-white p-2.5 rounded-xl border">"{l.reason}"</p></div>
              <div className="text-right text-xs shrink-0 space-y-1"><span className="text-slate-400 block font-semibold text-[10px]">SANCTION STATUS</span><span className="font-bold text-slate-800">{l.approvedBy ? l.approvedBy : 'Awaiting Principal Approval'}</span><span className="text-[10px] text-slate-400 block font-mono">Applied: {l.appliedDate}</span>{l.status==='Pending' && <div className="flex gap-1 justify-end mt-2"><button onClick={()=>approve(l.id)} className="px-2 py-1 bg-emerald-600 text-white rounded-full text-[10px] font-bold">Approve</button><button onClick={()=>reject(l.id)} className="px-2 py-1 bg-rose-600 text-white rounded-full text-[10px] font-bold">Reject</button></div>}</div>
            </div>
          ))}
        </div>
      </div>

      {isApplyOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsApplyOpen(false)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[640px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">Submit Institutional Leave Application</h3><button onClick={()=>setIsApplyOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><p className="text-xs text-slate-500 mb-4">Automatic escalation to Principal office for sanctioning</p><form onSubmit={handleApply} className="space-y-4"><div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Applicant Type</label><select value={form.type} onChange={e=>setForm({...form, type:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white"><option>Staff</option><option>Student</option></select></div><div><label className="block text-xs font-bold uppercase mb-1">Applicant Name</label><input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div><div><label className="block text-xs font-bold uppercase mb-1">Leave Type</label><select value={form.leaveType} onChange={e=>setForm({...form, leaveType:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white"><option>Casual</option><option>Sick</option><option>Emergency</option><option>Maternity / Paternity</option></select></div></div><div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">From Date</label><input type="date" required value={form.start} onChange={e=>setForm({...form, start:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white" /></div><div><label className="block text-xs font-bold uppercase mb-1">To Date</label><input type="date" required value={form.end} onChange={e=>setForm({...form, end:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white" /></div><div><label className="block text-xs font-bold uppercase mb-1">Total Days</label><input type="number" min={1} value={form.days} onChange={e=>setForm({...form, days:Number(e.target.value)})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono font-bold" /></div></div><div><label className="block text-xs font-bold uppercase mb-1">Reason / Medical Certificate Reference *</label><textarea required rows={3} value={form.reason} onChange={e=>setForm({...form, reason:e.target.value})} placeholder="State reason clearly..." className="w-full px-3.5 py-2 border rounded-xl text-xs focus:border-indigo-600 outline-none" /></div><div className="pt-3 flex justify-end gap-2 border-t"><button type="button" onClick={()=>setIsApplyOpen(false)} className="px-4 py-2 border text-xs font-bold rounded-xl">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 text-white text-xs font-black rounded-xl">Submit Application</button></div></form></div></div>
      )}
    </div>
  );
}
