import React, { useState } from 'react';
import { MessageSquare, Plus, Printer, Search, Trash2, X, Edit2, Filter, Download } from 'lucide-react';

type Enquiry = {
  id: string; studentName: string; fatherName: string; phone: string;
  course: string; source: string; status: 'New'|'Contacted'|'Follow-up'|'Admitted'|'Lost';
  enquiryDate: string; followUpDate: string; assignedTo: string; actionTaken: string; remarks: string;
};

const INITIAL: Enquiry[] = [
  { id:'ENQ-0001', studentName:'Ahmed Ali Qasmi', fatherName:'Muhammad Qasim', phone:'0300-1234567', course:'F.Sc Pre-Engineering', source:'Walk-in', status:'New', enquiryDate:'2026-10-20', followUpDate:'2026-10-22', assignedTo:'Sir Sajjad', actionTaken:'Prospectus issued', remarks:'Interested in board prep batch' },
  { id:'ENQ-0002', studentName:'Fatima Noor', fatherName:'Noor Ahmed', phone:'0301-2345678', course:'F.Sc Pre-Medical', source:'Facebook', status:'Contacted', enquiryDate:'2026-10-19', followUpDate:'2026-10-21', assignedTo:'Miss Ayesha', actionTaken:'Call done', remarks:'Medical entry test query' },
  { id:'ENQ-0003', studentName:'Muhammad Hadi', fatherName:'Meer Hadi', phone:'0302-3456789', course:'ICS', source:'Referral', status:'Follow-up', enquiryDate:'2026-10-18', followUpDate:'2026-10-20', assignedTo:'Dr. Usman', actionTaken:'Campus visit scheduled', remarks:'Lab facilities inquiry' },
  { id:'ENQ-0004', studentName:'Ayesha Siddiqui', fatherName:'Siddiq', phone:'0303-4567890', course:'Commerce', source:'Walk-in', status:'Admitted', enquiryDate:'2026-10-15', followUpDate:'2026-10-16', assignedTo:'Sir Bilal', actionTaken:'Admission confirmed', remarks:'Fee voucher issued VCH-26-801' },
  { id:'ENQ-0005', studentName:'Zainab Khan', fatherName:'Khan', phone:'0304-5678901', course:'F.Sc General Science', source:'Banner', status:'New', enquiryDate:'2026-10-21', followUpDate:'2026-10-23', assignedTo:'Prof. Ghulam Rasool', actionTaken:'Prospectus issued', remarks:'New admission open inquiry' },
];

export default function EnquiriesModule() {
  const [enquiries, setEnquiries] = useState<Enquiry[]>(INITIAL);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [sourceFilter, setSourceFilter] = useState('All');
  const [courseFilter, setCourseFilter] = useState('All');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [selected, setSelected] = useState<Enquiry | null>(null);
  const [form, setForm] = useState({ studentName:'', fatherName:'', phone:'', course:'F.Sc Pre-Engineering', source:'Walk-in', status:'New' as Enquiry['status'], enquiryDate:new Date().toISOString().split('T')[0], followUpDate:new Date().toISOString().split('T')[0], assignedTo:'Sir Sajjad', actionTaken:'Prospectus issued', remarks:'' });

  const filtered = enquiries.filter(e=>{
    const ms = e.studentName.toLowerCase().includes(search.toLowerCase()) || e.phone.includes(search) || e.fatherName.toLowerCase().includes(search.toLowerCase());
    const mst = statusFilter==='All' || e.status===statusFilter;
    const mso = sourceFilter==='All' || e.source===sourceFilter;
    const mc = courseFilter==='All' || e.course===courseFilter;
    return ms && mst && mso && mc;
  });

  const totalEnquiries = enquiries.length;
  const newCount = enquiries.filter(e=>e.status==='New').length;
  const admittedCount = enquiries.filter(e=>e.status==='Admitted').length;

  const handleSave = (e: React.FormEvent)=>{
    e.preventDefault();
    if(!form.studentName.trim() || !form.phone.trim()) return;
    if(isEditMode && selected){
      setEnquiries(enquiries.map(x=> x.id===selected.id ? { ...x, ...form } : x));
    } else {
      const ne: Enquiry = { id:`ENQ-${Date.now().toString().slice(-4)}`, ...form };
      setEnquiries([ne, ...enquiries]);
    }
    setIsAddOpen(false); setIsEditMode(false); setSelected(null);
    setForm({ studentName:'', fatherName:'', phone:'', course:'F.Sc Pre-Engineering', source:'Walk-in', status:'New', enquiryDate:new Date().toISOString().split('T')[0], followUpDate:new Date().toISOString().split('T')[0], assignedTo:'Sir Sajjad', actionTaken:'Prospectus issued', remarks:'' });
  };

  const handleNextStatus = (enq: Enquiry, ev: React.MouseEvent)=>{
    ev.stopPropagation();
    const transitions: Record<Enquiry['status'], Enquiry['status']> = { New:'Contacted', Contacted:'Follow-up', 'Follow-up':'Admitted', Admitted:'Admitted', Lost:'New' };
    const next = transitions[enq.status];
    setEnquiries(enquiries.map(x=> x.id===enq.id ? { ...x, status:next } : x));
  };

  const handleOpenEdit = (enq: Enquiry, ev: React.MouseEvent)=>{
    ev.stopPropagation();
    setSelected(enq); setIsEditMode(true);
    setForm({ studentName:enq.studentName, fatherName:enq.fatherName, phone:enq.phone, course:enq.course, source:enq.source, status:enq.status, enquiryDate:enq.enquiryDate, followUpDate:enq.followUpDate, assignedTo:enq.assignedTo, actionTaken:enq.actionTaken, remarks:enq.remarks });
    setIsAddOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><MessageSquare className="w-5 h-5" /></span><h1 className="text-xl md:text-2xl font-black">Enquiries & Leads Pipeline PRO</h1><span className="px-2 py-0.5 bg-amber-400 text-slate-950 font-black text-[10px] rounded uppercase">ENQ-LEDGER-2026</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Prospective Admission Enquiries & Lead Pipeline • 11 Fields • Status: New→Contacted→Follow-up→Admitted</p></div>
        <div className="flex flex-wrap items-center gap-2"><button onClick={()=>window.print()} className="px-4 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold rounded-xl flex items-center gap-1.5"><Printer className="w-4 h-4"/>Print A4 Lead Registry</button><button onClick={()=>{ setIsEditMode(false); setForm({ studentName:'', fatherName:'', phone:'', course:'F.Sc Pre-Engineering', source:'Walk-in', status:'New', enquiryDate:new Date().toISOString().split('T')[0], followUpDate:new Date().toISOString().split('T')[0], assignedTo:'Sir Sajjad', actionTaken:'Prospectus issued', remarks:'' }); setIsAddOpen(true); }} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4"/>Add New Enquiry</button></div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="p-4 bg-white rounded-[20px] border"><div className="text-[10px] font-black text-slate-400 uppercase">Total Leads</div><div className="text-2xl font-black font-mono">{totalEnquiries}</div><div className="text-[10px] text-slate-500">Prospective Admission Enquiries</div></div>
        <div className="p-4 bg-white rounded-[20px] border"><div className="text-[10px] font-black text-amber-600 uppercase">New Inquiries</div><div className="text-2xl font-black text-amber-600 font-mono">{newCount}</div><div className="text-[10px] text-slate-500">Awaiting contact</div></div>
        <div className="p-4 bg-white rounded-[20px] border"><div className="text-[10px] font-black text-emerald-600 uppercase">Admitted</div><div className="text-2xl font-black text-emerald-600 font-mono">{admittedCount}</div><div className="text-[10px] text-slate-500">Converted to admission</div></div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm space-y-3">
        <div className="relative"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by student name, phone, father..." className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500"/></div>
        <div className="flex flex-wrap gap-3 text-xs items-center"><span className="flex items-center gap-1"><Filter className="w-3 h-3"/>Status:</span>{['All','New','Contacted','Follow-up','Admitted','Lost'].map(s=><button key={s} onClick={()=>setStatusFilter(s)} className={`px-3 py-1 rounded-full text-[11px] font-bold ${statusFilter===s?'bg-indigo-600 text-white':'bg-slate-100 text-slate-600'}`}>{s}</button>)}<span className="w-px h-4 bg-slate-200"/><span>Source:</span>{['All','Walk-in','Facebook','Referral','Banner'].map(s=><button key={s} onClick={()=>setSourceFilter(s)} className={`px-3 py-1 rounded-full text-[11px] font-bold ${sourceFilter===s?'bg-slate-800 text-white':'bg-slate-100 text-slate-600'}`}>{s}</button>)}</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item=>(
          <div key={item.id} onClick={()=>setSelected(item)} className="p-5 bg-white rounded-[22px] border shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between">
            <div><div className="flex justify-between items-start gap-2"><span className="px-2.5 py-0.5 font-mono text-xs font-black bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200">{item.id}</span><span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${item.status==='New'?'bg-amber-100 text-amber-800':item.status==='Contacted'?'bg-blue-100 text-blue-800':item.status==='Follow-up'?'bg-violet-100 text-violet-800':item.status==='Admitted'?'bg-emerald-100 text-emerald-800':'bg-slate-100 text-slate-600'}`}>{item.status}</span></div>
              <h3 className="mt-3 text-base font-extrabold leading-snug">{item.studentName}</h3><p className="text-xs text-slate-500">S/O {item.fatherName} • {item.phone}</p>
              <div className="mt-3 p-3 bg-slate-50 rounded-xl border space-y-1.5 text-xs"><div className="flex justify-between"><span className="text-slate-400">Course:</span><strong>{item.course}</strong></div><div className="flex justify-between"><span className="text-slate-400">Source:</span><span className="font-bold">{item.source}</span></div><div className="flex justify-between"><span className="text-slate-400">Enquiry Date:</span><span className="font-mono">{item.enquiryDate}</span></div><div className="flex justify-between"><span className="text-slate-400">Follow-up:</span><span className="font-mono font-bold text-amber-700">{item.followUpDate}</span></div><div className="flex justify-between"><span className="text-slate-400">Assigned To:</span><span className="font-bold">{item.assignedTo}</span></div></div>
              <p className="mt-2 text-[11px] text-slate-600 italic">"{item.remarks}"</p>
            </div>
            <div className="mt-4 pt-3 border-t flex justify-between items-center"><button onClick={(e)=>handleNextStatus(item,e)} className="px-3 py-1 bg-black text-white rounded-full text-[10px] font-bold hover:bg-zinc-800">Next Status → {item.status==='New'?'Contacted':item.status==='Contacted'?'Follow-up':item.status==='Follow-up'?'Admitted':'Admitted'}</button><div className="flex gap-1"><button onClick={(e)=>handleOpenEdit(item,e)} className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded"><Edit2 className="w-3.5 h-3.5"/></button><button onClick={(e)=>{e.stopPropagation(); setEnquiries(enquiries.filter(x=>x.id!==item.id));}} className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"><Trash2 className="w-3.5 h-3.5"/></button></div></div>
          </div>
        ))}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60"/><div className="relative bg-white rounded-[24px] w-full max-w-[720px] p-6 max-h-[90vh] overflow-y-auto"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">{isEditMode?'Edit Enquiry Lead':'Add New Enquiry'}</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4"/></button></div><p className="text-xs text-slate-500 mb-4">11 Fields Original — Define lead source, course interest, follow-up schedule, and action taken</p><form onSubmit={handleSave} className="space-y-4"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Student Name *</label><input required value={form.studentName} onChange={e=>setForm({...form, studentName:e.target.value})} placeholder="Student full name" className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none focus:border-indigo-600"/></div><div><label className="block text-xs font-bold uppercase mb-1">Father Name</label><input value={form.fatherName} onChange={e=>setForm({...form, fatherName:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div></div><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Phone *</label><input required value={form.phone} onChange={e=>setForm({...form, phone:e.target.value})} placeholder="0300-1234567" className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono"/></div><div><label className="block text-xs font-bold uppercase mb-1">Course Interest</label><select value={form.course} onChange={e=>setForm({...form, course:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white"><option>F.Sc Pre-Engineering</option><option>F.Sc Pre-Medical</option><option>F.Sc General Science</option><option>ICS</option><option>Commerce</option><option>9th Standard</option></select></div></div><div className="grid grid-cols-3 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Source</label><select value={form.source} onChange={e=>setForm({...form, source:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white"><option>Walk-in</option><option>Facebook</option><option>Referral</option><option>Banner</option><option>WhatsApp</option></select></div><div><label className="block text-xs font-bold uppercase mb-1">Status</label><select value={form.status} onChange={e=>setForm({...form, status:e.target.value as any})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white"><option>New</option><option>Contacted</option><option>Follow-up</option><option>Admitted</option><option>Lost</option></select></div><div><label className="block text-xs font-bold uppercase mb-1">Assigned To</label><input value={form.assignedTo} onChange={e=>setForm({...form, assignedTo:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div></div><div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Enquiry Date</label><input type="date" value={form.enquiryDate} onChange={e=>setForm({...form, enquiryDate:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div><div><label className="block text-xs font-bold uppercase mb-1">Follow-up Date</label><input type="date" value={form.followUpDate} onChange={e=>setForm({...form, followUpDate:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div></div><div><label className="block text-xs font-bold uppercase mb-1">Action Taken</label><input value={form.actionTaken} onChange={e=>setForm({...form, actionTaken:e.target.value})} placeholder="Prospectus issued, Call done, Campus visit" className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div><div><label className="block text-xs font-bold uppercase mb-1">Remarks</label><textarea value={form.remarks} onChange={e=>setForm({...form, remarks:e.target.value})} rows={2} placeholder="Additional notes..." className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div><div className="pt-3 flex justify-end gap-2 border-t"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-4 py-2 border rounded-xl text-xs font-bold">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-black">{isEditMode?'Update Enquiry':'Save Enquiry'}</button></div></form></div></div>
      )}

      {selected && !isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setSelected(null)} className="absolute inset-0 bg-black/60"/><div className="relative bg-white rounded-[24px] w-full max-w-[560px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">Enquiry: {selected.studentName}</h3><button onClick={()=>setSelected(null)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4"/></button></div><div className="p-4 bg-slate-50 rounded-xl border grid grid-cols-2 gap-3 text-xs"><div><span className="text-slate-400 block text-[10px]">LEAD REF</span><strong className="font-mono">{selected.id}</strong></div><div><span className="text-slate-400 block text-[10px]">STATUS</span><strong>{selected.status}</strong></div><div><span className="text-slate-400 block text-[10px]">PHONE</span><strong className="font-mono">{selected.phone}</strong></div><div><span className="text-slate-400 block text-[10px]">COURSE</span><strong>{selected.course}</strong></div><div className="col-span-2"><span className="text-slate-400 block text-[10px]">ACTION TAKEN</span><strong>{selected.actionTaken}</strong></div></div><p className="mt-3 text-xs italic">"{selected.remarks}"</p><div className="mt-4 flex gap-2"><button onClick={()=>window.print()} className="flex-1 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1"><Printer className="w-4 h-4"/>Print Enquiry Slip</button><button onClick={()=>setSelected(null)} className="px-5 py-2 bg-zinc-100 rounded-xl text-xs font-bold">Close</button></div></div></div>
      )}
    </div>
  );
}
