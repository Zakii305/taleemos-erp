import React, { useState } from 'react';
import { Award, Plus, Printer, Search, Trash2, X, Calendar } from 'lucide-react';

type Exam = {
  id: string; examType: 'Monthly'|'Term'|'Final'|'Surprise Test';
  classBatch: string; subject: string; date: string; room: string; supervisor: string;
  status: 'Scheduled'|'Completed'|'Cancelled';
};

const INITIAL: Exam[] = [
  { id:'EXM-001', examType:'Monthly', classBatch:'Batch 2026-A (Morning)', subject:'Physics', date:'2026-11-05', room:'Room 101', supervisor:'Sir Sajjad Ahmed', status:'Scheduled' },
  { id:'EXM-002', examType:'Term', classBatch:'Batch 2026-A (Morning)', subject:'Mathematics', date:'2026-11-08', room:'Room 101', supervisor:'Sir Sajjad Ahmed', status:'Scheduled' },
  { id:'EXM-003', examType:'Monthly', classBatch:'Batch 2026-B (Morning)', subject:'Chemistry', date:'2026-11-10', room:'Room 102', supervisor:'Miss Ayesha Khan', status:'Scheduled' },
  { id:'EXM-004', examType:'Final', classBatch:'Batch 2026-A (Morning)', subject:'English', date:'2026-12-01', room:'Hall A', supervisor:'Sir Bilal Raza', status:'Scheduled' },
  { id:'EXM-005', examType:'Term', classBatch:'Batch 2026-C (Afternoon)', subject:'Computer Science', date:'2026-11-12', room:'Lab 12', supervisor:'Dr. Usman Ali', status:'Completed' },
];

export default function ExamsModule() {
  const [exams, setExams] = useState<Exam[]>(INITIAL);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('All');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selected, setSelected] = useState<Exam | null>(null);
  const [form, setForm] = useState({ examType:'Monthly' as Exam['examType'], classBatch:'Batch 2026-A (Morning)', subject:'Physics', date:'2026-11-15', room:'Room 101', supervisor:'Sir Sajjad Ahmed' });

  const filtered = exams.filter(e=>{
    const ms = e.subject.toLowerCase().includes(search.toLowerCase()) || e.classBatch.toLowerCase().includes(search.toLowerCase()) || e.supervisor.toLowerCase().includes(search.toLowerCase());
    const mt = typeFilter==='All' || e.examType===typeFilter;
    return ms && mt;
  });

  const handleCreate = (e: React.FormEvent)=>{
    e.preventDefault();
    const newEx: Exam = { id:`EXM-00${exams.length+1}`, examType:form.examType, classBatch:form.classBatch, subject:form.subject, date:form.date, room:form.room, supervisor:form.supervisor, status:'Scheduled' };
    setExams([newEx, ...exams]); setIsAddOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><Award className="w-5 h-5" /></span><h1 className="text-xl font-black">Examinations & Date Sheet PRO</h1><span className="px-2 py-0.5 bg-indigo-500 text-[10px] font-black rounded uppercase">EXM-XXXX • ORIGINAL SAFE</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Evaluation dates, invigilator assignment, hall/room allocation</p></div>
        <div className="flex gap-2"><button onClick={()=>window.print()} className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-xl border border-white/20 flex items-center gap-1.5"><Printer className="w-4 h-4"/>Print Schedule</button><button onClick={()=>setIsAddOpen(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4"/>Schedule Exam</button></div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm space-y-3">
        <div className="relative"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by subject, batch, invigilator..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500"/></div>
        <div className="flex flex-wrap gap-2 text-xs"><span className="text-[10px] font-bold text-slate-400 uppercase">Type:</span>{['All','Monthly','Term','Final','Surprise Test'].map(t=><button key={t} onClick={()=>setTypeFilter(t)} className={`px-3 py-1 rounded-full text-[11px] font-bold ${typeFilter===t?'bg-indigo-600 text-white':'bg-slate-100 text-slate-600'}`}>{t}</button>)}</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item=>(
          <div key={item.id} onClick={()=>setSelected(item)} className="p-5 bg-white rounded-[22px] border shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between">
            <div><div className="flex justify-between items-start"><span className="px-2.5 py-0.5 font-mono text-xs font-black bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200">{item.id}</span><span className={`px-2 py-0.2 rounded-full text-[10px] font-black uppercase ${item.status==='Scheduled'?'bg-amber-100 text-amber-800':item.status==='Completed'?'bg-emerald-100 text-emerald-800':'bg-slate-100 text-slate-600'}`}>{item.examType}</span></div>
              <h3 className="mt-3 text-base font-extrabold">{item.subject}</h3><p className="text-xs text-slate-500">{item.classBatch}</p>
              <div className="mt-3 p-3 bg-slate-50 rounded-xl border space-y-1.5 text-xs"><div className="flex justify-between"><span className="text-slate-400">Date:</span><strong className="font-mono flex items-center gap-1"><Calendar className="w-3 h-3"/>{item.date}</strong></div><div className="flex justify-between"><span className="text-slate-400">Hall/Room:</span><span className="font-bold">{item.room}</span></div><div className="flex justify-between"><span className="text-slate-400">Invigilator:</span><span className="font-bold">{item.supervisor}</span></div></div>
            </div>
            <div className="mt-4 pt-3 border-t flex justify-between text-xs"><span className="text-[10px] font-mono text-slate-400">ID: {item.id}</span><button onClick={(e)=>{e.stopPropagation(); setExams(exams.filter(x=>x.id!==item.id));}} className="p-1 text-slate-400 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5"/></button></div>
          </div>
        ))}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60"/><div className="relative bg-white rounded-[24px] w-full max-w-[560px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">Schedule New Examination</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4"/></button></div><p className="text-xs text-slate-500 mb-4">Establish evaluation date and invigilator assignment — EXAM SETUP ORIGINAL</p><form onSubmit={handleCreate} className="space-y-4"><div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Exam Type</label><select value={form.examType} onChange={e=>setForm({...form, examType:e.target.value as any})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white"><option>Monthly</option><option>Term</option><option>Final</option><option>Surprise Test</option></select></div><div><label className="block text-xs font-bold uppercase mb-1">Subject</label><input required value={form.subject} onChange={e=>setForm({...form, subject:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div></div><div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Class Batch</label><input value={form.classBatch} onChange={e=>setForm({...form, classBatch:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div><div><label className="block text-xs font-bold uppercase mb-1">Date</label><input type="date" value={form.date} onChange={e=>setForm({...form, date:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div></div><div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Hall / Room</label><input value={form.room} onChange={e=>setForm({...form, room:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono"/></div><div><label className="block text-xs font-bold uppercase mb-1">Invigilator</label><input value={form.supervisor} onChange={e=>setForm({...form, supervisor:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div></div><div className="pt-3 flex justify-end gap-2 border-t"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-4 py-2 border rounded-xl text-xs font-bold">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-black">Schedule Exam</button></div></form></div></div>
      )}

      {selected && !isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setSelected(null)} className="absolute inset-0 bg-black/60"/><div className="relative bg-white rounded-[24px] w-full max-w-[520px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">{selected.subject} — {selected.examType}</h3><button onClick={()=>setSelected(null)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4"/></button></div><div className="p-4 bg-slate-50 rounded-xl border grid grid-cols-2 gap-3 text-xs"><div><span className="text-slate-400 block text-[10px]">BATCH</span><strong>{selected.classBatch}</strong></div><div><span className="text-slate-400 block text-[10px]">DATE</span><strong className="font-mono">{selected.date}</strong></div><div><span className="text-slate-400 block text-[10px]">ROOM</span><strong>{selected.room}</strong></div><div><span className="text-slate-400 block text-[10px]">INVIGILATOR</span><strong>{selected.supervisor}</strong></div></div><div className="mt-4 flex gap-2"><button onClick={()=>window.print()} className="flex-1 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1"><Printer className="w-4 h-4"/>Print Exam Slip</button><button onClick={()=>setSelected(null)} className="px-5 py-2 bg-zinc-100 rounded-xl text-xs font-bold">Close</button></div></div></div>
      )}
    </div>
  );
}
