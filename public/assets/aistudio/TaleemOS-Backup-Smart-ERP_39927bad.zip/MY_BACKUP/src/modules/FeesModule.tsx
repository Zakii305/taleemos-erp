import React, { useState } from 'react';
import { DollarSign, Plus, Printer, Search, Trash2, X, Receipt, CheckCircle, AlertTriangle } from 'lucide-react';

type FeeVoucher = {
  id: string; voucherNo: string; studentName: string; rollNo: string;
  batch: string; month: string; feeHead: string;
  amount: number; discount: number; fine: number; netPayable: number;
  status: 'Paid' | 'Unpaid' | 'Partial'; paymentMethod: string; collectedBy: string;
};

const INITIAL_FEES: FeeVoucher[] = [
  { id:'FEE-01', voucherNo:'VCH-26-801', studentName:'Ahmed Ali Qasmi', rollNo:'TAK-26-001', batch:'10th-A Morning', month:'October 2026', feeHead:'Monthly', amount:4500, discount:0, fine:0, netPayable:4500, status:'Paid', paymentMethod:'Cash', collectedBy:'Admin' },
  { id:'FEE-02', voucherNo:'VCH-26-802', studentName:'Fatima Noor', rollNo:'TAK-26-002', batch:'9th-B Evening', month:'October 2026', feeHead:'Monthly', amount:4000, discount:500, fine:0, netPayable:3500, status:'Partial', paymentMethod:'JazzCash', collectedBy:'Admin' },
  { id:'FEE-03', voucherNo:'VCH-26-803', studentName:'Usman Tariq', rollNo:'TAK-26-003', batch:'10th-A Morning', month:'October 2026', feeHead:'Monthly', amount:4500, discount:0, fine:300, netPayable:4800, status:'Unpaid', paymentMethod:'Bank', collectedBy:'Admin' },
  { id:'FEE-04', voucherNo:'VCH-26-804', studentName:'Ayesha Siddiqua', rollNo:'TAK-26-004', batch:'8th-A', month:'September 2026', feeHead:'Admission', amount:15000, discount:2000, fine:0, netPayable:13000, status:'Paid', paymentMethod:'Cash', collectedBy:'Admin' },
  { id:'FEE-05', voucherNo:'VCH-26-805', studentName:'Bilal Raza', rollNo:'TAK-26-005', batch:'9th-A', month:'October 2026', feeHead:'Monthly', amount:4000, discount:0, fine:0, netPayable:4000, status:'Paid', paymentMethod:'Cash', collectedBy:'Admin' },
  { id:'FEE-06', voucherNo:'VCH-26-806', studentName:'Zainab Ali', rollNo:'TAK-26-006', batch:'10th-B', month:'October 2026', feeHead:'Monthly', amount:4200, discount:0, fine:0, netPayable:4200, status:'Unpaid', paymentMethod:'Bank', collectedBy:'Admin' },
];

export default function FeesModule() {
  const [fees, setFees] = useState<FeeVoucher[]>(INITIAL_FEES);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [selected, setSelected] = useState<FeeVoucher | null>(null);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [form, setForm] = useState({ roll:'TAK-26-001', name:'Ahmed Ali Qasmi', month:'October 2026', feeHead:'Monthly', amount:4500, discount:0, fine:0, status:'Paid' as any, method:'Cash' });

  const totalVouchers = fees.length;
  const totalPaid = fees.filter(f=>f.status==='Paid').reduce((s,f)=>s+f.netPayable,0);
  const totalUnpaid = fees.filter(f=>f.status!=='Paid').reduce((s,f)=>s+f.netPayable,0);
  const filtered = fees.filter(f=>{
    const matchSearch = f.studentName.toLowerCase().includes(search.toLowerCase()) || f.voucherNo.toLowerCase().includes(search.toLowerCase()) || f.rollNo.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter==='All' || f.status===statusFilter;
    return matchSearch && matchStatus;
  });

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const net = Math.max(0, Number(form.amount) - Number(form.discount) + Number(form.fine));
    const nv: FeeVoucher = {
      id:`FEE-${Date.now().toString().slice(-4)}`, voucherNo:`VCH-26-${800+fees.length+1}`,
      studentName:form.name, rollNo:form.roll, batch:'10th-A Morning', month:form.month, feeHead:form.feeHead,
      amount:Number(form.amount), discount:Number(form.discount), fine:Number(form.fine), netPayable:net,
      status:form.status, paymentMethod:form.method, collectedBy:'Admin'
    };
    setFees([...fees, nv]); setIsAddOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-emerald-600 rounded-xl"><DollarSign className="w-5 h-5" /></span><h1 className="text-xl font-black">Fee Vouchers & Collections</h1><span className="px-2 py-0.5 bg-emerald-500 text-[10px] font-black rounded uppercase">FINANCE ERP • ORIGINAL</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Student tuition invoices, bank challans, discount waivers, fines, defaulter tracking</p></div>
        <div className="flex gap-2"><button onClick={()=>window.print()} className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-xl border border-white/20 flex items-center gap-1.5"><Printer className="w-4 h-4" />Print Ledger</button><button onClick={()=>setIsAddOpen(true)} className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4" />Issue Voucher</button></div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 bg-white rounded-[20px] border shadow-sm"><div className="text-[11px] font-semibold text-slate-500 uppercase">Total Issued Vouchers</div><div className="text-2xl font-black font-mono mt-1">{totalVouchers} Invoices</div></div>
        <div className="p-4 bg-white rounded-[20px] border shadow-sm"><div className="text-[11px] font-semibold text-emerald-600 uppercase">Total Verified Revenue</div><div className="text-2xl font-black text-emerald-600 font-mono mt-1">PKR {totalPaid.toLocaleString()}</div></div>
        <div className="p-4 bg-white rounded-[20px] border shadow-sm"><div className="text-[11px] font-semibold text-rose-600 uppercase">Outstanding Defaulter Dues</div><div className="text-2xl font-black text-rose-600 font-mono mt-1">PKR {totalUnpaid.toLocaleString()}</div></div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm space-y-3">
        <div className="relative"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" /><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by Voucher No (VCH-26-801), student name, or roll no..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl text-xs outline-none" /></div>
        <div className="flex flex-wrap gap-2 text-xs"><span className="text-[11px] font-bold text-slate-400 uppercase">Status:</span>{['All','Paid','Unpaid','Partial'].map(st=><button key={st} onClick={()=>setStatusFilter(st)} className={`px-3 py-1 rounded-full text-[11px] font-bold ${statusFilter===st?'bg-emerald-600 text-white':'bg-slate-100 text-slate-600'}`}>{st}</button>)}</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item=>(
          <div key={item.id} onClick={()=>setSelected(item)} className="p-5 bg-white rounded-[22px] border shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between">
            <div>
              <div className="flex justify-between"><span className="px-2.5 py-0.5 font-mono text-xs font-black bg-indigo-50 text-indigo-700 rounded-lg">{item.voucherNo}</span><span className={`px-2.5 py-0.5 text-[10px] font-black rounded-full uppercase ${item.status==='Paid'?'bg-emerald-100 text-emerald-800':item.status==='Unpaid'?'bg-rose-100 text-rose-800':'bg-amber-100 text-amber-800'}`}>{item.status}</span></div>
              <h3 className="mt-2 text-base font-extrabold">{item.studentName}</h3><p className="text-xs text-slate-500 font-mono">Roll: {item.rollNo} • {item.batch}</p>
              <div className="mt-4 p-3 bg-slate-50 rounded-xl border space-y-1.5 text-xs"><div className="flex justify-between"><span className="text-slate-400">Fee Head / Month:</span><span className="font-bold">{item.feeHead} ({item.month})</span></div><div className="flex justify-between"><span className="text-slate-400">Payment Mode:</span><span className="font-medium">{item.paymentMethod}</span></div><div className="pt-1.5 border-t flex justify-between font-mono"><span className="font-semibold">Net Payable:</span><span className="font-black text-emerald-700 text-sm">PKR {item.netPayable.toLocaleString()}</span></div></div>
            </div>
            <div className="mt-4 pt-3 border-t flex justify-between text-xs text-slate-400"><span>Officer: {item.collectedBy}</span><button onClick={(e)=>{e.stopPropagation(); setFees(fees.filter(f=>f.id!==item.id));}} className="p-1 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button></div>
          </div>
        ))}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[720px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">Issue Fee Voucher / Bank Challan</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><form onSubmit={handleAdd} className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="text-xs font-bold uppercase">Student Name *</label><input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} className="w-full px-3 py-2 border rounded-xl text-xs mt-1" /></div><div><label className="text-xs font-bold uppercase">Roll No</label><input value={form.roll} onChange={e=>setForm({...form, roll:e.target.value})} className="w-full px-3 py-2 border rounded-xl text-xs mt-1 font-mono" /></div><div><label className="text-xs font-bold uppercase">Month</label><select value={form.month} onChange={e=>setForm({...form, month:e.target.value})} className="w-full px-3 py-2 border rounded-xl text-xs mt-1"><option>October 2026</option><option>September 2026</option><option>November 2026</option></select></div><div><label className="text-xs font-bold uppercase">Fee Head</label><select value={form.feeHead} onChange={e=>setForm({...form, feeHead:e.target.value})} className="w-full px-3 py-2 border rounded-xl text-xs mt-1"><option>Monthly</option><option>Admission</option><option>Exam</option></select></div><div><label className="text-xs font-bold uppercase">Amount</label><input type="number" value={form.amount} onChange={e=>setForm({...form, amount:Number(e.target.value)})} className="w-full px-3 py-2 border rounded-xl text-xs mt-1" /></div><div><label className="text-xs font-bold uppercase">Discount</label><input type="number" value={form.discount} onChange={e=>setForm({...form, discount:Number(e.target.value)})} className="w-full px-3 py-2 border rounded-xl text-xs mt-1" /></div><div className="sm:col-span-2 flex justify-end gap-2 mt-2"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-5 py-2 bg-zinc-100 rounded-xl text-xs font-bold">Cancel</button><button type="submit" className="px-5 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black">Issue VCH-26-XXX</button></div></form></div></div>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setSelected(null)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[560px] p-6"><div className="flex justify-between"><h3 className="font-black">Voucher {selected.voucherNo}</h3><button onClick={()=>setSelected(null)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><div className="mt-4 p-4 bg-slate-50 rounded-xl border"><p className="font-bold">{selected.studentName} - {selected.rollNo}</p><p className="text-xs text-slate-600 mt-1">{selected.batch} • {selected.month} • {selected.feeHead}</p><div className="mt-3 flex justify-between"><span>Amount:</span><span>PKR {selected.amount}</span></div><div className="flex justify-between text-emerald-700 font-black"><span>Net Payable:</span><span>PKR {selected.netPayable.toLocaleString()}</span></div><div className="mt-3 flex gap-2"><button onClick={()=>window.print()} className="flex-1 py-2 bg-black text-white rounded-full text-xs font-bold"><Receipt className="w-4 h-4 inline mr-1" />Print Challan</button></div></div></div></div>
      )}
    </div>
  );
}
