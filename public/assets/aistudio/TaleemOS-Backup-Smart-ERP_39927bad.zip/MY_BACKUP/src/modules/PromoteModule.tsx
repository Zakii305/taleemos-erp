import React, { useState, useMemo } from 'react';
import { GraduationCap, ArrowRight, Check, X, Search, Printer, Users, TrendingUp, AlertTriangle, CheckCircle2, Filter, ChevronRight } from 'lucide-react';

type Student = {
  id: string;
  name: string;
  father: string;
  rollNo: string;
  currentClass: string;
  currentBatch: string;
  result: 'Pass' | 'Fail' | 'Awaiting';
  percentage: number;
  feeStatus: 'Cleared' | 'Pending';
  attendance: number;
  eligible: boolean;
  promoted?: boolean;
  newClass?: string;
};

const CLASSES = ['Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10', 'Class 11', 'Class 12'];
const BATCHES = ['Batch A Morning', 'Batch B Morning', 'Batch C Afternoon'];

const INITIAL: Student[] = [
  { id:'STU-001', name:'Ahmed Ali Qasmi', father:'Muhammad Qasim', rollNo:'TA-2025-001', currentClass:'Class 9', currentBatch:'Batch A Morning', result:'Pass', percentage:78, feeStatus:'Cleared', attendance:88, eligible:true },
  { id:'STU-002', name:'Fatima Noor', father:'Noor Ahmed', rollNo:'TA-2025-002', currentClass:'Class 9', currentBatch:'Batch A Morning', result:'Pass', percentage:92, feeStatus:'Cleared', attendance:95, eligible:true },
  { id:'STU-003', name:'Muhammad Hadi', father:'Meer Hadi', rollNo:'TA-2025-003', currentClass:'Class 9', currentBatch:'Batch A Morning', result:'Fail', percentage:38, feeStatus:'Cleared', attendance:65, eligible:false },
  { id:'STU-004', name:'Ayesha Siddiqui', father:'Siddiqui', rollNo:'TA-2025-004', currentClass:'Class 9', currentBatch:'Batch B Morning', result:'Pass', percentage:65, feeStatus:'Pending', attendance:80, eligible:false },
  { id:'STU-005', name:'Ali Raza', father:'Raza Ahmed', rollNo:'TA-2025-005', currentClass:'Class 9', currentBatch:'Batch A Morning', result:'Pass', percentage:81, feeStatus:'Cleared', attendance:90, eligible:true },
  { id:'STU-006', name:'Zainab Khan', father:'Khan', rollNo:'TA-2025-006', currentClass:'Class 9', currentBatch:'Batch A Morning', result:'Pass', percentage:74, feeStatus:'Cleared', attendance:76, eligible:true },
  { id:'STU-007', name:'Bilal Ahmed', father:'Ahmed', rollNo:'TA-2025-007', currentClass:'Class 9', currentBatch:'Batch C Afternoon', result:'Awaiting', percentage:0, feeStatus:'Cleared', attendance:82, eligible:false },
  { id:'STU-008', name:'Sanaullah', father:'Ullah', rollNo:'TA-2025-008', currentClass:'Class 9', currentBatch:'Batch A Morning', result:'Pass', percentage:88, feeStatus:'Cleared', attendance:92, eligible:true },
];

export default function PromoteModule(){
  const [students, setStudents] = useState<Student[]>(INITIAL);
  const [currentSession] = useState('2025-2026');
  const [nextSession] = useState('2026-2027');
  const [sourceClass, setSourceClass] = useState('Class 9');
  const [sourceBatch, setSourceBatch] = useState('All');
  const [destClass, setDestClass] = useState('Class 10');
  const [destBatch, setDestBatch] = useState('Batch A Morning');
  const [search, setSearch] = useState('');
  const [filterEligible, setFilterEligible] = useState('All');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showConfirm, setShowConfirm] = useState(false);
  const [promotedHistory, setPromotedHistory] = useState<Student[]>([]);

  const filtered = useMemo(()=> {
    return students.filter(s=>{
      const matchClass = s.currentClass === sourceClass;
      const matchBatch = sourceBatch==='All' || s.currentBatch===sourceBatch;
      const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.rollNo.toLowerCase().includes(search.toLowerCase());
      const matchEligible = filterEligible==='All' || (filterEligible==='Eligible' && s.eligible) || (filterEligible==='Not Eligible' && !s.eligible) || (filterEligible==='Promoted' && s.promoted);
      return matchClass && matchBatch && matchSearch && matchEligible;
    });
  }, [students, sourceClass, sourceBatch, search, filterEligible]);

  const eligibleCount = filtered.filter(s=>s.eligible && !s.promoted).length;
  const promotedCount = students.filter(s=>s.promoted).length;
  const totalInClass = students.filter(s=>s.currentClass===sourceClass).length;

  const toggleSelect = (id: string) => {
    setSelectedIds(prev=> prev.includes(id) ? prev.filter(x=>x!==id) : [...prev, id]);
  };
  const selectAllEligible = () => {
    const ids = filtered.filter(s=>s.eligible && !s.promoted).map(s=>s.id);
    setSelectedIds(ids);
  };

  const handlePromote = () => {
    if(selectedIds.length===0) return;
    const updated = students.map(s=>{
      if(selectedIds.includes(s.id)){
        return { ...s, promoted:true, newClass:`${destClass} (${nextSession})` };
      }
      return s;
    });
    const newlyPromoted = updated.filter(s=>selectedIds.includes(s.id));
    setPromotedHistory([...newlyPromoted, ...promotedHistory]);
    setStudents(updated);
    setSelectedIds([]);
    setShowConfirm(false);
  };

  const handlePromoteAllEligible = () => {
    const ids = students.filter(s=>s.currentClass===sourceClass && s.eligible && !s.promoted).map(s=>s.id);
    setSelectedIds(ids);
    setShowConfirm(true);
  };

  return (
    <div className="space-y-4 animate-in fade-in">
      {/* HEADER - CLEAN TaleemOS only */}
      <div className="rounded-[20px] bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 p-5 text-white shadow-lg">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center"><GraduationCap className="w-5 h-5"/></div>
          <div>
            <h1 className="text-[16px] font-black tracking-tight">Promote Workflow PRO • Class Progression</h1>
            <p className="text-[11px] text-emerald-200/70">Session {currentSession} → {nextSession}</p>
          </div>
        </div>
      </div>

      {/* SESSION & ACTION BAR */}
      <div className="bg-white rounded-[18px] border p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center gap-6">
          <div className="text-center"><p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Current Session</p><p className="text-[16px] font-black mt-0.5">{currentSession}</p></div>
          <ChevronRight className="w-4 h-4 text-slate-300"/>
          <div className="text-center"><p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Next Session</p><p className="text-[16px] font-black text-emerald-600">{nextSession}</p></div>
          <div className="hidden md:flex items-center gap-3 ml-4 pl-6 border-l">
            <div className="text-center"><p className="text-[10px] text-slate-400">Total</p><p className="font-black">{totalInClass}</p></div>
            <div className="text-center"><p className="text-[10px] text-emerald-600">Eligible</p><p className="font-black text-emerald-600">{eligibleCount}</p></div>
            <div className="text-center"><p className="text-[10px] text-indigo-600">Promoted</p><p className="font-black text-indigo-600">{promotedCount}</p></div>
          </div>
        </div>
        <button onClick={handlePromoteAllEligible} disabled={eligibleCount===0} className="px-5 py-2.5 bg-black text-white rounded-full text-xs font-black hover:bg-zinc-800 disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2">
          Promote All Eligible → <span className="bg-white/20 px-2 py-0.5 rounded-full text-[10px]">{eligibleCount}</span>
        </button>
      </div>

      {/* CONTROLS */}
      <div className="bg-white rounded-[18px] border p-4 space-y-3 shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <div><label className="text-[10px] font-black uppercase text-slate-500">Source Class</label><select value={sourceClass} onChange={e=>setSourceClass(e.target.value)} className="mt-1 w-full px-3 py-2.5 border rounded-xl text-xs font-bold bg-white">{CLASSES.map(c=><option key={c}>{c}</option>)}</select></div>
          <div><label className="text-[10px] font-black uppercase text-slate-500">Source Batch</label><select value={sourceBatch} onChange={e=>setSourceBatch(e.target.value)} className="mt-1 w-full px-3 py-2.5 border rounded-xl text-xs bg-white"><option>All</option>{BATCHES.map(b=><option key={b}>{b}</option>)}</select></div>
          <div><label className="text-[10px] font-black uppercase text-slate-500">Destination Class</label><select value={destClass} onChange={e=>setDestClass(e.target.value)} className="mt-1 w-full px-3 py-2.5 border rounded-xl text-xs font-bold bg-emerald-50 border-emerald-200 text-emerald-800">{CLASSES.map(c=><option key={c}>{c}</option>)}</select></div>
          <div><label className="text-[10px] font-black uppercase text-slate-500">Destination Batch</label><select value={destBatch} onChange={e=>setDestBatch(e.target.value)} className="mt-1 w-full px-3 py-2.5 border rounded-xl text-xs bg-white">{BATCHES.map(b=><option key={b}>{b}</option>)}</select></div>
        </div>
        <div className="flex flex-col md:flex-row gap-3">
          <div className="relative flex-1"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search name or roll no..." className="w-full pl-10 pr-4 py-2.5 border rounded-full text-xs outline-none focus:border-black"/></div>
          <div className="flex gap-1.5 p-1 bg-slate-100 rounded-full">
            {['All','Eligible','Not Eligible','Promoted'].map(f=><button key={f} onClick={()=>setFilterEligible(f)} className={`px-3.5 py-1.5 rounded-full text-[11px] font-bold transition-all ${filterEligible===f?'bg-black text-white shadow':'text-slate-600 hover:bg-white'}`}>{f}</button>)}
          </div>
          <button onClick={selectAllEligible} className="px-4 py-2 bg-slate-900 text-white rounded-full text-[11px] font-bold">Select All Eligible</button>
        </div>
      </div>

      {/* STUDENTS LIST */}
      <div className="bg-white rounded-[18px] border shadow-sm overflow-hidden">
        <div className="p-4 border-b flex items-center justify-between">
          <div className="flex items-center gap-2"><Users className="w-4 h-4"/><span className="font-bold text-[13px]">{filtered.length} Students in {sourceClass}</span><span className="text-[11px] text-slate-500">• {selectedIds.length} selected</span></div>
          <div className="flex items-center gap-2">
            <button disabled={selectedIds.length===0} onClick={()=>setShowConfirm(true)} className="px-4 py-1.5 bg-emerald-600 text-white rounded-full text-[11px] font-bold disabled:opacity-30">Promote Selected ({selectedIds.length})</button>
            <button onClick={()=>window.print()} className="p-2 bg-slate-100 rounded-full"><Printer className="w-4 h-4"/></button>
          </div>
        </div>
        <div className="divide-y">
          {filtered.map(s=>(
            <div key={s.id} className={`p-4 flex items-center gap-3 hover:bg-slate-50 transition ${s.promoted?'bg-emerald-50/50':''} ${selectedIds.includes(s.id)?'bg-indigo-50/70 border-l-4 border-l-indigo-600':''}`}>
              <input type="checkbox" checked={selectedIds.includes(s.id)} onChange={()=>toggleSelect(s.id)} disabled={!s.eligible || s.promoted} className="w-4 h-4 rounded"/>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-bold text-[13px] truncate">{s.name}</span>
                  <span className="text-[10px] font-mono bg-slate-100 px-1.5 py-0.5 rounded">{s.rollNo}</span>
                  {s.promoted ? <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-black rounded-full flex items-center gap-1"><CheckCircle2 className="w-3 h-3"/>Promoted to {s.newClass}</span> :
                    s.eligible ? <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 text-[10px] font-black rounded-full">Eligible</span> :
                    <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-[10px] font-bold rounded-full flex items-center gap-1"><AlertTriangle className="w-3 h-3"/>Not Eligible</span>
                  }
                </div>
                <div className="flex items-center gap-3 mt-1 text-[11px] text-slate-500">
                  <span>{s.currentBatch}</span>
                  <span>• {s.result} {s.result!=='Awaiting' && `${s.percentage}%`}</span>
                  <span className={s.feeStatus==='Cleared'?'text-emerald-600':'text-rose-600'}>• Fee {s.feeStatus}</span>
                  <span>• Att {s.attendance}%</span>
                </div>
                {!s.eligible && !s.promoted && <p className="text-[10px] text-amber-700 mt-1">Reason: {s.result==='Fail'?'Failed in exam':''} {s.feeStatus==='Pending'?' Fee pending':''} {s.attendance<75?' Low attendance':''}</p>}
              </div>
              <ArrowRight className="w-4 h-4 text-slate-300 hidden md:block"/>
              <div className="hidden md:block text-right min-w-[110px]">
                <p className="text-[11px] text-slate-400">Will move to</p><p className="text-[12px] font-bold text-emerald-700">{destClass}</p><p className="text-[10px] text-slate-500">{destBatch}</p>
              </div>
            </div>
          ))}
          {filtered.length===0 && <div className="p-12 text-center text-slate-400 text-sm">No students found in this filter</div>}
        </div>
      </div>

      {/* CONFIRM MODAL */}
      {showConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div onClick={()=>setShowConfirm(false)} className="absolute inset-0 bg-black/50 backdrop-blur-sm"/>
          <div className="relative bg-white rounded-[22px] w-full max-w-[420px] p-6 shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mb-4"><GraduationCap className="w-6 h-6 text-emerald-600"/></div>
            <h3 className="font-black text-[16px]">Confirm Promotion?</h3>
            <p className="text-[12px] text-slate-600 mt-2">You are about to promote <span className="font-black text-black">{selectedIds.length} students</span> from <span className="font-bold">{sourceClass} ({currentSession})</span> to <span className="font-bold text-emerald-700">{destClass} - {destBatch} ({nextSession})</span>.</p>
            <div className="mt-4 p-3 bg-slate-50 rounded-xl border text-[11px]"><p className="font-bold">Selected Roll Nos:</p><p className="font-mono mt-1 text-slate-600 break-words">{selectedIds.map(id=>students.find(s=>s.id===id)?.rollNo).join(', ')}</p></div>
            <div className="mt-5 flex gap-2"><button onClick={()=>setShowConfirm(false)} className="flex-1 py-2.5 border rounded-full text-xs font-bold">Cancel</button><button onClick={handlePromote} className="flex-1 py-2.5 bg-black text-white rounded-full text-xs font-black">Yes, Promote Now</button></div>
          </div>
        </div>
      )}

      {/* HISTORY */}
      {promotedHistory.length>0 && (
        <div className="bg-white rounded-[18px] border p-4 shadow-sm">
          <h4 className="font-bold text-[13px] flex items-center gap-2"><TrendingUp className="w-4 h-4 text-emerald-600"/>Recently Promoted ({promotedHistory.length})</h4>
          <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2">
            {promotedHistory.slice(0,6).map(s=><div key={s.id} className="p-2.5 bg-emerald-50 border border-emerald-100 rounded-xl flex justify-between items-center"><span className="text-[12px] font-bold">{s.name} • {s.rollNo}</span><span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-full">→ {s.newClass}</span></div>)}
          </div>
        </div>
      )}
    </div>
  );
}
