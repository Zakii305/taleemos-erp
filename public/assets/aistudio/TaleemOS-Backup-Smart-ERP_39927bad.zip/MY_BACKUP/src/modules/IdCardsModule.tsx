import React, { useState } from 'react';
import { IdCard, Printer, Download, Search, QrCode, Filter } from 'lucide-react';

type StudentCard = {
  id: string; rollNo: string; name: string; fatherName: string;
  classBatch: string; photoUrl: string; batch: string;
};

const INITIAL: StudentCard[] = [
  { id:'STU-001', rollNo:'TAK-26-001', name:'Ahmed Ali Qasmi', fatherName:'Muhammad Qasim', classBatch:'10th-A', batch:'Batch 2026-A (Morning)', photoUrl:'https://i.pravatar.cc/100?img=1' },
  { id:'STU-002', rollNo:'TAK-26-002', name:'Fatima Noor', fatherName:'Noor Ahmed', classBatch:'9th-B', batch:'Batch 2026-B (Morning)', photoUrl:'https://i.pravatar.cc/100?img=2' },
  { id:'STU-003', rollNo:'TAK-26-003', name:'Muhammad Hadi', fatherName:'Meer Hadi', classBatch:'11th Pre-Eng', batch:'Batch 2026-A (Morning)', photoUrl:'https://i.pravatar.cc/100?img=3' },
  { id:'STU-004', rollNo:'TAK-26-004', name:'Ayesha Siddiqui', fatherName:'Siddiq Ahmed', classBatch:'10th-A', batch:'Batch 2026-A (Morning)', photoUrl:'https://i.pravatar.cc/100?img=4' },
  { id:'STU-005', rollNo:'TAK-26-005', name:'Bilal Raza', fatherName:'Ghulam Raza', classBatch:'ICS', batch:'Batch 2026-C (Afternoon)', photoUrl:'https://i.pravatar.cc/100?img=5' },
  { id:'STU-006', rollNo:'TAK-26-006', name:'Zainab Khan', fatherName:'Khan', classBatch:'9th-A', batch:'Batch 2026-B (Morning)', photoUrl:'https://i.pravatar.cc/100?img=6' },
  { id:'STU-007', rollNo:'TAK-26-007', name:'Usman Ali', fatherName:'Ali', classBatch:'F.Sc Med', batch:'Batch 2026-B (Morning)', photoUrl:'https://i.pravatar.cc/100?img=7' },
  { id:'STU-008', rollNo:'TAK-26-008', name:'Sajjad Ahmed', fatherName:'Ahmed', classBatch:'F.Sc Eng', batch:'Batch 2026-A (Morning)', photoUrl:'https://i.pravatar.cc/100?img=8' },
];

export default function IdCardsModule(){
  const [search, setSearch] = useState('');
  const [batchFilter, setBatchFilter] = useState('All');
  const students = INITIAL;
  const batches = [...new Set(students.map(s=>s.batch))];

  const filtered = students.filter(s=>{
    const ms = s.name.toLowerCase().includes(search.toLowerCase()) || s.rollNo.toLowerCase().includes(search.toLowerCase()) || s.fatherName.toLowerCase().includes(search.toLowerCase());
    const mb = batchFilter==='All' || s.batch===batchFilter;
    return ms && mb;
  });

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><IdCard className="w-5 h-5 text-white" /></span><h1 className="text-xl md:text-2xl font-black tracking-tight">Student ID Cards Generator</h1><span className="px-2 py-0.5 bg-amber-400 text-slate-950 font-black text-[10px] rounded uppercase">A4 8-UP PRO</span></div><p className="text-xs text-indigo-200 mt-1">Printable 8 cards per standard A4 sheet with QR code, Cloudinary photos, and institutional barcodes.</p></div>
        <div className="flex flex-wrap items-center gap-2"><button type="button" onClick={()=>window.print()} className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"><Printer className="w-4 h-4"/>Print 8-Card Sheet (A4)</button><button type="button" onClick={()=>window.print()} className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"><Download className="w-4 h-4"/>Download PDF</button></div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-[20px] border p-4 flex flex-col md:flex-row gap-3 no-print">
        <div className="relative flex-1"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search by name, TAK-26-XXX, or father name..." className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-500 focus:bg-white"/></div>
        <div className="flex items-center gap-2"><Filter className="w-4 h-4 text-slate-400"/><select value={batchFilter} onChange={e=>setBatchFilter(e.target.value)} className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium outline-none"><option value="All">All Batches</option>{batches.map(b=><option key={b} value={b}>{b}</option>)}</select></div>
      </div>

      {/* 8-Card Printable Grid */}
      <div id="id-cards-sheet" className="p-4 md:p-6 bg-slate-100 rounded-[22px] print:bg-white print:p-0">
        <div className="text-center mb-4 print:hidden"><span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Displaying {filtered.length} cards (Rendered 2 columns x 4 rows per page)</span></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 print:grid-cols-2 print:gap-3 max-w-[800px] mx-auto">
          {filtered.map((s)=>(
            <div key={s.id} className="w-full bg-white rounded-2xl border-2 border-indigo-900/40 shadow-md p-4 flex flex-col justify-between overflow-hidden relative print:shadow-none print:border print:border-slate-800 print:rounded-xl print:page-break-inside-avoid print:break-inside-avoid">
              {/* Card top banner */}
              <div className="flex items-center justify-between border-b border-indigo-900/20 pb-2"><div className="flex items-center gap-2"><div className="w-7 h-7 rounded-lg bg-indigo-950 text-white font-black text-xs flex items-center justify-center">TA</div><div><h5 className="text-[11px] font-black tracking-tight text-slate-900 uppercase leading-none">Taleem Academy</h5><span className="text-[8px] font-semibold text-indigo-700">Kandhkot Campus</span></div></div><span className="px-2 py-0.5 bg-indigo-50 border border-indigo-200 text-indigo-800 text-[8px] font-black rounded uppercase">Student ID</span></div>

              {/* Card Body */}
              <div className="flex items-center gap-3 my-2.5">
                <img src={s.photoUrl} alt={s.name} className="w-16 h-16 rounded-xl object-cover border-2 border-indigo-600 shadow shrink-0"/>
                <div className="text-xs min-w-0 flex-1"><h4 className="font-black text-slate-900 text-sm leading-snug truncate">{s.name}</h4><div className="text-[11px] text-slate-600 leading-tight"><div><span className="text-slate-400">Roll:</span> <span className="font-mono font-bold text-indigo-700">{s.rollNo}</span></div><div><span className="text-slate-400">Father:</span> {s.fatherName}</div><div><span className="text-slate-400">Class:</span> <span className="font-bold">{s.classBatch}</span></div><div><span className="text-slate-400">Batch:</span> {s.batch}</div></div></div>
              </div>

              {/* Card Footer */}
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-100">
                <div className="flex items-center gap-1.5"><QrCode className="w-8 h-8 text-slate-800"/><div className="text-[7px] leading-none"><div className="font-mono font-bold">{s.rollNo}</div><div className="text-slate-400">Scan to verify</div><div className="mt-0.5 h-1 w-12 bg-slate-900" style={{background:'repeating-linear-gradient(90deg, #000 0 2px, transparent 2px 4px)'}} /></div></div>
                <div className="text-right"><div className="text-[7px] font-bold text-slate-500 uppercase">Valid Till</div><div className="text-[10px] font-black font-mono">2027-05-30</div><div className="text-[7px] text-emerald-700 font-bold mt-1">✓ Verified</div></div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-600 via-violet-600 to-indigo-900"/>
            </div>
          ))}
        </div>
        {filtered.length===0 && <div className="text-center py-12 text-xs text-slate-500 bg-white rounded-2xl border">No students found — try different search or batch filter</div>}
      </div>
    </div>
  );
}
