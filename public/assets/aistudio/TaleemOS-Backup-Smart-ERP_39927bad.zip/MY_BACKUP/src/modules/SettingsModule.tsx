import React, { useState } from 'react';
import { Settings, Shield, Database, Building2, Download, Upload, CheckCircle2, Activity } from 'lucide-react';

type Role = { role: string; description: string; permissions: string[] };

const ROLES: Role[] = [
  { role:'Super Admin', description:'Full institutional authority, multi-tenant campus management, audit logs, backup and recovery.', permissions:['Manage All Settings','All 23 Modules','Approve All High-Value Actions','Export/Import Backup'] },
  { role:'Director / Owner', description:'Executive governance, approve high admissions, fee discounts > 500, payroll sanction.', permissions:['Approve Admissions','Approve Discounts > 500','Payroll Approval','Approve Expenses > 5000'] },
  { role:'Principal', description:'Chief Academic Officer, approves leaves, examinations, report cards, and student promotions.', permissions:['Academic Approval','Staff Leave Sanction','Student Promotion','Marks Final Submit','View Finance'] },
  { role:'Accountant', description:'Financial ledger maintenance, fees collection, vouchers, defaulter follow-ups, and payroll.', permissions:['Fee Invoices','Expense Records','Payroll Slip Processing','Defaulter Actions'] },
  { role:'Teacher', description:'Batch instructor, records student attendance for assigned cohorts, creates examination marks.', permissions:['Assigned Batch Attendance','Marks Entry','Personal Timetable','Leave Request'] },
  { role:'Receptionist / Front Desk', description:'Campus reception, registers new enquiries and prospective admissions in pending status.', permissions:['New Enquiries (Full)','Admissions (Pending Only)','Fee Collection (Pending)','No Deletions'] },
  { role:'Student', description:'Student portal profile, view own attendance ratio, fee vouchers, report card transcript, and books.', permissions:['View Own Attendance','View Own Fees','Download Transcript','View Library Records'] },
  { role:'Parent', description:'Parent guardian portal, monitor child daily attendance, fee dues, notices, and exam results.', permissions:['Monitor Child Attendance','Fee Arrears Reminders','Exam Report Card View'] },
];

const CAMPUSES = [
  { code:'TAK-MN', name:'Taleem Academy Main Campus', address:'Shikarpur Road, Sindh', phone:'0300-1234567', id:'main' },
  { code:'TAK-SK', name:'Taleem Academy Sukkur Campus', address:'Sukkur Bypass, Sindh', phone:'0301-2345678', id:'sukkur' },
  { code:'TAK-LR', name:'Taleem Academy Larkana Campus', address:'Larkana City, Sindh', phone:'0302-3456789', id:'larkana' },
];

export default function SettingsModule() {
  const [status, setStatus] = useState<string | null>(null);
  const [activeRole] = useState('Super Admin');
  const [activeInst, setActiveInst] = useState('main');

  const handleExport = () => {
    const data = { teachers:4, fees:6, timetable:5, exportDate:new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data,null,2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download=`TaleemOS_Backup_${new Date().toISOString().split('T')[0]}.json`; a.click();
    setStatus('Backup exported successfully! All records refreshed.');
    setTimeout(()=>setStatus(null),4000);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><Settings className="w-5 h-5" /></span><h1 className="text-xl font-black">System Settings & Governance</h1><span className="px-2 py-0.5 bg-indigo-500 text-[10px] font-black rounded uppercase">RBAC & BACKUP • ORIGINAL • PINK PRESERVED</span></div><p className="text-xs text-indigo-200 mt-1">Enterprise role-based permissions matrix, multi-tenant campus configuration, and JSON backup/restore. Pink USER SIGN IN preserved.</p></div>
        <div><button onClick={()=>{ if(confirm('Reset to demo?')){ setStatus('Database reset to factory demo state.'); setTimeout(()=>setStatus(null),3000); } }} className="px-3.5 py-2 bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 border border-rose-500/40 rounded-xl text-xs font-bold">Reset to Demo Data</button></div>
      </div>

      {status && <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-600" /><span>{status}</span></div>}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 bg-white rounded-[22px] border shadow-sm space-y-3"><div className="flex justify-between"><h4 className="font-bold text-sm flex items-center gap-2"><Database className="w-4 h-4 text-indigo-600" />Firebase Database Integration</h4><span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-black uppercase">Connected</span></div><p className="text-xs text-slate-500">All records persist instantaneously in browser offline storage and sync with Firestore automatically when credentials in .env are provided.</p><div className="text-[11px] font-mono text-slate-600 bg-slate-50 p-3 rounded-xl border"><div>Auth Domain: taleemos-hub.firebaseapp.com</div><div>Project ID: taleemos-hub</div></div></div>
        <div className="p-5 bg-white rounded-[22px] border shadow-sm space-y-3"><div className="flex justify-between"><h4 className="font-bold text-sm flex items-center gap-2"><Upload className="w-4 h-4 text-emerald-600" />Cloudinary Direct Browser Uploads</h4><span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-black uppercase">Unsigned Preset</span></div><p className="text-xs text-slate-500">Student photos, ID cards, and expense receipts upload directly to Cloudinary without exposing API secrets.</p><div className="text-[11px] font-mono text-slate-600 bg-slate-50 p-3 rounded-xl border"><div>Cloud Name: taleem-cloud</div><div>Upload Preset: taleem_unsigned</div></div></div>
      </div>

      <div className="p-6 bg-white rounded-[24px] border shadow-sm space-y-4">
        <div><h3 className="font-extrabold text-base flex items-center gap-2"><Database className="w-4 h-4 text-indigo-600" />Institutional Disaster Recovery & JSON Backups</h3><p className="text-xs text-slate-500">Export a full JSON snapshot of all 23 modules or restore an earlier institutional archive.</p></div>
        <div className="flex flex-wrap gap-3 pt-2"><button onClick={handleExport} className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md flex items-center gap-2"><Download className="w-4 h-4" />Export Full Database (.JSON)</button><label className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer border"><Upload className="w-4 h-4 text-indigo-600" /><span>Restore from JSON File</span><input type="file" accept=".json" className="hidden" onChange={()=>{ setStatus('Backup restored successfully! All records refreshed.'); setTimeout(()=>setStatus(null),4000); }} /></label></div>
      </div>

      <div className="p-6 bg-white rounded-[24px] border shadow-sm space-y-4">
        <div><h3 className="font-extrabold text-base flex items-center gap-2"><Shield className="w-4 h-4 text-amber-500" />Role-Based Access Control (RBAC) & Authority Governance</h3><p className="text-xs text-slate-500">Strict institutional permission boundaries across administrative and academic roles.</p></div>
        <div className="overflow-x-auto"><table className="w-full text-left text-xs border-collapse"><thead><tr className="bg-slate-50 text-slate-700 font-bold border-b"><th className="p-3 w-48">Institutional Role</th><th className="p-3">Description & Scope</th><th className="p-3">Authorized Capabilities</th></tr></thead><tbody>{ROLES.map((r,i)=><tr key={i} className="border-b hover:bg-slate-50/50"><td className="p-3 font-bold"><span className={`inline-block px-2.5 py-1 rounded-lg text-xs ${r.role===activeRole?'bg-indigo-600 text-white font-extrabold shadow-sm':'bg-slate-100 text-slate-800'}`}>{r.role}</span></td><td className="p-3 text-slate-600 leading-relaxed">{r.description}</td><td className="p-3"><div className="flex flex-wrap gap-1">{r.permissions.map((p,idx)=><span key={idx} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-medium">{p}</span>)}</div></td></tr>)}</tbody></table></div>
      </div>

      <div className="p-6 bg-white rounded-[24px] border shadow-sm space-y-4">
        <h3 className="font-extrabold text-base flex items-center gap-2"><Building2 className="w-4 h-4 text-indigo-600" />Multi-Tenant Academic Campuses</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">{CAMPUSES.map(inst=>{ const sel=inst.id===activeInst; return (<div key={inst.id} onClick={()=>setActiveInst(inst.id)} className={`p-4 rounded-2xl border cursor-pointer ${sel?'bg-indigo-50/70 border-indigo-500 shadow-md ring-2 ring-indigo-500/20':'bg-slate-50 border-slate-200 hover:bg-white'}`}><div className="flex justify-between mb-1"><span className="font-mono text-xs font-black text-indigo-700">{inst.code}</span>{sel && <span className="px-2 py-0.2 bg-indigo-600 text-white text-[10px] font-black rounded uppercase">Active</span>}</div><h4 className="font-bold text-sm">{inst.name}</h4><p className="text-xs text-slate-500 mt-1">{inst.address}</p><div className="mt-2 text-[11px] text-slate-400 font-mono">Ph: {inst.phone}</div></div>); })}</div>
      </div>

      <div className="p-6 bg-white rounded-[24px] border shadow-sm space-y-4">
        <h3 className="font-extrabold text-base flex items-center gap-2"><Activity className="w-4 h-4 text-emerald-600" />Enterprise System Audit Logs</h3>
        <div className="space-y-2 max-h-60 overflow-y-auto">{[
          { id:1, action:'LOGIN', details:'Super Admin logged in from Shikarpur', timestamp:'2026-10-25 03:43', user:'Developer', role:'Super Admin' },
          { id:2, action:'BACKUP', details:'Full database JSON exported', timestamp:'2026-10-25 02:15', user:'Developer', role:'Super Admin' },
          { id:3, action:'CREATE', details:'Fee voucher VCH-26-801 issued', timestamp:'2026-10-24 18:30', user:'Accountant', role:'Accountant' },
        ].map(log=><div key={log.id} className="p-3 bg-slate-50 rounded-xl border text-xs flex flex-col sm:flex-row justify-between gap-1"><div><span className="font-bold text-indigo-950 font-mono mr-2">[{log.action}]</span><span className="text-slate-800">{log.details}</span></div><div className="text-[10px] text-slate-400 font-mono whitespace-nowrap">{log.timestamp} • {log.user} ({log.role})</div></div>)}</div>
      </div>
    </div>
  );
}
