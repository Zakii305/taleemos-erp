import React, { useState } from 'react';
import { FileCheck, Plus, Printer, Search, Trash2, X, Award } from 'lucide-react';

type SubjectMark = { subject: string; marks: number; max: number; grade: string };
type ReportCard = {
  id: string; rollNo: string; studentName: string; fatherName: string;
  classBatch: string; examType: string; marksObtained: number; maxMarks: number;
  percentage: number; grade: string; rank: number; remarks: string; subjectsBreakdown: SubjectMark[];
};

const INITIAL_REPORTS: ReportCard[] = [
  { id:'REP-01', rollNo:'TAK-26-001', studentName:'Ahmed Ali Qasmi', fatherName:'Muhammad Ali', classBatch:'Batch 2026-A (Morning)', examType:'Mid-Term Examination', marksObtained:333, maxMarks:400, percentage:83.3, grade:'A', rank:2, remarks:'Commendable performance across all disciplines.', subjectsBreakdown:[{subject:'Physics', marks:85, max:100, grade:'A+'},{subject:'Mathematics', marks:90, max:100, grade:'A+'},{subject:'Chemistry', marks:80, max:100, grade:'A'},{subject:'English', marks:78, max:100, grade:'A'}] },
  { id:'REP-02', rollNo:'TAK-26-002', studentName:'Fatima Noor', fatherName:'Khalid Mehmood', classBatch:'9th-B Evening', examType:'Mid-Term Examination', marksObtained:355, maxMarks:400, percentage:88.8, grade:'A+', rank:1, remarks:'Excellent problem solving skills.', subjectsBreakdown:[{subject:'Physics', marks:92, max:100, grade:'A+'},{subject:'Mathematics', marks:95, max:100, grade:'A+'},{subject:'Chemistry', marks:88, max:100, grade:'A+'},{subject:'English', marks:80, max:100, grade:'A'}] },
  { id:'REP-03', rollNo:'TAK-26-003', studentName:'Usman Tariq', fatherName:'Tariq Jameel', classBatch:'10th-A Morning', examType:'Final Examination', marksObtained:260, maxMarks:400, percentage:65, grade:'B', rank:5, remarks:'Needs improvement in English.', subjectsBreakdown:[{subject:'Physics', marks:70, max:100, grade:'B'},{subject:'Mathematics', marks:75, max:100, grade:'A'},{subject:'Chemistry', marks:65, max:100, grade:'B'},{subject:'English', marks:50, max:100, grade:'C'}] },
];

export default function ReportCardsModule() {
  const [reports, setReports] = useState<ReportCard[]>(INITIAL_REPORTS);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<ReportCard | null>(null);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [form, setForm] = useState({ studentId:'TAK-26-001', name:'Ahmed Ali Qasmi', father:'Muhammad Ali', batch:'Batch 2026-A (Morning)', examType:'Mid-Term Examination', s1:85, s2:90, s3:80, s4:78, remarks:'Commendable performance' });

  const calcGrade = (pct:number)=>{ if(pct>=85) return 'A+'; if(pct>=75) return 'A'; if(pct>=65) return 'B'; if(pct>=50) return 'C'; if(pct>=40) return 'D'; return 'F'; };

  const handleCreate = (e: React.FormEvent)=>{
    e.preventDefault();
    const subs = [
      {subject:'Physics', marks:form.s1, max:100, grade:calcGrade(form.s1)},
      {subject:'Mathematics', marks:form.s2, max:100, grade:calcGrade(form.s2)},
      {subject:'Chemistry', marks:form.s3, max:100, grade:calcGrade(form.s3)},
      {subject:'English', marks:form.s4, max:100, grade:calcGrade(form.s4)},
    ];
    const total = subs.reduce((s,x)=>s+x.marks,0);
    const max = 400;
    const pct = Math.round((total/max)*1000)/10;
    const grade = calcGrade(pct);
    const nr: ReportCard = { id:`REP-${Date.now().toString().slice(-4)}`, rollNo:form.studentId, studentName:form.name, fatherName:form.father, classBatch:form.batch, examType:form.examType, marksObtained:total, maxMarks:max, percentage:pct, grade, rank:reports.length+1, remarks:form.remarks, subjectsBreakdown:subs };
    setReports([...reports, nr]); setIsAddOpen(false);
  };

  const filtered = reports.filter(r=> r.studentName.toLowerCase().includes(search.toLowerCase()) || r.rollNo.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><FileCheck className="w-5 h-5" /></span><h1 className="text-xl font-black">Report Cards & Transcripts PRO</h1><span className="px-2 py-0.5 bg-indigo-500 text-[10px] font-black rounded uppercase">TRANSCRIPTS • ORIGINAL</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Automated grading, percentage calculators, ranks, printable official transcripts</p></div>
        <div className="flex gap-2"><button onClick={()=>window.print()} className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-xl border border-white/20 flex items-center gap-1.5"><Printer className="w-4 h-4" />Print Ledger</button><button onClick={()=>setIsAddOpen(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4" />Create Transcript</button></div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm"><div className="relative"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" /><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search report cards by student, roll number, or class batch..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl text-xs outline-none" /></div></div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item=>(
          <div key={item.id} onClick={()=>setSelected(item)} className="p-5 bg-white rounded-[22px] border shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between">
            <div>
              <div className="flex justify-between"><span className="px-2.5 py-0.5 font-mono text-xs font-black bg-indigo-50 text-indigo-700 rounded-lg">{item.rollNo}</span><span className={`px-2.5 py-0.5 text-xs font-black rounded-full ${item.grade==='A+'||item.grade==='A'?'bg-emerald-100 text-emerald-800':'bg-indigo-100 text-indigo-800'}`}>Grade: {item.grade}</span></div>
              <h3 className="mt-2 text-base font-extrabold">{item.studentName}</h3><p className="text-xs text-slate-500">{item.classBatch}</p>
              <div className="mt-4 p-3 bg-slate-50 rounded-xl border grid grid-cols-3 gap-1 text-center font-mono"><div><span className="text-[9px] text-slate-400 uppercase block">Marks</span><span className="text-xs font-bold">{item.marksObtained}/{item.maxMarks}</span></div><div><span className="text-[9px] text-slate-400 uppercase block">Percentage</span><span className="text-xs font-bold text-indigo-700">{item.percentage}%</span></div><div><span className="text-[9px] text-slate-400 uppercase block">Position</span><span className="text-xs font-black text-amber-600">Rank #{item.rank}</span></div></div>
              <div className="mt-3 text-[11px] text-slate-500 italic bg-white p-2 rounded-lg border line-clamp-2">"{item.remarks}"</div>
            </div>
            <div className="mt-4 pt-3 border-t flex justify-between text-xs"><span className="text-[11px] text-slate-400 font-semibold">{item.examType}</span><button onClick={(e)=>{e.stopPropagation(); setReports(reports.filter(r=>r.id!==item.id));}} className="p-1 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button></div>
          </div>
        ))}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[640px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">Generate Academic Transcript</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><form onSubmit={handleCreate} className="space-y-4"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Student Name *</label><input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div><div><label className="block text-xs font-bold uppercase mb-1">Roll No</label><input value={form.studentId} onChange={e=>setForm({...form, studentId:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono" /></div></div><div className="p-4 bg-slate-50 rounded-2xl border space-y-3"><span className="text-xs font-bold uppercase">Subject Papers Marks (Out of 100)</span><div className="grid grid-cols-2 sm:grid-cols-4 gap-3"><input type="number" value={form.s1} onChange={e=>setForm({...form, s1:Number(e.target.value)})} className="w-full px-3 py-1.5 bg-white border rounded-lg text-xs font-mono font-bold" /><input type="number" value={form.s2} onChange={e=>setForm({...form, s2:Number(e.target.value)})} className="w-full px-3 py-1.5 bg-white border rounded-lg text-xs font-mono font-bold" /><input type="number" value={form.s3} onChange={e=>setForm({...form, s3:Number(e.target.value)})} className="w-full px-3 py-1.5 bg-white border rounded-lg text-xs font-mono font-bold" /><input type="number" value={form.s4} onChange={e=>setForm({...form, s4:Number(e.target.value)})} className="w-full px-3 py-1.5 bg-white border rounded-lg text-xs font-mono font-bold" /></div></div><div className="flex justify-end gap-2 border-t pt-3"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-4 py-2 border rounded-xl text-xs font-bold">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-black">Compile Transcript</button></div></form></div></div>
      )}

      {selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60"><div className="bg-white rounded-[24px] w-full max-w-[720px] p-6 max-h-[90vh] overflow-y-auto"><div className="flex justify-between"><h3 className="font-black">Official Transcript: {selected.studentName}</h3><button onClick={()=>setSelected(null)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><div className="mt-4 p-4 bg-slate-50 rounded-xl border grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs"><div><span className="text-slate-400 block text-[10px]">CANDIDATE NAME</span><strong className="uppercase">{selected.studentName}</strong></div><div><span className="text-slate-400 block text-[10px]">FATHER</span><strong>{selected.fatherName}</strong></div><div><span className="text-slate-400 block text-[10px]">ROLL</span><strong className="font-mono text-indigo-700">{selected.rollNo}</strong></div><div><span className="text-slate-400 block text-[10px]">BATCH</span><strong>{selected.classBatch}</strong></div></div><table className="w-full mt-4 border-collapse border border-slate-300 text-xs text-left"><thead><tr className="bg-slate-100 font-bold"><th className="border p-2">Subject</th><th className="border p-2 text-center">Max</th><th className="border p-2 text-center">Obtained</th><th className="border p-2 text-center">Grade</th></tr></thead><tbody>{selected.subjectsBreakdown.map((s,i)=><tr key={i}><td className="border p-2 font-bold">{s.subject}</td><td className="border p-2 text-center font-mono">{s.max}</td><td className="border p-2 text-center font-mono font-bold">{s.marks}</td><td className="border p-2 text-center font-bold text-indigo-700">{s.grade}</td></tr>)}<tr className="bg-slate-50 font-bold"><td className="border p-2">Aggregate</td><td className="border p-2 text-center">{selected.maxMarks}</td><td className="border p-2 text-center font-black text-indigo-900">{selected.marksObtained}</td><td className="border p-2 text-center font-black text-emerald-700">{selected.grade} ({selected.percentage}%)</td></tr></tbody></table><div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs flex justify-between"><span>Remarks: "{selected.remarks}"</span><span className="font-black">Rank #{selected.rank}</span></div><div className="mt-4 flex gap-2"><button onClick={()=>window.print()} className="flex-1 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1"><Printer className="w-4 h-4" />Print Official Transcript</button><button onClick={()=>setSelected(null)} className="px-5 py-2 bg-zinc-100 rounded-xl text-xs font-bold">Close</button></div></div></div>
      )}
    </div>
  );
}
