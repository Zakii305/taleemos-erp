import { useState, useEffect, useMemo } from 'react';
import { User, logout } from '../components/auth/AuthSystem';
import { db } from '../lib/firebase';
import { collection, getDocs, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { Search, ArrowUpRight, Building2, Users, GraduationCap, DollarSign, TrendingUp, Activity, BarChart3, ArrowLeft } from 'lucide-react';
import TeachersModule from './TeachersModule';
import FeesModule from './FeesModule';
import TimetableModule from './TimetableModule';
import SettingsModule from './SettingsModule';
import ReportCardsModule from './ReportCardsModule';
import InventoryModule from './InventoryModule';
import LeavesModule from './LeavesModule';
import StudentsModule from './StudentsModule';
import PromoteModule from './PromoteModule';
import LibraryModule from './LibraryModule';
import PayrollModule from './PayrollModule';
import BatchesModule from './BatchesModule';
import ExamsModule from './ExamsModule';
import CoursesModule from './CoursesModule';
import IdCardsModule from './IdCardsModule';
import EnquiriesModule from './EnquiriesModule';
import AdmissionsModule from './AdmissionsModule';
import AttendanceModule from './AttendanceModule';
import CertificatesModule from './CertificatesModule';
import TransfersModule from './TransfersModule';
import AccountsModule from './AccountsModule';
import AssetsModule from './AssetsModule';
import ExpensesModule from './ExpensesModule';
import DefaultersModule from './DefaultersModule';
import AlertsModule from './AlertsModule';
import CommunicationModule from './CommunicationModule';
import CampusModule from './CampusModule';

export default function DashboardModule({ user }: { user: User }) {
  const [drawer, setDrawer] = useState(false);
  const [active, setActive] = useState('dashboard');
  const [requests, setRequests] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [moduleSearch, setModuleSearch] = useState('');
  useEffect(()=>{ (async()=>{ if(!db) return; try{ const r=await getDocs(collection(db,"approval_requests")); const u=await getDocs(collection(db,"users")); setRequests(r.docs.map(d=>({ ...d.data(), _docId:d.id }))); setUsers(u.docs.map(d=>({ ...d.data(), _docId:d.id }))); }catch(e){} })(); }, []);
  const pendingCount = requests.filter((r:any)=>r.status==='pending').length;
  const hour = new Date().getHours(); const greeting = hour < 12 ? 'Good Morning' : hour < 18 ? 'Good Afternoon' : 'Good Evening';
  const revenueData = [
    { month:'Jan', revenue:450000, revPct:62 },
    { month:'Feb', revenue:520000, revPct:72 },
    { month:'Mar', revenue:610000, revPct:84 },
    { month:'Apr', revenue:580000, revPct:80 },
    { month:'May', revenue:720000, revPct:100 },
    { month:'Jun', revenue:690000, revPct:95 },
  ];
  const pieData = [
    { name:'Tuition Fees', value:65, color:'#6366f1' },
    { name:'Admissions', value:15, color:'#10b981' },
    { name:'Library', value:5, color:'#f59e0b' },
    { name:'Other', value:15, color:'#ec4899' },
  ];
  const groups = [
    { title:'MAIN', items:[ { id:'dashboard', name:'Dashboard', icon:'📊' }, { id:'approvals', name:'Approvals', icon:'✅', badge:`${pendingCount}` }, { id:'users', name:'Users', icon:'👥', badge:`${users.length}` }, { id:'settings', name:'Settings', icon:'⚙️' }, ]},
    { title:'STUDENTS & ADMISSIONS', items:[ { id:'students', name:'Students Directory', icon:'👨‍🎓' }, { id:'admissions', name:'Admissions', icon:'📝' }, { id:'promote', name:'Promote Workflow', icon:'📈' }, { id:'reportcards', name:'Report Cards', icon:'📄' }, { id:'batches', name:'Batches', icon:'🎓' }, { id:'courses', name:'Courses', icon:'📖' }, { id:'transfers', name:'Transfers', icon:'🔄' }, { id:'certificates', name:'Certificates', icon:'🏅' }, ]},
    { title:'ACADEMICS & CAMPUS', items:[ { id:'teachers', name:'Teacher Zone', icon:'👨‍🏫' }, { id:'timetable', name:'Timetable', icon:'🕒' }, { id:'attendance', name:'Attendance', icon:'📅' }, { id:'library', name:'Library ERP', icon:'📚' }, { id:'exams', name:'Exams', icon:'📝' }, { id:'idcards', name:'ID Cards', icon:'🪪' }, { id:'campus', name:'Campus', icon:'🏛️' }, ]},
    { title:'FINANCE & HR', items:[ { id:'fees', name:'Fees Finance', icon:'💰' }, { id:'payroll', name:'Payroll', icon:'💵' }, { id:'leaves', name:'Leaves', icon:'🌴' }, { id:'accounts', name:'Accounts', icon:'📊' }, { id:'enquiries', name:'Enquiries', icon:'📩' }, { id:'expenses', name:'Expenses', icon:'🧾' }, { id:'defaulters', name:'Defaulters', icon:'⚠️' }, ]},
    { title:'OPERATIONS', items:[ { id:'inventory', name:'Inventory', icon:'📦' }, { id:'assets', name:'Assets', icon:'🏫' }, { id:'alerts', name:'Alerts', icon:'🔔' }, { id:'communication', name:'Communication', icon:'📢' }, ]},
  ];
  const allItems = groups.flatMap(g=>g.items);
  const filteredModules = useMemo(()=> { if(!moduleSearch) return allItems.filter(i=>i.id!=='dashboard'); return allItems.filter(i=>i.id!=='dashboard' && i.name.toLowerCase().includes(moduleSearch.toLowerCase())); }, [moduleSearch, pendingCount, users.length]);
  const Wrap = ({title,children}:any)=><div className="space-y-4"><div className="bg-white rounded-2xl border p-4 shadow-sm"><h2 className="font-black text-[16px]">{title}</h2></div>{children}</div>;
  const renderDashboardHome = ()=>{
    return (
      <div className="space-y-5">
        <div className="rounded-[24px] bg-gradient-to-br from-slate-900 to-indigo-900 p-6 text-white shadow-lg">
          <div className="flex items-center gap-2 mb-2"><span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"/><span className="text-[11px] font-bold tracking-widest text-indigo-200">TALEEMOS OPERATIONAL</span></div>
          <h1 className="text-[24px] md:text-[28px] font-black leading-tight">{greeting}, {user.email?.split('@')[0]}!</h1>
          <p className="text-[13px] text-indigo-200/80 mt-1">Here's what's happening in your campus today.</p>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-[20px] border p-4 shadow-sm"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Total Students</p><p className="text-[26px] font-black mt-1">1,248</p><p className="text-[11px] text-emerald-600 font-bold mt-1 bg-emerald-50 px-2 py-0.5 rounded-full w-fit">↑ 12% this month</p></div>
          <div className="bg-white rounded-[20px] border p-4 shadow-sm"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Revenue</p><p className="text-[22px] font-black mt-1">PKR 720k</p><p className="text-[11px] text-slate-500 mt-1 bg-slate-50 px-2 py-0.5 rounded-full w-fit">May 2026</p></div>
          <div className="bg-white rounded-[20px] border p-4 shadow-sm"><p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Campus Capacity</p><p className="text-[20px] font-black mt-1">395 Students</p><p className="text-[11px] text-violet-600 font-bold mt-1 bg-violet-50 px-2 py-0.5 rounded-full w-fit">6 Venues</p></div>
          <div className="bg-white rounded-[20px] border p-4 shadow-sm bg-gradient-to-br from-emerald-500 to-teal-600 text-white border-0"><p className="text-[10px] font-black text-emerald-100 uppercase tracking-widest">Pending Approvals</p><p className="text-[26px] font-black mt-1">{pendingCount}</p><p className="text-[11px] text-emerald-100 mt-1 bg-white/20 px-2 py-0.5 rounded-full w-fit">Needs attention</p></div>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 bg-white rounded-[20px] border p-5 shadow-sm">
            <div className="flex items-center gap-2 mb-5"><div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center"><BarChart3 className="w-4 h-4 text-indigo-600"/></div><div><h3 className="font-bold text-[14px]">Revenue Overview</h3><p className="text-[11px] text-slate-500">Jan - Jun 2026 • PKR in thousands</p></div></div>
            <div className="space-y-3">{revenueData.map(d=><div key={d.month} className="flex items-center gap-3"><span className="text-[11px] font-bold w-7 text-slate-700">{d.month}</span><div className="flex-1 h-2.5 bg-slate-100 rounded-full overflow-hidden"><div className="h-full bg-black rounded-full transition-all duration-1000" style={{ width:`${d.revPct}%` }}/></div><span className="text-[11px] font-mono font-bold min-w-[60px] text-right">PKR {(d.revenue/1000).toFixed(0)}k</span></div>)}</div>
          </div>
          <div className="bg-white rounded-[20px] border p-5 shadow-sm">
            <h3 className="font-bold text-[14px]">Income Breakdown</h3><p className="text-[11px] text-slate-500 mb-4">Source distribution</p>
            <div className="flex justify-center mb-6"><div className="relative w-36 h-36"><div className="absolute inset-0 rounded-full" style={{ background:`conic-gradient(#6366f1 0% 65%, #10b981 65% 80%, #f59e0b 80% 85%, #ec4899 85% 100%)` }}/><div className="absolute inset-3 bg-white rounded-full flex flex-col items-center justify-center shadow-inner border"><span className="font-black text-[20px]">100%</span><span className="text-[10px] text-slate-400">Total</span><span className="text-[11px] font-bold text-indigo-600">PKR 720k</span></div></div></div>
            <div className="space-y-2">{pieData.map(p=><div key={p.name} className="flex items-center gap-2 text-[11px] p-2 rounded-lg bg-slate-50"><span className="w-2.5 h-2.5 rounded-full" style={{ background:p.color }}/><span className="flex-1 font-semibold">{p.name}</span><span className="font-bold bg-white px-2 py-0.5 rounded-full border text-[11px]">{p.value}%</span></div>)}</div>
          </div>
        </div>
        <div>
          <div className="flex items-center justify-between mb-3"><h3 className="font-black text-[11px] tracking-[0.14em] text-slate-500 uppercase">All Modules • Embedded</h3><div className="relative w-60"><Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/><input value={moduleSearch} onChange={e=>setModuleSearch(e.target.value)} placeholder="Search modules..." className="w-full pl-9 pr-3 py-2.5 bg-white border rounded-full text-[12px] outline-none focus:border-black"/></div></div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">{filteredModules.map(m=><button key={m.id} onClick={()=>{setActive(m.id); window.scrollTo({top:0, behavior:'smooth'});}} className="group bg-white border border-slate-200/80 rounded-[16px] p-4 flex items-center gap-3 text-left hover:border-black hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"><div className="w-11 h-11 rounded-[12px] bg-slate-50 group-hover:bg-black group-hover:text-white flex items-center justify-center text-[18px] transition-all">{m.icon}</div><div className="flex-1 min-w-0"><p className="font-bold text-[13px] truncate">{m.name}</p>{(m as any).badge && (m as any).badge!=='' && (m as any).badge!=='0' && <p className="text-[10px] text-amber-600 font-bold mt-0.5">{(m as any).badge} pending</p>}</div><ArrowUpRight className="w-4 h-4 text-slate-300 group-hover:text-black transition"/></button>)}</div>
          <div className="mt-5 p-3.5 bg-slate-900 rounded-[14px] text-center text-white text-[11px] font-bold tracking-wider">TALEEM ACADEMY KANDHKOT CAMPUS • TaleemOS</div>
        </div>
      </div>
    );
  };
  const renderContent = ()=>{
    if(active==='dashboard') return renderDashboardHome();
    if(active==='campus') return <Wrap title="Campus Infrastructure"><CampusModule /></Wrap>;
    if(active==='communication') return <Wrap title="Communication Broadcast"><CommunicationModule /></Wrap>;
    if(active==='alerts') return <Wrap title="Alerts & Notifications PRO"><AlertsModule /></Wrap>;
    if(active==='expenses') return <Wrap title="Expenses ERP"><ExpensesModule /></Wrap>;
    if(active==='defaulters') return <Wrap title="Fee Defaulters"><DefaultersModule /></Wrap>;
    if(active==='exams') return <Wrap title="Exams & Date Sheet"><ExamsModule /></Wrap>;
    if(active==='courses') return <Wrap title="Courses PRO"><CoursesModule /></Wrap>;
    if(active==='idcards') return <Wrap title="ID Cards A4 8-UP"><IdCardsModule /></Wrap>;
    if(active==='enquiries') return <Wrap title="Enquiries & Leads"><EnquiriesModule /></Wrap>;
    if(active==='payroll') return <Wrap title="Payroll PRO"><PayrollModule /></Wrap>;
    if(active==='batches') return <Wrap title="Batches"><BatchesModule /></Wrap>;
    if(active==='students') return <Wrap title="Students Directory"><StudentsModule /></Wrap>;
    if(active==='promote') return <Wrap title="Promote Workflow"><PromoteModule /></Wrap>;
    if(active==='library') return <Wrap title="Library ERP"><LibraryModule /></Wrap>;
    if(active==='teachers') return <Wrap title="Teacher Zone PRO"><TeachersModule /></Wrap>;
    if(active==='fees') return <Wrap title="Fees Finance ERP"><FeesModule /></Wrap>;
    if(active==='timetable') return <Wrap title="Timetable GRID"><TimetableModule /></Wrap>;
    if(active==='settings') return <Wrap title="Settings"><SettingsModule /></Wrap>;
    if(active==='reportcards') return <Wrap title="Report Cards PRO"><ReportCardsModule /></Wrap>;
    if(active==='inventory') return <Wrap title="Inventory Stock"><InventoryModule /></Wrap>;
    if(active==='leaves') return <Wrap title="Leaves ERP"><LeavesModule /></Wrap>;
    if(active==='admissions') return <Wrap title="Admissions"><AdmissionsModule /></Wrap>;
    if(active==='attendance') return <Wrap title="Attendance"><AttendanceModule /></Wrap>;
    if(active==='certificates') return <Wrap title="Certificates"><CertificatesModule /></Wrap>;
    if(active==='transfers') return <Wrap title="Transfers"><TransfersModule /></Wrap>;
    if(active==='accounts') return <Wrap title="Accounts"><AccountsModule /></Wrap>;
    if(active==='assets') return <Wrap title="Assets"><AssetsModule /></Wrap>;
    if(active==='approvals'){ return <Wrap title="Approvals"><div className="grid gap-2">{requests.map((r:any)=><div key={r._docId} className="bg-white border p-4 rounded-2xl"><p className="font-bold text-sm">{r.name} - {r.email}</p><button onClick={async()=>{ await setDoc(doc(db!,"users", r._docId), { ...r, status:'approved' }); await deleteDoc(doc(db!,"approval_requests", r._docId)); setRequests(requests.filter(x=>x._docId!==r._docId)); }} className="mt-2 w-full bg-black text-white py-2.5 rounded-xl text-xs font-bold">Approve</button></div>)}{requests.length===0 && <p className="text-xs text-zinc-500 p-6 bg-white rounded-2xl border text-center">No pending approvals</p>}</div></Wrap>; }
    if(active==='users'){ return <Wrap title="Users"><div className="bg-white rounded-2xl border divide-y">{users.map((u:any)=><div key={u._docId} className="p-3 flex justify-between"><span className="font-bold text-xs">{u.name}</span><span className="text-[11px] text-zinc-500">{u.email}</span></div>)}</div></Wrap>; }
    return <Wrap title={active.toUpperCase()}><div className="bg-white rounded-2xl border p-8 text-center"><p className="font-black">{active} Module</p></div></Wrap>;
  };
  return (
    <div className="min-h-screen bg-[#f6f7fb] flex">
      {drawer && <div onClick={()=>setDrawer(false)} className="fixed inset-0 bg-black/50 z-40 lg:hidden"/>}
      <aside className={`fixed lg:sticky top-0 h-[100dvh] w-[320px] bg-white z-50 border-r flex flex-col ${drawer?'translate-x-0':'-translate-x-full lg:translate-x-0'} transition-transform`}>
        <div className="bg-black text-white p-4 flex items-center gap-2"><span className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"/><h2 className="font-bold text-[15px]">TaleemOS</h2></div>
        <div className="flex-1 overflow-y-auto p-3 space-y-5">{groups.map(g=><div key={g.title}><p className="text-[10px] font-black text-zinc-400 px-2 mb-2 tracking-widest">{g.title}</p><div className="space-y-1">{g.items.map((it:any)=><button key={it.id} onClick={()=>{setActive(it.id); setDrawer(false); window.scrollTo({top:0, behavior:'smooth'});}} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[12.5px] border text-left ${active===it.id?'bg-black text-white font-bold shadow':'bg-white border-zinc-100 hover:border-zinc-300'}`}><span className="w-8 h-8 rounded-lg flex items-center justify-center bg-zinc-50 text-[14px]">{it.icon}</span><span className="flex-1 truncate">{it.name}</span>{(it as any).badge && (it as any).badge!=='' && (it as any).badge!=='0' && <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500 text-white font-bold">{(it as any).badge}</span>}</button>)}</div></div>)}</div>
        <div className="p-3 border-t"><button onClick={logout} className="w-full py-2.5 rounded-xl bg-black text-white text-xs font-bold">Logout</button></div>
      </aside>
      <div className="flex-1 min-w-0">
        <div className="sticky top-0 z-30 bg-white border-b backdrop-blur-xl bg-white/90">
          <div className="flex items-center gap-2 px-3 py-2.5">
            <button onClick={()=>setDrawer(true)} className="lg:hidden w-10 h-10 bg-black text-white rounded-xl flex items-center justify-center text-[16px]">☰</button>
            {active!=='dashboard' && (
              <button onClick={()=>{setActive('dashboard'); window.scrollTo({top:0, behavior:'smooth'});}} className="w-10 h-10 bg-white border border-slate-200 hover:border-black hover:bg-black hover:text-white rounded-xl flex items-center justify-center transition-all shadow-sm" title="Back to Dashboard">
                <ArrowLeft className="w-4 h-4"/>
              </button>
            )}
            <div className="flex-1 ml-1">
              <h1 className="font-bold text-[14px] leading-none">TaleemOS</h1>
              <p className="text-[10px] text-zinc-500 mt-0.5">{active==='dashboard' ? 'Dashboard • Overview' : `${active.toUpperCase()} • Press ← to go back`}</p>
            </div>
            <button onClick={()=>{setActive('dashboard'); window.scrollTo({top:0, behavior:'smooth'});}} className={`px-3.5 py-2 rounded-xl text-xs font-bold transition ${active==='dashboard' ? 'bg-slate-100 text-slate-400 cursor-default' : 'bg-black text-white hover:bg-zinc-800'}`}>Dashboard</button>
          </div>
        </div>
        <div className="p-3 md:p-5 space-y-4 pb-24">{renderContent()}</div>
      </div>
    </div>
  );
}
