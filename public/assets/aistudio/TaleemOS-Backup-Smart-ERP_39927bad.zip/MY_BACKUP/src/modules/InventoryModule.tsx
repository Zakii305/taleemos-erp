import React, { useState } from 'react';
import { Package, Plus, Printer, Search, AlertTriangle, ArrowUpRight, ArrowDownLeft, Trash2, X } from 'lucide-react';

type InventoryItem = {
  id: string; name: string; category: string;
  currentStock: number; minimumThreshold: number;
  unit: string; costPerUnit: number; location: string; lastUpdated: string;
};

const INITIAL: InventoryItem[] = [
  { id:'INV-01', name:'A4 Paper Box (500 Sheets)', category:'Stationery', currentStock:45, minimumThreshold:20, unit:'Boxes', costPerUnit:1500, location:'Main Store Cupboard B', lastUpdated:'2026-10-25' },
  { id:'INV-02', name:'White Board Markers', category:'Stationery', currentStock:8, minimumThreshold:20, unit:'Pieces', costPerUnit:120, location:'Main Store Cupboard A', lastUpdated:'2026-10-25' },
  { id:'INV-03', name:'Projector Epson EB-X51', category:'IT Equipment', currentStock:3, minimumThreshold:2, unit:'Pieces', costPerUnit:45000, location:'IT Lab Store', lastUpdated:'2026-10-24' },
  { id:'INV-04', name:'Chemistry Lab Beakers Set', category:'Lab Consumable', currentStock:15, minimumThreshold:10, unit:'Sets', costPerUnit:800, location:'Chemistry Lab', lastUpdated:'2026-10-23' },
  { id:'INV-05', name:'Student Desks', category:'Furniture', currentStock:25, minimumThreshold:10, unit:'Pieces', costPerUnit:2500, location:'Main Campus Store', lastUpdated:'2026-10-22' },
  { id:'INV-06', name:'Answer Sheets Bundle', category:'Stationery', currentStock:5, minimumThreshold:15, unit:'Bundles', costPerUnit:600, location:'Exam Cell', lastUpdated:'2026-10-25' },
];

export default function InventoryModule() {
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [form, setForm] = useState({ name:'', category:'Stationery', stock:50, threshold:20, unit:'Pieces', cost:150, location:'Main Store Cupboard B' });

  const filtered = inventory.filter(item=>{
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase()) || item.location.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter==='All' || item.category===categoryFilter;
    return matchSearch && matchCat;
  });
  const lowStock = inventory.filter(i=>i.currentStock <= i.minimumThreshold);

  const handleCreate = (e: React.FormEvent)=>{
    e.preventDefault();
    if(!form.name.trim()) return;
    const ni: InventoryItem = { id:`INV-${Date.now().toString().slice(-4)}`, name:form.name, category:form.category, currentStock:Number(form.stock), minimumThreshold:Number(form.threshold), unit:form.unit, costPerUnit:Number(form.cost), location:form.location, lastUpdated:new Date().toISOString().split('T')[0] };
    setInventory([...inventory, ni]); setIsAddOpen(false); setForm({ name:'', category:'Stationery', stock:50, threshold:20, unit:'Pieces', cost:150, location:'Main Store Cupboard B' });
  };
  const adjust = (id:string, delta:number)=>{ setInventory(inventory.map(i=> i.id===id ? { ...i, currentStock: Math.max(0, i.currentStock+delta), lastUpdated:new Date().toISOString().split('T')[0] } : i)); };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><Package className="w-5 h-5" /></span><h1 className="text-xl font-black">Institutional Inventory & Stationery</h1><span className="px-2 py-0.5 bg-indigo-500 text-[10px] font-black rounded uppercase">STOCK AUDIT • ORIGINAL</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Stationery reams, answer sheets, IT hardware, lab reagents, low-stock warnings</p></div>
        <div className="flex gap-2"><button onClick={()=>window.print()} className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-xl border border-white/20 flex items-center gap-1.5"><Printer className="w-4 h-4" />Print Stock Ledger</button><button onClick={()=>setIsAddOpen(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4" />Stock In Item</button></div>
      </div>

      {lowStock.length>0 && (
        <div className="p-4 bg-amber-50 border border-amber-300 rounded-2xl flex items-center justify-between gap-3 text-amber-900 text-xs">
          <div className="flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" /><div><span className="font-bold">Low Stock Warning: </span>{lowStock.map(i=>`${i.name} (${i.currentStock} ${i.unit})`).join(', ')}</div></div>
          <span className="px-2.5 py-1 bg-amber-200 text-amber-900 font-bold rounded-lg">Reorder Suggested</span>
        </div>
      )}

      <div className="p-4 bg-white rounded-[22px] border shadow-sm space-y-3">
        <div className="relative"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" /><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search items by name, category, or store location..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl text-xs outline-none" /></div>
        <div className="flex flex-wrap gap-2 text-xs"><span className="text-[11px] font-bold text-slate-400 uppercase">Category:</span>{['All','Stationery','IT Equipment','Furniture','Lab Consumable'].map(c=><button key={c} onClick={()=>setCategoryFilter(c)} className={`px-3 py-1 rounded-full text-[11px] font-bold ${categoryFilter===c?'bg-indigo-600 text-white':'bg-slate-100 text-slate-600'}`}>{c}</button>)}</div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item=>{
          const isLow = item.currentStock <= item.minimumThreshold;
          return (
            <div key={item.id} className="p-5 bg-white rounded-[22px] border shadow-sm hover:shadow-lg transition-all flex flex-col justify-between">
              <div>
                <div className="flex justify-between gap-2"><span className="px-2.5 py-0.5 text-xs font-bold bg-indigo-50 text-indigo-700 rounded-lg">{item.category}</span><span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${isLow?'bg-rose-100 text-rose-800':'bg-emerald-100 text-emerald-800'}`}>{isLow?'Low Stock':'In Stock'}</span></div>
                <h3 className="mt-2 text-base font-extrabold">{item.name}</h3><p className="text-xs text-slate-500 font-mono mt-0.5">Location: {item.location}</p>
                <div className="mt-4 p-3 bg-slate-50 rounded-xl border flex justify-between text-xs font-mono"><div><span className="text-[10px] text-slate-400 block">Current Balance</span><span className={`text-base font-black ${isLow?'text-rose-600':'text-slate-900'}`}>{item.currentStock} {item.unit}</span></div><div className="text-right"><span className="text-[10px] text-slate-400 block">Unit Price</span><span className="font-bold">PKR {item.costPerUnit}</span></div></div>
              </div>
              <div className="mt-4 pt-3 border-t flex justify-between text-xs">
                <div className="flex gap-1.5"><button onClick={()=>adjust(item.id,5)} className="px-2 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-lg text-[10px] flex items-center gap-0.5"><ArrowDownLeft className="w-3 h-3" />+5 In</button><button onClick={()=>adjust(item.id,-5)} className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-lg text-[10px] flex items-center gap-0.5"><ArrowUpRight className="w-3 h-3" />-5 Out</button></div>
                <button onClick={()=>setInventory(inventory.filter(i=>i.id!==item.id))} className="p-1 text-slate-400 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          );
        })}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[560px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">Stock In New Inventory Item</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><form onSubmit={handleCreate} className="space-y-4"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Item Title *</label><input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} placeholder="e.g. A4 Paper Box" className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none focus:border-indigo-600" /></div><div><label className="block text-xs font-bold uppercase mb-1">Category</label><select value={form.category} onChange={e=>setForm({...form, category:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white"><option>Stationery</option><option>IT Equipment</option><option>Furniture</option><option>Lab Consumable</option></select></div></div><div className="grid grid-cols-3 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Quantity</label><input type="number" value={form.stock} onChange={e=>setForm({...form, stock:Number(e.target.value)})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono font-bold" /></div><div><label className="block text-xs font-bold uppercase mb-1">Low Threshold</label><input type="number" value={form.threshold} onChange={e=>setForm({...form, threshold:Number(e.target.value)})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono font-bold text-rose-600" /></div><div><label className="block text-xs font-bold uppercase mb-1">Unit</label><input value={form.unit} onChange={e=>setForm({...form, unit:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div></div><div className="grid grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Cost Per Unit (PKR)</label><input type="number" value={form.cost} onChange={e=>setForm({...form, cost:Number(e.target.value)})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono" /></div><div><label className="block text-xs font-bold uppercase mb-1">Storage Location</label><input value={form.location} onChange={e=>setForm({...form, location:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div></div><div className="pt-3 flex justify-end gap-2 border-t"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-4 py-2 border rounded-xl text-xs font-bold">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 text-white rounded-xl text-xs font-black">Catalog Inventory</button></div></form></div></div>
      )}
    </div>
  );
}
