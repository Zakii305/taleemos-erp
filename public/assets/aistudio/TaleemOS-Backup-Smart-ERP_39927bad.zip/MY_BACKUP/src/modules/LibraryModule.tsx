import React, { useState } from 'react';
import { BookOpen, Search, Plus, X, Clock, AlertTriangle, CheckCircle2, DollarSign } from 'lucide-react';
type Book = { id: string; title: string; author: string; total: number; available: number; category: string; };
type Issue = { id: string; bookId: string; studentName: string; rollNo: string; issueDate: string; dueDate: string; status: 'Issued' | 'Returned' | 'Overdue'; fine: number; };
const BOOKS: Book[] = [
  { id:'LIB-01', title:'Physics by Halliday Resnick', author:'Resnick', total:20, available:15, category:'Science' },
  { id:'LIB-02', title:'Chemistry F.Sc Part I', author:'Punjab Board', total:30, available:18, category:'Science' },
  { id:'LIB-03', title:'Mathematics F.Sc', author:'M. Afzal', total:25, available:17, category:'Mathematics' },
  { id:'LIB-04', title:'English Grammar Wren & Martin', author:'Wren', total:15, available:10, category:'Languages' },
];
const ISSUES: Issue[] = [
  { id:'ISS-001', bookId:'LIB-01', studentName:'Ahmed Ali', rollNo:'TA-001', issueDate:'2026-01-10', dueDate:'2026-01-25', status:'Issued', fine:0 },
  { id:'ISS-002', bookId:'LIB-02', studentName:'Fatima Noor', rollNo:'TA-002', issueDate:'2026-01-01', dueDate:'2026-01-15', status:'Overdue', fine:150 },
];
export default function LibraryModule(){
  const [books, setBooks] = useState(BOOKS);
  const [issues, setIssues] = useState(ISSUES);
  const [search, setSearch] = useState('');
  const [showIssue, setShowIssue] = useState(false);
  const [issueForm, setIssueForm] = useState({ bookId:'LIB-01', studentName:'', rollNo:'' });
  const filtered = books.filter(b=> b.title.toLowerCase().includes(search.toLowerCase()) || b.id.toLowerCase().includes(search.toLowerCase()));
  const handleIssue = () => { if(!issueForm.studentName || !issueForm.rollNo) return; const n: Issue = { id:`ISS-${String(issues.length+1).padStart(3,'0')}`, bookId:issueForm.bookId, studentName:issueForm.studentName, rollNo:issueForm.rollNo, issueDate:new Date().toISOString().split('T')[0], dueDate:new Date(Date.now()+14*86400000).toISOString().split('T')[0], status:'Issued', fine:0 }; setIssues([n, ...issues]); setBooks(books.map(b=> b.id===issueForm.bookId ? { ...b, available:b.available-1 } : b)); setShowIssue(false); setIssueForm({ bookId:'LIB-01', studentName:'', rollNo:'' }); };
  const returnBook = (id: string) => { const iss = issues.find(i=>i.id===id); if(!iss) return; setIssues(issues.map(i=> i.id===id ? { ...i, status:'Returned' as const } : i)); setBooks(books.map(b=> b.id===iss.bookId ? { ...b, available:b.available+1 } : b)); };
  return (
    <div className="space-y-4">
      <div className="rounded-[20px] bg-black p-5 text-white flex items-center justify-between"><div className="flex items-center gap-3"><div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center"><BookOpen className="w-5 h-5"/></div><div><h1 className="text-[16px] font-black">Library ERP • Circulation & Fines</h1><p className="text-[11px] text-zinc-400">{books.length} Books • {books.reduce((a,b)=>a+b.available,0)} Available • {issues.filter(i=>i.status==='Overdue').length} Overdue</p></div></div><button onClick={()=>setShowIssue(true)} className="px-4 py-2 bg-white text-black rounded-full text-xs font-black">+ Issue Book</button></div>
      <div className="bg-white rounded-[18px] border p-3"><div className="relative"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search books..." className="w-full pl-10 pr-4 py-2.5 border rounded-full text-xs outline-none"/></div></div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">{filtered.map(b=><div key={b.id} className="bg-white rounded-[18px] border p-4 shadow-sm"><span className="font-mono text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded">{b.id}</span><p className="font-bold text-[13px] mt-2">{b.title}</p><p className="text-[11px] text-slate-500">{b.author} • {b.category}</p><p className="text-[11px] mt-1"><span className="font-bold text-emerald-600">{b.available} Available</span> / {b.total} Total</p><div className="mt-2 w-full bg-slate-100 h-1.5 rounded-full overflow-hidden"><div className="h-full bg-indigo-600 rounded-full" style={{ width:`${(b.available/b.total)*100}%` }}/></div></div>)}</div>
      <div className="bg-white rounded-[18px] border shadow-sm overflow-hidden"><div className="p-4 border-b font-bold text-[13px]">Recent Issues • Circulation</div><div className="divide-y">{issues.map(i=><div key={i.id} className="p-4 flex items-center justify-between"><div><p className="font-bold text-[12px]">{i.studentName} • {i.rollNo} <span className={`ml-2 px-2 py-0.5 rounded-full text-[10px] font-bold ${i.status==='Issued'?'bg-indigo-100 text-indigo-700':i.status==='Overdue'?'bg-rose-100 text-rose-700':'bg-emerald-100 text-emerald-700'}`}>{i.status} {i.fine>0 && `• PKR ${i.fine} Fine`}</span></p><p className="text-[11px] text-slate-500">{books.find(b=>b.id===i.bookId)?.title} • Issue {i.issueDate} • Due {i.dueDate}</p></div>{i.status!=='Returned' && <button onClick={()=>returnBook(i.id)} className="px-3 py-1 bg-black text-white rounded-full text-[11px] font-bold">Return</button>}</div>)}</div></div>
      {showIssue && <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setShowIssue(false)} className="absolute inset-0 bg-black/50"/><div className="relative bg-white rounded-[22px] w-full max-w-[400px] p-5"><div className="flex justify-between mb-4"><h3 className="font-black">Issue Book</h3><button onClick={()=>setShowIssue(false)} className="w-8 h-8 bg-slate-100 rounded-full flex items-center justify-center"><X className="w-4 h-4"/></button></div><div className="space-y-3"><select value={issueForm.bookId} onChange={e=>setIssueForm({...issueForm, bookId:e.target.value})} className="w-full px-3 py-2.5 border rounded-xl text-xs">{books.map(b=><option key={b.id} value={b.id}>{b.title} ({b.available} avail)</option>)}</select><input value={issueForm.studentName} onChange={e=>setIssueForm({...issueForm, studentName:e.target.value})} placeholder="Student Name" className="w-full px-3 py-2.5 border rounded-xl text-xs"/><input value={issueForm.rollNo} onChange={e=>setIssueForm({...issueForm, rollNo:e.target.value})} placeholder="Roll No" className="w-full px-3 py-2.5 border rounded-xl text-xs"/><button onClick={handleIssue} className="w-full py-2.5 bg-black text-white rounded-full text-xs font-black">Issue Now (14 Days)</button></div></div></div>}
    </div>
  );
}
