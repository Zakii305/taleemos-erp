import React, { useState } from 'react';
import { UserCheck, Printer, Download, Search, Users, CheckCircle2, XCircle, Clock, Send, Check } from 'lucide-react';

type AttStudent = { id: string; name: string; rollNo: string; fatherName: string; parentPhone: string; photoUrl: string; classBatch: string; };
type AttRecord = { id: string; date: string; batch: string; studentId: string; studentName: string; rollNo: string; status: 'P'|'A'|'L'; };

const ALL_BATCHES = ['Batch 2026-A (Morning)', 'Batch 2026-B (Morning)', 'Batch 2026-C (Afternoon)'];

const ALL_STUDENTS: AttStudent[] = [
  { id:'STU-001', name:'Ahmed Ali Qasmi', rollNo:'TAK-26-001', fatherName:'Muhammad Qasim', parentPhone:'0300-1234567', photoUrl:'https://i.pravatar.cc/100?img=1', classBatch:'Batch 2026-A (Morning)' },
  { id:'STU-002', name:'Fatima Noor', rollNo:'TAK-26-002', fatherName:'Noor Ahmed', parentPhone:'0301-2345678', photoUrl:'https://i.pravatar.cc/100?img=2', classBatch:'Batch 2026-A (Morning)' },
  { id:'STU-003', name:'Muhammad Hadi', rollNo:'TAK-26-003', fatherName:'Meer Hadi', parentPhone:'0302-3456789', photoUrl:'https://i.pravatar.cc/100?img=3', classBatch:'Batch 2026-A (Morning)' },
  { id:'STU-004', name:'Ayesha Siddiqui', rollNo:'TAK-26-004', fatherName:'Siddiq Ahmed', parentPhone:'0303-4567890', photoUrl:'https://i.pravatar.cc/100?img=4', classBatch:'Batch 2026-B (Morning)' },
  { id:'STU-005', name:'Bilal Raza', rollNo:'TAK-26-005', fatherName:'Ghulam Raza', parentPhone:'0304-5678901', photoUrl:'https://i.pravatar.cc/100?img=5', classBatch:'Batch 2026-B (Morning)' },
  { id:'STU-006', name:'Zainab Khan', rollNo:'TAK-26-006', fatherName:'Khan', parentPhone:'0305-6789012', photoUrl:'https://i.pravatar.cc/100?img=6', classBatch:'Batch 2026-C (Afternoon)' },
];

export default function AttendanceModule(){
  const [selectedBatch, setSelectedBatch] = useState(ALL_BATCHES[0]);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [attendance, setAttendance] = useState<AttRecord[]>([]);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);
  const [smsSentNotice, setSmsSentNotice] = useState<string|null>(null);
  const [search, setSearch] = useState('');

  const batchStudents = ALL_STUDENTS.filter(s=>s.classBatch===selectedBatch).filter(s=> s.name.toLowerCase().includes(search.toLowerCase()) || s.rollNo.toLowerCase().includes(search.toLowerCase()));

  const getStatus = (studentId: string): 'P'|'A'|'L' => {
    const rec = attendance.find(a=>a.studentId===studentId && a.date===selectedDate && a.batch===selectedBatch);
    return rec ? rec.status : 'P';
  };

  const handleSetStatus = (student: AttStudent, status: 'P'|'A'|'L')=>{
    const existing = attendance.find(a=>a.studentId===student.id && a.date===selectedDate && a.batch===selectedBatch);
    if(existing){
      setAttendance(attendance.map(a=> a.id===existing.id ? { ...a, status } : a));
    } else {
      const newRec: AttRecord = { id:`ATT-${Date.now().toString().slice(-4)}`, date:selectedDate, batch:selectedBatch, studentId:student.id, studentName:student.name, rollNo:student.rollNo, status };
      setAttendance([...attendance, newRec]);
    }
  };

  const markAll = (status: 'P'|'A')=>{
    batchStudents.forEach(student=>{ handleSetStatus(student, status); });
  };

  const presentCount = batchStudents.filter(s=>getStatus(s.id)==='P').length;
  const absentCount = batchStudents.filter(s=>getStatus(s.id)==='A').length;
  const lateCount = batchStudents.filter(s=>getStatus(s.id)==='L').length;
  const attendanceRate = batchStudents.length>0 ? Math.round((presentCount / batchStudents.length)*100) : 0;

  const handleSendSmsToAbsents = ()=>{
    const absents = batchStudents.filter(s=>getStatus(s.id)==='A');
    if(absents.length===0){ alert('No students marked absent for this batch today.'); return; }
    setSmsSentNotice(`Dispatched absence SMS notification to parents of ${absents.length} students via Gateway.`);
    setTimeout(()=>setSmsSentNotice(null), 4000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><UserCheck className="w-5 h-5"/></span><h1 className="text-xl md:text-2xl font-black tracking-tight">Student Daily Attendance</h1><span className="px-2 py-0.5 bg-emerald-500 text-white font-black text-[10px] rounded uppercase">BIOMETRIC & MANUAL</span></div><p className="text-xs text-indigo-200 mt-1">Take daily attendance per batch, mark P/A/L, send SMS to absent parents, and print roll sheet.</p></div>
        <div className="flex flex-wrap items-center gap-2"><button onClick={()=>setIsPrintAllOpen(true)} className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold rounded-xl"><Printer className="w-4 h-4"/>Print Roll Sheet</button><button onClick={handleSendSmsToAbsents} className="inline-flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black rounded-xl shadow-lg"><Send className="w-4 h-4"/>SMS Absent Parents</button></div>
      </div>

      {smsSentNotice && <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl flex items-center gap-2"><CheckCircle2 className="w-4 h-4"/>{smsSentNotice}</div>}

      <div className="grid grid-cols-4 gap-3">
        <div className="p-4 bg-white rounded-[20px] border shadow-sm"><div className="text-[11px] font-semibold text-indigo-600 uppercase">Present</div><div className="text-2xl font-black text-emerald-600 font-mono mt-1">{presentCount}</div></div>
        <div className="p-4 bg-white rounded-[20px] border shadow-sm"><div className="text-[11px] font-semibold text-rose-600 uppercase">Absent</div><div className="text-2xl font-black text-rose-600 font-mono mt-1">{absentCount}</div></div>
        <div className="p-4 bg-white rounded-[20px] border shadow-sm"><div className="text-[11px] font-semibold text-amber-600 uppercase">Late</div><div className="text-2xl font-black text-amber-600 font-mono mt-1">{lateCount}</div></div>
        <div className="p-4 bg-white rounded-[20px] border shadow-sm"><div className="text-[11px] font-semibold text-indigo-600 uppercase">Daily Ratio %</div><div className="text-2xl font-black text-indigo-600 font-mono mt-1">{attendanceRate}%</div></div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm flex flex-col md:flex-row gap-3">
        <div className="flex gap-2 items-center"><span className="text-xs font-bold">Batch:</span><select value={selectedBatch} onChange={e=>setSelectedBatch(e.target.value)} className="px-3 py-2 bg-slate-50 border rounded-xl text-xs font-bold">{ALL_BATCHES.map(b=><option key={b} value={b}>{b}</option>)}</select></div>
        <div className="flex gap-2 items-center"><span className="text-xs font-bold">Date:</span><input type="date" value={selectedDate} onChange={e=>setSelectedDate(e.target.value)} className="px-3 py-2 bg-slate-50 border rounded-xl text-xs font-mono font-bold"/></div>
        <div className="flex-1 relative"><Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search roll or name..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl text-xs"/></div>
        <div className="flex gap-2"><button onClick={()=>markAll('P')} className="px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1"><Check className="w-3.5 h-3.5"/>All Present</button><button onClick={()=>markAll('A')} className="px-3 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold flex items-center gap-1"><XCircle className="w-3.5 h-3.5"/>All Absent</button></div>
      </div>

      <div className="p-6 bg-white rounded-[24px] border shadow-sm overflow-x-auto">
        {batchStudents.length===0 ? (
          <div className="py-12 text-center text-slate-400"><p className="text-sm font-semibold">No students enrolled in {selectedBatch}</p><p className="text-xs mt-1">Assign students in Students Directory module</p></div>
        ) : (
          <table className="w-full text-left text-xs border-collapse">
            <thead><tr className="bg-slate-50 text-slate-700 font-bold border-b"><th className="p-3">Roll No</th><th className="p-3">Photo</th><th className="p-3">Student Name</th><th className="p-3">Father Name</th><th className="p-3">Parent Phone</th><th className="p-3 text-center">Take Attendance (P / A / L)</th></tr></thead>
            <tbody>{batchStudents.map(s=>{
              const st=getStatus(s.id);
              return (
                <tr key={s.id} className="border-b border-slate-100 hover:bg-slate-50/50 transition-colors">
                  <td className="p-3 font-mono font-bold text-indigo-700">{s.rollNo}</td>
                  <td className="p-3"><img src={s.photoUrl} alt={s.name} className="w-8 h-8 rounded-lg object-cover border"/></td>
                  <td className="p-3 font-bold">{s.name}</td>
                  <td className="p-3">{s.fatherName}</td>
                  <td className="p-3 font-mono">{s.parentPhone}</td>
                  <td className="p-3"><div className="flex items-center justify-center gap-1.5">
                    <button onClick={()=>handleSetStatus(s,'P')} className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${st==='P'?'bg-emerald-600 text-white shadow':'text-slate-600 hover:bg-slate-200'}`}>P</button>
                    <button onClick={()=>handleSetStatus(s,'A')} className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${st==='A'?'bg-rose-600 text-white shadow':'text-slate-600 hover:bg-slate-200'}`}>A</button>
                    <button onClick={()=>handleSetStatus(s,'L')} className={`px-3 py-1.5 rounded-lg text-xs font-black transition-all ${st==='L'?'bg-amber-500 text-white shadow':'text-slate-600 hover:bg-slate-200'}`}>L</button>
                  </div></td>
                </tr>
              );
            })}</tbody>
          </table>
        )}
      </div>

      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b mb-4"><h3 className="font-bold text-base">Daily Attendance Roll Sheet (A4)</h3><div className="flex items-center gap-2"><button onClick={()=>window.print()} className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold flex items-center gap-1"><Printer className="w-3.5 h-3.5"/>Print A4</button><button onClick={()=>setIsPrintAllOpen(false)} className="px-3 py-1.5 text-xs text-slate-500">Close</button></div></div>
            <div id="attendance-print-table">
              <div className="text-center border-b pb-3 mb-3"><h2 className="font-black text-lg">Taleem Academy Kandhkot Campus</h2><p className="font-bold">Daily Attendance Sheet — {selectedBatch} — {selectedDate}</p><div className="flex justify-center gap-6 mt-2 text-xs"><span>Present: {presentCount}</span><span>Absent: {absentCount}</span><span>Daily Rate: {attendanceRate}%</span></div></div>
              <table className="w-full border-collapse border border-slate-300 text-left text-xs"><thead><tr className="bg-slate-100 font-bold"><th className="border border-slate-300 p-2">Roll No</th><th className="border border-slate-300 p-2">Student Name</th><th className="border border-slate-300 p-2">Father Name</th><th className="border border-slate-300 p-2">Parent Phone</th><th className="border border-slate-300 p-2 text-center">Status</th></tr></thead><tbody>{batchStudents.map(s=>{ const st=getStatus(s.id); return <tr key={s.id}><td className="border p-2 font-mono font-bold">{s.rollNo}</td><td className="border p-2">{s.name}</td><td className="border p-2">{s.fatherName}</td><td className="border p-2">{s.parentPhone}</td><td className="border p-2 text-center font-black">{st}</td></tr>; })}</tbody></table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
