import React, { useState } from 'react';
import { BookOpen, Plus, Printer, Search, Trash2, X } from 'lucide-react';

type Course = {
  id: string; name: string; code: string; duration: string;
  fee: number; subjects: string[]; department: string; status: 'Active'|'Draft'; instructor: string;
};

const INITIAL: Course[] = [
  { id:'CRS-01', name:'F.Sc Pre-Engineering', code:'FSC-ENG', duration:'2 Years', fee:4000, subjects:['Physics','Chemistry','Mathematics'], department:'Science & Engineering', status:'Active', instructor:'Prof. Ghulam Rasool' },
  { id:'CRS-02', name:'F.Sc Pre-Medical', code:'FSC-MED', duration:'2 Years', fee:4000, subjects:['Physics','Chemistry','Biology'], department:'Science & Medical', status:'Active', instructor:'Miss Ayesha Khan' },
  { id:'CRS-03', name:'F.Sc General Science', code:'FSC-GEN', duration:'2 Years', fee:3500, subjects:['Physics','Mathematics','Computer'], department:'Science & Engineering', status:'Active', instructor:'Sir Sajjad Ahmed' },
  { id:'CRS-04', name:'ICS Computer Science', code:'ICS-CS', duration:'2 Years', fee:3500, subjects:['Computer','Mathematics','Physics'], department:'Computer Science', status:'Active', instructor:'Dr. Usman Ali' },
  { id:'CRS-05', name:'Commerce', code:'COM-01', duration:'2 Years', fee:3000, subjects:['Accounting','Business Math','Economics'], department:'Commerce', status:'Active', instructor:'Sir Bilal Raza' },
];

export default function CoursesModule() {
  const [courses, setCourses] = useState<Course[]>(INITIAL);
  const [search, setSearch] = useState('');
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selected, setSelected] = useState<Course | null>(null);
  const [form, setForm] = useState({ name:'', code:'', duration:'2 Years', fee:5000, subjectsStr:'Physics, Chemistry, Mathematics', department:'Science & Engineering', instructor:'Prof. Ghulam Rasool' });

  const filtered = courses.filter(c=> c.name.toLowerCase().includes(search.toLowerCase()) || c.code.toLowerCase().includes(search.toLowerCase()) || c.department.toLowerCase().includes(search.toLowerCase()));

  const handleCreate = (e: React.FormEvent)=>{
    e.preventDefault();
    if(!form.name.trim() || !form.code.trim()) return;
    const nc: Course = { id:`CRS-0${courses.length+1}`, name:form.name, code:form.code, duration:form.duration, fee:Number(form.fee), subjects:form.subjectsStr.split(',').map(s=>s.trim()).filter(Boolean), department:form.department, status:'Active', instructor:form.instructor };
    setCourses([nc, ...courses]); setIsAddOpen(false);
    setForm({ name:'', code:'', duration:'2 Years', fee:5000, subjectsStr:'Physics, Chemistry, Mathematics', department:'Science & Engineering', instructor:'Prof. Ghulam Rasool' });
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><BookOpen className="w-5 h-5" /></span><h1 className="text-xl font-black">Academic Courses & Programs</h1><span className="px-2 py-0.5 bg-indigo-500 text-[10px] font-black rounded uppercase">CRS-XXXX • ORIGINAL SAFE</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Institutional Academic Programs Catalog • CRS-CATALOG-2026</p></div>
        <div className="flex gap-2"><button onClick={()=>window.print()} className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-xl border border-white/20 flex items-center gap-1.5"><Printer className="w-4 h-4"/>Print Catalog</button><button onClick={()=>setIsAddOpen(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4"/>Add New Course</button></div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm"><div className="relative"><Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400"/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search courses by title, code, or department..." className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500"/></div></div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(item=>(
          <div key={item.id} onClick={()=>setSelected(item)} className="p-5 bg-white rounded-[22px] border shadow-sm hover:shadow-lg hover:-translate-y-0.5 transition-all cursor-pointer flex flex-col justify-between">
            <div><div className="flex justify-between items-start gap-2"><span className="px-2.5 py-0.5 font-mono text-xs font-black bg-indigo-50 text-indigo-700 rounded-lg border border-indigo-200">{item.id}</span><span className="px-2 py-0.2 rounded-full text-[10px] font-black uppercase bg-emerald-100 text-emerald-800">{item.status}</span></div>
              <h3 className="mt-3 text-base font-extrabold leading-snug">{item.name}</h3><p className="text-xs font-mono text-indigo-600 font-bold">{item.code} • {item.department}</p>
              <div className="mt-3 p-3 bg-slate-50 rounded-xl border grid grid-cols-2 gap-2 text-xs"><div><span className="text-[10px] text-slate-400 uppercase block">Duration</span><span className="font-bold">{item.duration}</span></div><div><span className="text-[10px] text-slate-400 uppercase block">Tuition</span><span className="font-bold text-indigo-700 font-mono">PKR {item.fee}/mo</span></div><div className="col-span-2"><span className="text-[10px] text-slate-400 uppercase block">Lead Instructor / Dean</span><span className="font-bold">{item.instructor}</span></div></div>
              <div className="mt-3 flex flex-wrap gap-1">{item.subjects.map((sub,i)=><span key={i} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[10px] font-medium">{sub}</span>)}</div>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs"><span className="text-[11px] text-slate-400 font-mono">ID: {item.id}</span><button type="button" onClick={(e)=>{e.stopPropagation(); setCourses(courses.filter(x=>x.id!==item.id));}} className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer" title="Delete"><Trash2 className="w-3.5 h-3.5"/></button></div>
          </div>
        ))}
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60"/><div className="relative bg-white rounded-[24px] w-full max-w-[720px] p-6 max-h-[90vh] overflow-y-auto"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">Add New Academic Course Program</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4"/></button></div><p className="text-xs text-slate-500 mb-1">Define subjects, curriculum length, and tuition charges</p><span className="inline-block mb-4 px-2 py-0.5 bg-indigo-50 text-indigo-700 text-[10px] font-black rounded uppercase border border-indigo-200">Course Definition</span><form onSubmit={handleCreate} className="space-y-4"><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Course Title *</label><input required value={form.name} onChange={e=>setForm({...form, name:e.target.value})} placeholder="e.g. F.Sc General Science" className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none focus:border-indigo-600"/></div><div><label className="block text-xs font-bold uppercase mb-1">Course Code *</label><input required value={form.code} onChange={e=>setForm({...form, code:e.target.value})} placeholder="e.g. FSC-GEN" className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono outline-none"/></div></div><div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Duration</label><input value={form.duration} onChange={e=>setForm({...form, duration:e.target.value})} placeholder="2 Years" className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div><div><label className="block text-xs font-bold uppercase mb-1">Fee (PKR/month)</label><input type="number" value={form.fee} onChange={e=>setForm({...form, fee:Number(e.target.value)})} className="w-full px-3.5 py-2 border rounded-xl text-xs font-mono font-bold"/></div><div><label className="block text-xs font-bold uppercase mb-1">Department</label><input value={form.department} onChange={e=>setForm({...form, department:e.target.value})} placeholder="Science & Engineering" className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div></div><div><label className="block text-xs font-bold uppercase mb-1">Subjects (Comma separated)</label><input value={form.subjectsStr} onChange={e=>setForm({...form, subjectsStr:e.target.value})} placeholder="Physics, Chemistry, Mathematics, English" className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div><div><label className="block text-xs font-bold uppercase mb-1">Lead Instructor / Dean</label><input value={form.instructor} onChange={e=>setForm({...form, instructor:e.target.value})} placeholder="Professor name" className="w-full px-3.5 py-2 border rounded-xl text-xs"/></div><div className="pt-3 flex justify-end gap-2 border-t"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-4 py-2 border rounded-xl text-xs font-bold">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-lg shadow-indigo-600/30">Save Course</button></div></form></div></div>
      )}

      {selected && !isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setSelected(null)} className="absolute inset-0 bg-black/60"/><div className="relative bg-white rounded-[24px] w-full max-w-[560px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">{selected.name}</h3><button onClick={()=>setSelected(null)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4"/></button></div><div className="p-4 bg-slate-50 rounded-xl border grid grid-cols-2 gap-3 text-xs"><div><span className="text-slate-400 block text-[10px]">CODE</span><strong className="font-mono">{selected.code}</strong></div><div><span className="text-slate-400 block text-[10px]">DEPARTMENT</span><strong>{selected.department}</strong></div><div><span className="text-slate-400 block text-[10px]">DURATION</span><strong>{selected.duration}</strong></div><div><span className="text-slate-400 block text-[10px]">FEE</span><strong className="font-mono text-indigo-700">PKR {selected.fee}/mo</strong></div><div className="col-span-2"><span className="text-slate-400 block text-[10px]">INSTRUCTOR</span><strong>{selected.instructor}</strong></div></div><div className="mt-4"><p className="text-[10px] font-bold text-slate-400 uppercase mb-2">Subjects</p><div className="flex flex-wrap gap-1.5">{selected.subjects.map((s,i)=><span key={i} className="px-2.5 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-full text-[11px] font-bold">{s}</span>)}</div></div><div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900"><span className="font-bold">Catalog:</span> CRS-CATALOG-2026 • {selected.id} • Active Streams • TaleemOS Hub</div><div className="mt-4 flex gap-2"><button onClick={()=>window.print()} className="flex-1 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1"><Printer className="w-4 h-4"/>Print Course Detail</button><button onClick={()=>setSelected(null)} className="px-5 py-2 bg-zinc-100 rounded-xl text-xs font-bold">Close</button></div></div></div>
      )}
    </div>
  );
}
