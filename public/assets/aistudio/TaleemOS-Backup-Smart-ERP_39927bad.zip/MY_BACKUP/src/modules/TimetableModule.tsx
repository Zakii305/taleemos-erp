import React, { useState } from 'react';
import { Clock, Plus, Printer, X } from 'lucide-react';

type TimetableSlot = {
  id: string; batch: string; day: string; period: number;
  timing: string; subject: string; teacher: string; room: string;
};

const BATCHES = ['Batch 2026-A (Morning)', 'Batch 2026-B (Evening)', 'Batch 2026-C', '10th-A Morning', '9th-B Evening'];
const DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const PERIODS = [1,2,3,4,5,6];
const TIMINGS: Record<number,string> = {
  1:'08:00 - 08:50', 2:'08:50 - 09:40', 3:'09:40 - 10:30',
  4:'10:50 - 11:40', 5:'11:40 - 12:30', 6:'12:30 - 01:15'
};

const INITIAL_SLOTS: TimetableSlot[] = [
  { id:'TT-01', batch:'Batch 2026-A (Morning)', day:'Monday', period:1, timing:TIMINGS[1], subject:'Physics', teacher:'Sir Sajjad Ahmed', room:'Room 101' },
  { id:'TT-02', batch:'Batch 2026-A (Morning)', day:'Monday', period:2, timing:TIMINGS[2], subject:'Mathematics', teacher:'Miss Ayesha Khan', room:'Room 102' },
  { id:'TT-03', batch:'Batch 2026-A (Morning)', day:'Tuesday', period:1, timing:TIMINGS[1], subject:'English', teacher:'Sir Bilal Raza', room:'Room 101' },
  { id:'TT-04', batch:'Batch 2026-A (Morning)', day:'Wednesday', period:3, timing:TIMINGS[3], subject:'Computer', teacher:'Dr. Usman Ali', room:'Lab 02' },
  { id:'TT-05', batch:'Batch 2026-A (Morning)', day:'Thursday', period:2, timing:TIMINGS[2], subject:'Chemistry', teacher:'Miss Ayesha Khan', room:'Lab 01' },
];

export default function TimetableModule() {
  const [slots, setSlots] = useState<TimetableSlot[]>(INITIAL_SLOTS);
  const [selectedBatch, setSelectedBatch] = useState(BATCHES[0]);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [form, setForm] = useState({ day:'Monday', period:1, timing:TIMINGS[1], subject:'Physics', teacher:'Sir Sajjad Ahmed', room:'Room 101' });

  const handlePeriodChange = (p:number)=>{ setForm({ ...form, period:p, timing:TIMINGS[p] }); };

  const handleCreate = (e: React.FormEvent)=>{
    e.preventDefault();
    const existing = slots.find(t=>t.batch===selectedBatch && t.day===form.day && t.period===form.period);
    if(existing){
      setSlots(slots.map(s=>s.id===existing.id ? { ...s, subject:form.subject, teacher:form.teacher, room:form.room, timing:form.timing } : s));
    }else{
      const ns: TimetableSlot = { id:`TT-${Date.now().toString().slice(-4)}`, batch:selectedBatch, day:form.day, period:form.period, timing:form.timing, subject:form.subject, teacher:form.teacher, room:form.room };
      setSlots([...slots, ns]);
    }
    setIsAddOpen(false);
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row justify-between gap-4">
        <div><div className="flex items-center gap-2"><span className="p-2 bg-indigo-600 rounded-xl"><Clock className="w-5 h-5" /></span><h1 className="text-xl font-black">Academic Timetable Matrix (GRID)</h1><span className="px-2 py-0.5 bg-indigo-500 text-[10px] font-black rounded uppercase">6-PERIOD GRID • ORIGINAL</span></div><p className="text-xs text-indigo-200 mt-1">Original taleemos-hub1.zip • Weekly class schedule, lecture timings, faculty assignments, venue allocation</p></div>
        <div className="flex gap-2"><button onClick={()=>window.print()} className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-xs font-bold rounded-xl border border-white/20 flex items-center gap-1.5"><Printer className="w-4 h-4" />Print Timetable</button><button onClick={()=>setIsAddOpen(true)} className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-xs font-black rounded-xl flex items-center gap-1.5"><Plus className="w-4 h-4" />Assign Period</button></div>
      </div>

      <div className="p-4 bg-white rounded-[22px] border shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3"><span className="text-xs font-bold text-slate-500 uppercase">Select Class Cohort:</span><select value={selectedBatch} onChange={e=>setSelectedBatch(e.target.value)} className="px-3.5 py-1.5 bg-indigo-50 border border-indigo-200 rounded-xl text-xs font-bold text-indigo-900 outline-none">{BATCHES.map(b=><option key={b} value={b}>{b}</option>)}</select></div>
        <div className="flex items-center gap-4 text-xs text-slate-500 font-mono"><span>6 Daily Periods</span><span>•</span><span>45-50 Min Lectures</span><span>•</span><span>10:30-10:50 Recess Break</span></div>
      </div>

      <div className="p-4 md:p-6 bg-white rounded-[24px] border shadow-sm overflow-x-auto">
        <table className="w-full min-w-[700px] border-collapse text-xs">
          <thead><tr className="bg-slate-50 text-slate-700 font-bold border-b"><th className="p-3 text-left w-24">Day</th>{PERIODS.map(p=><th key={p} className="p-3 text-center border-l"><div>Period {p}</div><div className="text-[10px] text-slate-400 font-mono font-normal">{TIMINGS[p]}</div></th>)}</tr></thead>
          <tbody>{DAYS.map(day=><tr key={day} className="border-b hover:bg-slate-50/50"><td className="p-3 font-bold bg-slate-50/30">{day}</td>{PERIODS.map(p=>{ const slot = slots.find(t=>t.batch===selectedBatch && t.day===day && t.period===p); return (<td key={p} className="p-2 border-l text-center align-top h-24 w-36">{slot ? (<div className="h-full p-2.5 bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-200 rounded-xl flex flex-col justify-between group hover:shadow-md relative"><button onClick={()=>setSlots(slots.filter(s=>s.id!==slot.id))} className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 text-slate-400 hover:text-rose-600">×</button><div><div className="font-extrabold text-indigo-900">{slot.subject}</div><div className="text-[10px] text-slate-500 font-semibold mt-0.5">{slot.teacher}</div></div><div className="text-[9px] font-mono text-indigo-700 bg-indigo-100/60 rounded px-1.5 py-0.5 mt-1">{slot.room}</div></div>) : (<div onClick={()=>{ setForm({ ...form, day, period:p, timing:TIMINGS[p] }); setIsAddOpen(true); }} className="h-full border border-dashed border-slate-200 hover:border-indigo-400 hover:bg-indigo-50/30 rounded-xl flex flex-col items-center justify-center text-slate-300 hover:text-indigo-600 cursor-pointer"><Plus className="w-4 h-4" /><span className="text-[9px] font-bold mt-0.5">Assign</span></div>)}</td>);})}</tr>)}</tbody>
        </table>
      </div>

      {isAddOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"><div onClick={()=>setIsAddOpen(false)} className="absolute inset-0 bg-black/60" /><div className="relative bg-white rounded-[24px] w-full max-w-[560px] p-6"><div className="flex justify-between mb-4"><h3 className="font-black text-lg">Assign Timetable Slot</h3><button onClick={()=>setIsAddOpen(false)} className="w-8 h-8 bg-zinc-100 rounded-full flex items-center justify-center"><X className="w-4 h-4" /></button></div><p className="text-xs text-slate-500 mb-4">Cohort: {selectedBatch}</p><form onSubmit={handleCreate} className="space-y-4"><div className="grid grid-cols-1 sm:grid-cols-3 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Day</label><select value={form.day} onChange={e=>setForm({...form, day:e.target.value})} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white">{DAYS.map(d=><option key={d}>{d}</option>)}</select></div><div><label className="block text-xs font-bold uppercase mb-1">Period</label><select value={form.period} onChange={e=>handlePeriodChange(Number(e.target.value))} className="w-full px-3.5 py-2 border rounded-xl text-xs bg-white font-mono">{PERIODS.map(p=><option key={p} value={p}>Period {p} ({TIMINGS[p]})</option>)}</select></div><div><label className="block text-xs font-bold uppercase mb-1">Room</label><input value={form.room} onChange={e=>setForm({...form, room:e.target.value})} placeholder="Room 101" className="w-full px-3.5 py-2 border rounded-xl text-xs" /></div></div><div className="grid grid-cols-1 sm:grid-cols-2 gap-4"><div><label className="block text-xs font-bold uppercase mb-1">Subject *</label><input required value={form.subject} onChange={e=>setForm({...form, subject:e.target.value})} placeholder="Physics" className="w-full px-3.5 py-2 border rounded-xl text-xs focus:border-indigo-600 outline-none" /></div><div><label className="block text-xs font-bold uppercase mb-1">Faculty *</label><input required value={form.teacher} onChange={e=>setForm({...form, teacher:e.target.value})} placeholder="Instructor Name" className="w-full px-3.5 py-2 border rounded-xl text-xs outline-none" /></div></div><div className="pt-3 flex justify-end gap-2 border-t"><button type="button" onClick={()=>setIsAddOpen(false)} className="px-4 py-2 border text-xs font-bold rounded-xl">Cancel</button><button type="submit" className="px-5 py-2 bg-indigo-600 text-white text-xs font-black rounded-xl">Save Slot</button></div></form></div></div>
      )}
    </div>
  );
}
