/**
 * Cloudinary Unsigned Upload Utility
 * Supports direct browser uploads to Cloudinary without exposing API secrets.
 * Provides fallback to Base64 data URLs for seamless offline/local execution.
 */

export const CLOUDINARY_CLOUD_NAME =
  import.meta.env.VITE_CLOUDINARY_CLOUD_NAME || 'demo-edu';
export const CLOUDINARY_UPLOAD_PRESET =
  import.meta.env.VITE_CLOUDINARY_UPLOAD_PRESET || 'taleemos_preset';

export interface CloudinaryUploadResult {
  secure_url: string;
  public_id: string;
  format: string;
  bytes: number;
}

export async function uploadToCloudinary(file: File): Promise<string> {
  // If demo credentials or offline, convert to instant Base64 data URL with realistic preview
  const isDemo =
    CLOUDINARY_CLOUD_NAME === 'demo-edu' ||
    CLOUDINARY_UPLOAD_PRESET === 'taleemos_preset' ||
    !navigator.onLine;

  if (isDemo) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result as string);
      };
      reader.readAsDataURL(file);
    });
  }

  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', CLOUDINARY_UPLOAD_PRESET);
  formData.append('folder', 'taleemos_erp');

  try {
    const response = await fetch(
      `https://api.cloudinary.com/v1_1/${CLOUDINARY_CLOUD_NAME}/auto/upload`,
      {
        method: 'POST',
        body: formData,
      }
    );

    if (!response.ok) {
      throw new Error(`Cloudinary upload failed: ${response.statusText}`);
    }

    const data: CloudinaryUploadResult = await response.json();
    return data.secure_url;
  } catch (err) {
    console.warn('Direct Cloudinary upload failed, falling back to local data URL:', err);
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        resolve(reader.result as string);
      };
      reader.readAsDataURL(file);
    });
  }
}
