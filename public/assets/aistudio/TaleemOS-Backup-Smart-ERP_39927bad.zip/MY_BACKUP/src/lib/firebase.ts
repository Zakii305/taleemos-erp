import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyChex6LVImnOrUS94SgvhRJ5-Ugjpybevg",
  authDomain: "hisaab-kitaab-27e3f.firebaseapp.com",
  projectId: "hisaab-kitaab-27e3f",
  storageBucket: "hisaab-kitaab-27e3f.firebasestorage.app",
  messagingSenderId: "130568215824",
  appId: "1:130568215824:web:dec9dec4ac252011581995",
  measurementId: "G-6V5FRYTS4W"
};

let app, auth, db, googleProvider;
try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  googleProvider = new GoogleAuthProvider();
  console.log("🔥 Firebase Connected:", firebaseConfig.projectId);
} catch (e) {
  console.error("Firebase Error:", e);
  // @ts-ignore
  db = null; auth = null;
}

export { auth, db, googleProvider };
export const isFirebaseEnabled = () => !!db;
