import React, { useState, useEffect } from 'react';
import {
  Bell,
  Megaphone,
  Plus,
  X,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Send,
  Building2,
  Globe,
  Radio,
  ExternalLink,
} from 'lucide-react';
import { erpStorage, INSTITUTIONS } from '../../lib/storage';
import { type AlertNotification } from '../../types';
import { getCurrentUser } from '../auth/AuthSystem';
import { saveNoticeToFirestore, deleteNoticeFromFirestore } from '../../lib/academyService';
import { logAuditEvent } from '../../lib/auditLogger';

interface TopbarNoticesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (path: string) => void;
}

export const TopbarNoticesModal: React.FC<TopbarNoticesModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
}) => {
  const currentUser = getCurrentUser();
  const isDev = currentUser?.role === 'developer';
  const isAdmin = currentUser?.role === 'admin';
  const isTeacher = currentUser?.role === 'teacher';
  const canPostNotices = isDev || isAdmin || isTeacher;

  const userAcademyId = currentUser?.academyId || 'inst-1';
  const userAcademyName =
    currentUser?.academyName ||
    INSTITUTIONS.find((i) => i.academyId === userAcademyId)?.academyName ||
    'Taleem Academy';

  const [alerts, setAlerts] = useState<AlertNotification[]>([]);
  const [showPostForm, setShowPostForm] = useState(false);
  const [editingAlertId, setEditingAlertId] = useState<string | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<AlertNotification['priority']>('Medium');
  const [type, setType] = useState<AlertNotification['type']>('General');
  const [audience, setAudience] = useState<AlertNotification['audience']>('All');
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const loadAlerts = () => {
    const all = erpStorage.getState().alerts;
    // Filter for tenant isolation
    const filtered = all.filter((item) => {
      if (isDev) return true;
      const belongsToOwn = item.academyId === userAcademyId;
      const isGlobal = item.academyId === 'all';
      const isLegacy = !item.academyId;
      return belongsToOwn || isGlobal || isLegacy;
    });
    setAlerts(filtered);
  };

  useEffect(() => {
    loadAlerts();
    const handleStorage = () => loadAlerts();
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, [userAcademyId, isDev]);

  // Body scroll locking and touch containment while modal is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      document.body.style.touchAction = 'none';
      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      window.addEventListener('keydown', handleKeyDown);
      return () => {
        document.body.style.overflow = '';
        document.body.style.touchAction = '';
        window.removeEventListener('keydown', handleKeyDown);
      };
    } else {
      document.body.style.overflow = '';
      document.body.style.touchAction = '';
    }
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const canModify = (item: AlertNotification) => {
    if (isDev) return true;
    if ((isAdmin || isTeacher) && (item.academyId === userAcademyId || (!item.academyId && userAcademyId === 'inst-1'))) {
      return true;
    }
    if (item.postedById && (item.postedById === currentUser?.uid || item.postedById === currentUser?.id)) {
      return true;
    }
    return false;
  };

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;

    if (editingAlertId) {
      const existing = alerts.find((a) => a.id === editingAlertId);
      if (existing) {
        const updated = {
          ...existing,
          title: title.trim(),
          message: message.trim(),
          priority,
          type,
          audience,
        };
        erpStorage.updateItem('alerts', existing.id, updated);
        saveNoticeToFirestore(updated);
        logAuditEvent({
          action: 'NOTICE_UPDATE',
          module: 'Alerts & Notices',
          targetRecord: title,
          details: `Updated notice ${existing.id} via Topbar Quick Panel`,
        });
        setSuccessMsg('Notice updated successfully!');
      }
      setEditingAlertId(null);
    } else {
      const targetAcadId = isDev ? 'all' : userAcademyId;
      const targetAcadName = isDev ? 'Global Broadcast (All Academies)' : userAcademyName;

      const newAlert: AlertNotification = {
        id: `ALT-${Date.now().toString().slice(-4)}`,
        title: title.trim(),
        type,
        priority,
        date: new Date().toISOString().split('T')[0],
        audience,
        status: 'New',
        message: message.trim(),
        assignedTo: isTeacher ? `${currentUser?.name || 'Teacher'} (Faculty)` : 'Academy Administration',
        actionTaken: 'Published via Topbar',
        academyId: targetAcadId,
        academyName: targetAcadName,
        postedBy: currentUser?.name || (isDev ? 'Developer' : isTeacher ? 'Teacher' : 'Admin'),
        postedByRole: currentUser?.role || (isDev ? 'developer' : isTeacher ? 'teacher' : 'admin'),
        postedById: currentUser?.uid || currentUser?.id || 'usr-quick',
      };

      erpStorage.addItem('alerts', newAlert);
      saveNoticeToFirestore(newAlert);
      logAuditEvent({
        action: 'NOTICE_CREATE',
        module: 'Alerts & Notices',
        targetRecord: title,
        details: `Published notice for ${targetAcadName} via Topbar Quick Panel`,
      });
      setSuccessMsg(`Notice published to ${targetAcadName}!`);
    }

    loadAlerts();
    setTitle('');
    setMessage('');
    setShowPostForm(false);
    setTimeout(() => setSuccessMsg(null), 3000);
  };

  const handleStartEdit = (item: AlertNotification) => {
    setEditingAlertId(item.id);
    setTitle(item.title);
    setMessage(item.message);
    setPriority(item.priority);
    setType(item.type);
    setAudience(item.audience);
    setShowPostForm(true);
  };

  const handleDelete = async (item: AlertNotification) => {
    if (confirm(`Delete notice "${item.title}"?`)) {
      erpStorage.deleteItem('alerts', item.id);
      await deleteNoticeFromFirestore(item.id);
      logAuditEvent({
        action: 'NOTICE_DELETE',
        module: 'Alerts & Notices',
        targetRecord: item.title,
        details: `Deleted notice ${item.id} via Topbar Quick Panel`,
      });
      loadAlerts();
      setSuccessMsg('Notice deleted.');
      setTimeout(() => setSuccessMsg(null), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end md:justify-center items-center overflow-y-auto no-print overscroll-contain touch-pan-y">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/75 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Dialog */}
      <div className="relative w-full max-w-2xl bg-white rounded-t-[28px] md:rounded-[24px] shadow-2xl border border-slate-200/80 max-h-[88vh] flex flex-col z-10 my-0 md:my-8 overflow-hidden overscroll-contain">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center text-xl shrink-0">
              📢
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-tight text-white">
                  Academy Notices & Broadcasts
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-black uppercase tracking-wider bg-indigo-500/30 text-indigo-200 border border-indigo-400/30 rounded-md">
                  {isDev ? 'Global' : userAcademyName.split(' ')[0]}
                </span>
              </div>
              <p className="text-xs text-indigo-200/80 mt-0.5">
                {isTeacher
                  ? 'Teachers & Admins can publish, edit & manage academy notices'
                  : 'Official announcements, exam circulars & academic notices'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-full transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Alert */}
        {successMsg && (
          <div className="px-5 py-2.5 bg-emerald-50 border-b border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Action Bar (Top of Body) */}
        <div className="px-5 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between gap-3 shrink-0">
          <div className="text-xs text-slate-600 font-semibold">
            <span>{alerts.length} Active Notices</span>
          </div>

          <div className="flex items-center gap-2">
            {canPostNotices && (
              <button
                type="button"
                onClick={() => {
                  if (showPostForm) {
                    setShowPostForm(false);
                    setEditingAlertId(null);
                    setTitle('');
                    setMessage('');
                  } else {
                    setShowPostForm(true);
                  }
                }}
                className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{showPostForm ? 'Cancel Post' : '+ Post Notice'}</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                onClose();
                onNavigate('alerts');
              }}
              className="px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <span>Full Center</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content Body with overscroll containment */}
        <div
          className="p-5 overflow-y-auto flex-1 space-y-4 overscroll-contain touch-pan-y"
          style={{ WebkitOverflowScrolling: 'touch' }}
        >
          {/* Quick Notice Post / Edit Form */}
          {showPostForm && canPostNotices && (
            <form
              onSubmit={handlePublish}
              className="p-4 bg-indigo-50/70 border border-indigo-200 rounded-2xl space-y-3 animate-fade-in"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase tracking-wider text-indigo-900 flex items-center gap-1.5">
                  <Megaphone className="w-3.5 h-3.5 text-indigo-600" />
                  {editingAlertId ? 'Edit Notice' : 'Post New Notice'}
                </span>
                <span className="text-[10px] font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-full">
                  Scope: {isDev ? 'Global Broadcast' : userAcademyName}
                </span>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Notice Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Mid-Term Examination Routine Announced"
                  className="w-full px-3 py-2 bg-white border rounded-xl text-xs outline-none focus:border-indigo-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                    Priority
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 bg-white border rounded-lg font-bold"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                    <option value="Critical">Critical</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                    Category
                  </label>
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 bg-white border rounded-lg font-bold"
                  >
                    <option value="General">General</option>
                    <option value="Exam Schedule">Exam Schedule</option>
                    <option value="Fee Due">Fee Due</option>
                    <option value="Staff Meeting">Staff Meeting</option>
                    <option value="Student Absenteeism">Absenteeism</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                    Audience
                  </label>
                  <select
                    value={audience}
                    onChange={(e) => setAudience(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 bg-white border rounded-lg font-bold"
                  >
                    <option value="All">All Academy</option>
                    <option value="Teachers">Faculty / Teachers</option>
                    <option value="Students">Students</option>
                    <option value="Parents">Parents</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase mb-1">
                  Notice Details / Message *
                </label>
                <textarea
                  required
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Enter notice details, instructions, or timetable announcements..."
                  className="w-full px-3 py-2 bg-white border rounded-xl text-xs outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setShowPostForm(false);
                    setEditingAlertId(null);
                  }}
                  className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-black shadow transition flex items-center gap-1 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{editingAlertId ? 'Save Changes' : 'Publish Notice'}</span>
                </button>
              </div>
            </form>
          )}

          {/* Notices List */}
          {alerts.length === 0 ? (
            <div className="py-12 text-center text-slate-400 bg-slate-50 rounded-2xl border border-dashed">
              <Bell className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-600">No Active Notices</p>
              <p className="text-xs text-slate-400 mt-1">
                Announcements published for this academy will appear here in real time.
              </p>
            </div>
          ) : (
            alerts.map((item) => {
              const userCanModify = canModify(item);
              const isCritical = item.priority === 'Critical';
              const isHigh = item.priority === 'High';

              return (
                <div
                  key={item.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isCritical
                      ? 'bg-rose-50/70 border-rose-300 shadow-xs'
                      : isHigh
                      ? 'bg-amber-50/60 border-amber-300'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1 min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                            isCritical
                              ? 'bg-rose-100 text-rose-800 border-rose-300'
                              : isHigh
                              ? 'bg-amber-100 text-amber-800 border-amber-300'
                              : 'bg-indigo-50 text-indigo-700 border-indigo-200'
                          }`}
                        >
                          {item.priority}
                        </span>
                        <span className="text-[10px] font-bold text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
                          {item.type}
                        </span>
                        <span className="text-[10px] text-slate-400 flex items-center gap-1 font-mono">
                          <Clock className="w-3 h-3" />
                          {item.date}
                        </span>
                        {item.academyId === 'all' && (
                          <span className="text-[9px] font-bold bg-purple-100 text-purple-800 px-1.5 py-0.2 rounded">
                            🌐 Global Notice
                          </span>
                        )}
                      </div>

                      <h4 className="font-extrabold text-sm text-slate-900 pt-0.5">
                        {item.title}
                      </h4>
                      <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                        {item.message}
                      </p>

                      <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-100 mt-2">
                        <div className="flex items-center gap-2 truncate">
                          <span>
                            Posted by: <b>{item.postedBy || 'Administration'}</b>
                          </span>
                          {item.postedByRole && (
                            <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-slate-100 font-bold">
                              {item.postedByRole}
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-indigo-600 font-bold">
                          Audience: {item.audience}
                        </span>
                      </div>
                    </div>

                    {/* Quick Edit/Delete Actions for Teacher/Admin/Developer */}
                    {userCanModify && (
                      <div className="flex items-center gap-1 shrink-0 pt-0.5">
                        <button
                          type="button"
                          onClick={() => handleStartEdit(item)}
                          className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-white rounded-lg cursor-pointer transition"
                          title="Edit Notice"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(item)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-white rounded-lg cursor-pointer transition"
                          title="Delete Notice"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
