import React from 'react';

export default function AuditLogsModule() {
  return (
    <div className="p-4">
      <h2 className="text-xl font-bold">Audit Logs</h2>
      <p>Module is working properly.</p>
    </div>
  );
}
