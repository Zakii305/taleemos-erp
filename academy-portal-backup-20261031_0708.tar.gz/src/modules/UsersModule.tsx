import React, { useState, useEffect, useMemo } from 'react';
import {
  Users,
  Search,
  Filter,
  Printer,
  Download,
  Plus,
  Trash2,
  Edit2,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Building2,
  Phone,
  Mail,
  UserCheck,
  Calendar,
  AlertCircle,
  Lock,
  ArrowRight,
  Shield,
  FileSpreadsheet,
  CheckSquare,
  Square,
  X,
  RefreshCw,
} from 'lucide-react';
import {
  getLocalUsers,
  saveLocalUsers,
  deleteUserAccount,
  updateUserRole,
  updateUserAccount,
  registerUserAccount,
  fetchActiveAcademies,
  fetchPendingUsers,
  setUserApprovalStatus,
  DEV_EMAILS,
} from '../lib/academyService';
import { getCurrentUser, type User } from '../components/auth/AuthSystem';
import { type AppUser, type Academy, type UserRole } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';

interface UsersModuleProps {
  onNavigate?: (path: string) => void;
}

export const UsersModule: React.FC<UsersModuleProps> = ({ onNavigate }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(getCurrentUser());
  const [users, setUsers] = useState<AppUser[]>([]);
  const [academies, setAcademies] = useState<Academy[]>([]);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [academyFilter, setAcademyFilter] = useState<string>('All');

  // Multi-select state
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditUserModalOpen, setIsEditUserModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<AppUser | null>(null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<AppUser | null>(null);
  const [roleChangeUser, setRoleChangeUser] = useState<AppUser | null>(null);
  const [newSelectedRole, setNewSelectedRole] = useState<AppUser['role']>('teacher');
  const [toast, setToast] = useState<string | null>(null);

  // New user form fields
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formRole, setFormRole] = useState<AppUser['role']>('teacher');
  const [formAcademyId, setFormAcademyId] = useState('');
  const [formPassword, setFormPassword] = useState('pass123');

  // Edit user form fields
  const [editName, setEditName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editRole, setEditRole] = useState<AppUser['role']>('teacher');
  const [editStatus, setEditStatus] = useState<AppUser['status']>('approved');
  const [editAcademyId, setEditAcademyId] = useState('');

  const [isRefreshing, setIsRefreshing] = useState(false);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3500);
  };

  const loadAll = async () => {
    const u = getCurrentUser();
    setCurrentUser(u);
    const isDeveloper = Boolean(
      u?.role === 'developer' ||
      (u?.email && DEV_EMAILS.includes(u.email.toLowerCase()))
    );

    // 1. Fetch live pending users from Firestore (executes query(collection(db, "users"), where("status", "==", "pending")))
    try {
      await fetchPendingUsers(u?.academyId, isDeveloper);
    } catch (err) {
      console.warn("Notice: Firestore pending users query:", err);
    }

    const [userList, acadList] = await Promise.all([
      Promise.resolve(getLocalUsers()),
      fetchActiveAcademies(),
    ]);
    setUsers(userList);
    setAcademies(acadList);
    if (acadList.length > 0 && !formAcademyId) {
      setFormAcademyId(acadList[0].academyId);
    }
  };

  const handleManualFirestoreRefresh = async () => {
    setIsRefreshing(true);
    const u = getCurrentUser();
    const isDeveloper = Boolean(
      u?.role === 'developer' ||
      (u?.email && DEV_EMAILS.includes(u.email.toLowerCase()))
    );
    const fetched = await fetchPendingUsers(u?.academyId, isDeveloper);
    const userList = getLocalUsers();
    setUsers(userList);
    setIsRefreshing(false);
    showToast(`✓ Firestore synced! Found ${fetched?.length || 0} pending registration(s).`);
  };

  const handleApproveUser = async (target: AppUser) => {
    await setUserApprovalStatus(target.uid || target.id || '', 'approved');
    showToast(`✓ Account for ${target.name} (${target.role.toUpperCase()}) approved successfully!`);
    loadAll();
  };

  const handleRejectUser = async (target: AppUser) => {
    await setUserApprovalStatus(target.uid || target.id || '', 'rejected');
    showToast(`✕ Account for ${target.name} rejected.`);
    loadAll();
  };

  useEffect(() => {
    loadAll();
    const handleStorage = () => loadAll();
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const isDev =
    currentUser?.role === 'developer' ||
    (currentUser?.email && DEV_EMAILS.includes(currentUser.email.toLowerCase()));
  const isAdmin = currentUser?.role === 'admin';
  const userAcadId = currentUser?.academyId;

  // Filter users based on role scoping:
  // - Developer sees ALL users across all academies.
  // - Admin only sees users belonging to THEIR OWN ACADEMY (plus themselves).
  const visibleUsers = useMemo(() => {
    let list = users;
    if (!isDev && isAdmin && userAcadId) {
      list = users.filter((u) => u.academyId === userAcadId || u.uid === currentUser?.uid);
    }
    return list.filter((u) => {
      const matchSearch =
        u.name.toLowerCase().includes(search.toLowerCase()) ||
        u.email.toLowerCase().includes(search.toLowerCase()) ||
        (u.phone && u.phone.includes(search)) ||
        (u.academyName && u.academyName.toLowerCase().includes(search.toLowerCase())) ||
        (u.uid && u.uid.toLowerCase().includes(search.toLowerCase()));

      const matchRole = roleFilter === 'All' || u.role === roleFilter;
      const matchStatus = statusFilter === 'All' || u.status === statusFilter;
      const matchAcademy = academyFilter === 'All' || u.academyId === academyFilter;

      return matchSearch && matchRole && matchStatus && matchAcademy;
    });
  }, [users, isDev, isAdmin, userAcadId, currentUser, search, roleFilter, statusFilter, academyFilter]);

  // Scoped Pending Users for cards & table queue
  const pendingUsers = useMemo(() => {
    let list = users.filter((u) => u.status === 'pending');
    if (!isDev && isAdmin && userAcadId) {
      list = list.filter(
        (u) =>
          u.academyId === userAcadId &&
          u.role !== 'admin' &&
          u.role !== 'developer'
      );
    }
    return list;
  }, [users, isDev, isAdmin, userAcadId]);

  // KPIs
  const totalCount = visibleUsers.length;
  const adminCount = users.filter((u) => u.role === 'admin').length;
  const teacherCount = visibleUsers.filter((u) => u.role === 'teacher').length;
  const studentCount = visibleUsers.filter((u) => u.role === 'student').length;
  const pendingCount = pendingUsers.length;

  const toggleUserSelect = (uid: string) => {
    setSelectedUserIds((prev) =>
      prev.includes(uid) ? prev.filter((id) => id !== uid) : [...prev, uid]
    );
  };

  const toggleUserSelectAll = () => {
    if (selectedUserIds.length === visibleUsers.length && visibleUsers.length > 0) {
      setSelectedUserIds([]);
    } else {
      setSelectedUserIds(visibleUsers.map((u) => u.uid || u.id || ''));
    }
  };

  // Format timestamp to date & time
  const formatJoinedDateTime = (ts: number | string | undefined) => {
    if (!ts) return 'Earlier Session';
    const num = typeof ts === 'string' ? parseInt(ts, 10) : ts;
    if (isNaN(num)) return String(ts);
    const d = new Date(num);
    return `${d.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    })} at ${d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`;
  };

  const formatRelativeTime = (ts: number | string | undefined) => {
    if (!ts) return '';
    const num = typeof ts === 'string' ? parseInt(ts, 10) : ts;
    if (isNaN(num)) return '';
    const diff = Date.now() - num;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    if (days === 0) return 'Joined today';
    if (days === 1) return 'Joined yesterday';
    if (days < 30) return `Joined ${days} days ago`;
    const months = Math.floor(days / 30);
    return `Joined ${months} month${months > 1 ? 's' : ''} ago`;
  };

  // Handle Edit User
  const handleOpenEditUser = (u: AppUser) => {
    setEditingUser(u);
    setEditName(u.name);
    setEditPhone(u.phone || '');
    setEditRole(u.role);
    setEditStatus(u.status);
    setEditAcademyId(u.academyId || academies[0]?.academyId || '');
    setIsEditUserModalOpen(true);
  };

  const handleSaveEditUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    const chosenAcad = academies.find((a) => a.academyId === editAcademyId);

    await updateUserAccount(editingUser.uid || editingUser.id || '', {
      name: editName.trim(),
      phone: editPhone.trim(),
      role: editRole,
      status: editStatus,
      academyId: editRole === 'developer' ? null : editAcademyId,
      academyName: editRole === 'developer' ? 'All Academies Network' : (chosenAcad?.academyName || editingUser.academyName),
    });

    setIsEditUserModalOpen(false);
    setEditingUser(null);
    showToast(`Updated user profile: ${editName}`);
    loadAll();
  };

  // Handle Create User
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formEmail.trim()) return;

    const targetAcad = academies.find((a) => a.academyId === formAcademyId);
    const newUser = await registerUserAccount({
      uid: `usr-${Date.now()}`,
      email: formEmail.trim().toLowerCase(),
      name: formName.trim(),
      phone: formPhone.trim(),
      role: formRole as UserRole,
      academyId: formRole === 'developer' ? null : formAcademyId,
      academyName: formRole === 'developer' ? 'All Academies Network' : (targetAcad?.academyName || 'Taleem Academy'),
      password: formPassword,
    });

    setIsAddModalOpen(false);
    setFormName('');
    setFormEmail('');
    setFormPhone('');
    showToast(`Successfully registered new user: ${newUser.name} (${newUser.role})`);
    loadAll();
  };

  // Confirm and Execute User Deletion
  const handleConfirmDelete = async () => {
    if (!userToDelete || !currentUser) return;
    const res = await deleteUserAccount(
      userToDelete.uid || userToDelete.id || '',
      userToDelete,
      currentUser
    );

    if (res.success) {
      showToast(`User ${userToDelete.name} (${userToDelete.role}) permanently removed.`);
      setUserToDelete(null);
      loadAll();
    } else {
      alert(res.error || 'Failed to delete user.');
    }
  };

  // Role Badge Styling
  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'developer':
        return {
          label: 'Super Developer',
          badge: 'bg-purple-100 text-purple-800 border-purple-200',
          dot: 'bg-purple-500',
        };
      case 'admin':
        return {
          label: 'Academy Admin',
          badge: 'bg-blue-100 text-blue-800 border-blue-200',
          dot: 'bg-blue-500',
        };
      case 'teacher':
        return {
          label: 'Teacher / Faculty',
          badge: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          dot: 'bg-emerald-500',
        };
      case 'student':
        return {
          label: 'Enrolled Student',
          badge: 'bg-cyan-100 text-cyan-800 border-cyan-200',
          dot: 'bg-cyan-500',
        };
      case 'parent':
        return {
          label: 'Parent Guardian',
          badge: 'bg-amber-100 text-amber-800 border-amber-200',
          dot: 'bg-amber-500',
        };
      default:
        return {
          label: role,
          badge: 'bg-slate-100 text-slate-800 border-slate-200',
          dot: 'bg-slate-500',
        };
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 text-xs font-bold animate-fade-in">
          <span>{toast}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 md:p-8 text-white shadow-xl border border-indigo-900/40 relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center gap-1">
                <Users className="w-3.5 h-3.5" />
                Stakeholders Roster & RBAC
              </span>
              <span className="text-xs text-slate-400">
                {isDev ? 'Global Multi-Academy Scope' : (currentUser?.academyName || 'My Academy')}
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Institutional Users & Access Directory
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Complete stakeholder directory with full joined timestamps, contact details, and role permissions.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setIsPrintModalOpen(true)}
              className="px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-bold flex items-center gap-2 border border-white/10 transition shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4 text-indigo-300" />
              <span>Print A4 Users List</span>
            </button>
            <button
              onClick={() =>
                downloadElementAsPdf('users-printable-roster', 'TaleemOS_All_Users_Directory')
              }
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 border border-slate-700 transition shadow-sm cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-300" />
              <span>Download PDF</span>
            </button>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center gap-2 shadow-lg shadow-indigo-950/40 transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Register User</span>
            </button>
          </div>
        </div>

        {/* Counter Pills */}
        <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Total Users</span>
            <span className="text-2xl font-black text-indigo-300 font-mono mt-0.5 block">{totalCount}</span>
          </div>
          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Academy Admins</span>
            <span className="text-2xl font-black text-blue-300 font-mono mt-0.5 block">{adminCount}</span>
          </div>
          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Teachers</span>
            <span className="text-2xl font-black text-emerald-300 font-mono mt-0.5 block">{teacherCount}</span>
          </div>
          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Students</span>
            <span className="text-2xl font-black text-cyan-300 font-mono mt-0.5 block">{studentCount}</span>
          </div>
          <button
            type="button"
            onClick={() => setStatusFilter(statusFilter === 'pending' ? 'All' : 'pending')}
            className={`p-3 rounded-2xl border transition text-left cursor-pointer ${
              statusFilter === 'pending'
                ? 'bg-amber-500 text-white border-amber-400 shadow-md shadow-amber-900/30'
                : 'bg-amber-500/15 text-amber-200 border-amber-500/30 hover:bg-amber-500/25'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase block opacity-80">Pending Queue</span>
              {pendingCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              )}
            </div>
            <span className="text-2xl font-black font-mono mt-0.5 block">{pendingCount}</span>
          </button>
        </div>
      </div>

      {/* Search, Filters, and Checkbox Multi-Select Bar */}
      <div className="bg-white rounded-2xl border p-4 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name, email, phone, UID, or academy..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
            <button
              type="button"
              onClick={handleManualFirestoreRefresh}
              disabled={isRefreshing}
              title="Sync pending users directly from Firestore"
              className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isRefreshing ? 'Syncing...' : 'Sync Firestore'}</span>
            </button>

            <button
              type="button"
              onClick={toggleUserSelectAll}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-2 cursor-pointer transition shrink-0"
            >
              {selectedUserIds.length === visibleUsers.length && visibleUsers.length > 0 ? (
                <CheckSquare className="w-4 h-4 text-indigo-600" />
              ) : (
                <Square className="w-4 h-4 text-slate-400" />
              )}
              <span>
                {selectedUserIds.length === visibleUsers.length && visibleUsers.length > 0
                  ? 'Deselect All'
                  : `Select All (${visibleUsers.length})`}
              </span>
            </button>
          </div>
        </div>

        {/* Filter Pills */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
              Role:
            </span>
            {['All', 'developer', 'admin', 'teacher', 'student', 'parent'].map((r) => {
              const isSelected = roleFilter === r;
              return (
                <button
                  key={r}
                  onClick={() => setRoleFilter(r)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition capitalize cursor-pointer ${
                    isSelected
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {r === 'All' ? 'All Roles' : r}
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
              Status:
            </span>
            {['All', 'approved', 'pending', 'rejected'].map((st) => {
              const isSelected = statusFilter === st;
              return (
                <button
                  key={st}
                  onClick={() => setStatusFilter(st)}
                  className={`px-2.5 py-1 rounded-full text-[11px] font-bold transition capitalize cursor-pointer flex items-center gap-1 ${
                    isSelected
                      ? st === 'pending'
                        ? 'bg-amber-600 text-white shadow-sm'
                        : 'bg-slate-900 text-white shadow-sm'
                      : st === 'pending' && pendingCount > 0
                      ? 'bg-amber-100 text-amber-800 border border-amber-300 font-extrabold hover:bg-amber-200'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <span>{st === 'All' ? 'All Status' : st}</span>
                  {st === 'pending' && pendingCount > 0 && (
                    <span className="px-1.5 py-0.2 text-[9px] bg-amber-500 text-white rounded-full font-mono">
                      {pendingCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Pending Users Approval Cards Queue (UI Cards Grid) */}
      {pendingUsers.length > 0 && (
        <div className="bg-gradient-to-br from-amber-50 to-orange-50 border-2 border-amber-300 rounded-3xl p-5 shadow-sm space-y-4 animate-in fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-200/80 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center font-bold shadow-sm">
                <Clock className="w-4 h-4 animate-spin" style={{ animationDuration: '8s' }} />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-amber-950 flex items-center gap-2">
                  Pending Stakeholder Approvals
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-200 text-amber-900 border border-amber-300">
                    {pendingUsers.length} in Queue
                  </span>
                </h3>
                <p className="text-[11px] text-amber-800">
                  {isDev
                    ? 'Super Developer Authority: Approve or reject institution Admins across all branches.'
                    : `Academy Administrator: Authorize faculty, students, and parents for ${currentUser?.academyName || 'your academy'}.`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-start sm:self-auto">
              <button
                type="button"
                onClick={handleManualFirestoreRefresh}
                disabled={isRefreshing}
                className="px-3 py-1.5 bg-amber-200 hover:bg-amber-300 text-amber-900 rounded-xl text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                <span>Re-query Firestore</span>
              </button>
            </div>
          </div>

          {/* Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {pendingUsers.map((pUser) => (
              <div
                key={pUser.uid || pUser.id}
                className="bg-white rounded-2xl p-4 border border-amber-200/80 shadow-sm hover:shadow-md transition flex flex-col justify-between gap-3"
              >
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 text-white font-bold flex items-center justify-center text-sm shadow-sm shrink-0">
                        {pUser.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="min-w-0">
                        <h4 className="font-extrabold text-slate-900 text-xs leading-tight truncate">
                          {pUser.name}
                        </h4>
                        <span className="text-[10px] text-slate-500 font-mono block truncate">
                          {pUser.email}
                        </span>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-wider bg-amber-100 text-amber-900 border border-amber-300 shrink-0">
                      {pUser.role}
                    </span>
                  </div>

                  <div className="text-[11px] text-slate-600 bg-slate-50 rounded-xl p-2.5 space-y-1 border border-slate-100">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-slate-400 text-[10px]">Academy:</span>
                      <span className="font-semibold text-slate-800 truncate text-right">
                        {pUser.academyName || 'Unassigned'}
                      </span>
                    </div>
                    {pUser.phone && (
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-slate-400 text-[10px]">Phone:</span>
                        <span className="font-mono text-slate-700">{pUser.phone}</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-slate-400 text-[10px]">Applied:</span>
                      <span className="text-[10px] text-slate-500">
                        {formatRelativeTime(pUser.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Action Buttons */}
                <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => handleApproveUser(pUser)}
                    className="flex-1 py-1.5 px-3 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-xl shadow-sm shadow-emerald-700/20 flex items-center justify-center gap-1.5 cursor-pointer transition-all"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Approve</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRejectUser(pUser)}
                    className="py-1.5 px-3 bg-rose-100 hover:bg-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center justify-center gap-1 cursor-pointer transition-colors"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Reject</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setUserToDelete(pUser)}
                    title="Delete registration request"
                    className="p-1.5 bg-slate-100 hover:bg-rose-50 text-slate-500 hover:text-rose-600 rounded-xl cursor-pointer transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Floating Toolbar when users are checked */}
      {selectedUserIds.length > 0 && (
        <div className="p-3.5 bg-gradient-to-r from-indigo-900 to-slate-900 text-white rounded-2xl shadow-lg border border-indigo-500/40 flex flex-wrap items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2 text-xs font-bold">
            <span className="px-2.5 py-1 bg-indigo-500 text-white rounded-lg font-mono">
              {selectedUserIds.length}
            </span>
            <span>Users Selected</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsPrintModalOpen(true)}
              className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print Selected</span>
            </button>
            <button
              type="button"
              onClick={() =>
                downloadElementAsPdf('users-printable-roster', 'Selected_Users_Roster')
              }
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </button>
            <button
              type="button"
              onClick={() => setSelectedUserIds([])}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Users Table Card */}
      <div className="bg-white rounded-3xl border shadow-sm overflow-hidden">
        <div className="p-4 border-b flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-sm text-slate-900">
              Users Roster ({visibleUsers.length} records)
            </h3>
            <span className="text-xs text-slate-400">
              {isDev ? 'Developer Master Authority: Can modify or delete ANY user role' : 'Academy Administrator View'}
            </span>
          </div>
          <button
            onClick={() => setIsPrintModalOpen(true)}
            className="text-xs text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1 cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Full Roster</span>
          </button>
        </div>

        <div className="overflow-x-auto touch-scroll">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-bold border-b">
                <th className="p-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={selectedUserIds.length === visibleUsers.length && visibleUsers.length > 0}
                    onChange={toggleUserSelectAll}
                    className="w-4 h-4 rounded text-indigo-600 cursor-pointer"
                  />
                </th>
                <th className="p-3">User Details</th>
                <th className="p-3">Role</th>
                <th className="p-3">Academy / Campus</th>
                <th className="p-3">Phone</th>
                <th className="p-3">When Joined</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {visibleUsers.map((u) => {
                const roleBadge = getRoleBadge(u.role);
                const isSelected = selectedUserIds.includes(u.uid || u.id || '');
                const canDelete =
                  isDev ||
                  (isAdmin &&
                    u.academyId === userAcadId &&
                    u.role !== 'admin' &&
                    u.role !== 'developer');

                return (
                  <tr
                    key={u.uid || u.id}
                    className={`transition ${isSelected ? 'bg-indigo-50/70' : 'hover:bg-slate-50/60'}`}
                  >
                    {/* Checkbox */}
                    <td className="p-3 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleUserSelect(u.uid || u.id || '')}
                        className="w-4 h-4 rounded text-indigo-600 cursor-pointer"
                      />
                    </td>

                    {/* User Name & Avatar */}
                    <td className="p-3">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-white text-xs shrink-0 ${
                            u.role === 'developer'
                              ? 'bg-purple-600'
                              : u.role === 'admin'
                              ? 'bg-blue-600'
                              : u.role === 'teacher'
                              ? 'bg-emerald-600'
                              : u.role === 'student'
                              ? 'bg-cyan-600'
                              : 'bg-amber-600'
                          }`}
                        >
                          {u.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <p className="font-extrabold text-slate-900 truncate">{u.name}</p>
                          <p className="text-[11px] text-slate-500 font-mono truncate">{u.email}</p>
                        </div>
                      </div>
                    </td>

                    {/* Role Badge */}
                    <td className="p-3 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold border ${roleBadge.badge}`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${roleBadge.dot}`} />
                        <span>{roleBadge.label}</span>
                      </span>
                    </td>

                    {/* Academy Name */}
                    <td className="p-3">
                      <span className="font-medium text-slate-800 line-clamp-1">
                        {u.academyName || 'Global Network'}
                      </span>
                    </td>

                    {/* Phone & Contact */}
                    <td className="p-3 whitespace-nowrap font-mono text-slate-600">
                      {u.phone || 'N/A'}
                    </td>

                    {/* When Joined */}
                    <td className="p-3 whitespace-nowrap">
                      <div>
                        <span className="font-bold text-slate-800 block text-[11px]">
                          {formatJoinedDateTime(u.createdAt)}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          {formatRelativeTime(u.createdAt)}
                        </span>
                      </div>
                    </td>

                    {/* Status */}
                    <td className="p-3 whitespace-nowrap">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          u.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                            : u.status === 'pending'
                            ? 'bg-amber-100 text-amber-800 border border-amber-200 animate-pulse'
                            : 'bg-rose-100 text-rose-800 border border-rose-200'
                        }`}
                      >
                        {u.status}
                      </span>
                    </td>

                    {/* Actions: Edit / Modify next to Delete */}
                    <td className="p-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        {/* Quick Approve / Reject for Pending Users in HTML Table */}
                        {u.status === 'pending' && (
                          <>
                            <button
                              type="button"
                              onClick={() => handleApproveUser(u)}
                              title="Approve this user account"
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition shadow-sm"
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Approve</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => handleRejectUser(u)}
                              title="Reject this user account"
                              className="px-2 py-1 bg-rose-100 hover:bg-rose-200 text-rose-700 rounded-lg text-[10px] font-bold flex items-center gap-1 cursor-pointer transition"
                            >
                              <XCircle className="w-3 h-3" />
                              <span>Reject</span>
                            </button>
                          </>
                        )}

                        {/* Edit / Modify User */}
                        <button
                          onClick={() => handleOpenEditUser(u)}
                          title="Edit / Modify User Details"
                          className="p-1.5 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-lg transition cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete User */}
                        {canDelete ? (
                          <button
                            onClick={() => setUserToDelete(u)}
                            title={isDev ? 'Developer: Delete this role/user' : 'Delete user'}
                            className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        ) : (
                          <span className="text-[10px] text-slate-400 italic">Protected</span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {visibleUsers.length === 0 && (
          <div className="py-12 text-center text-slate-400">
            <Users className="w-10 h-10 mx-auto text-slate-300 mb-2" />
            <p className="font-bold text-sm text-slate-600">No users found matching your filters</p>
          </div>
        )}
      </div>

      {/* EDIT USER MODAL */}
      {editingUser && (
        <Modal
          isOpen={isEditUserModalOpen}
          onClose={() => {
            setIsEditUserModalOpen(false);
            setEditingUser(null);
          }}
          title={`Edit / Modify User: ${editingUser.name}`}
          subtitle={`UID: ${editingUser.uid || editingUser.id} • ${editingUser.email}`}
          badge="MODIFY USER"
        >
          <form onSubmit={handleSaveEditUser} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 uppercase mb-1">Full Name *</label>
              <input
                type="text"
                required
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-bold outline-none focus:border-indigo-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">Phone</label>
                <input
                  type="text"
                  value={editPhone}
                  onChange={(e) => setEditPhone(e.target.value)}
                  placeholder="0300-1234567"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">User Status</label>
                <select
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as AppUser['status'])}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-bold outline-none"
                >
                  <option value="approved">Approved</option>
                  <option value="pending">Pending Approval</option>
                  <option value="rejected">Rejected</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">Role *</label>
                <select
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value as AppUser['role'])}
                  disabled={!isDev && editingUser.role === 'admin'}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-bold outline-none"
                >
                  {isDev && <option value="developer">👑 Developer</option>}
                  <option value="admin">🛡️ Academy Admin</option>
                  <option value="teacher">👨‍🏫 Teacher</option>
                  <option value="student">🎓 Student</option>
                  <option value="parent">👨‍👩‍👧 Parent</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">Academy Allocation</label>
                <select
                  value={editAcademyId}
                  onChange={(e) => setEditAcademyId(e.target.value)}
                  disabled={!isDev}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-bold outline-none truncate"
                >
                  {academies.map((a) => (
                    <option key={a.academyId} value={a.academyId}>
                      {a.academyName}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="pt-3 flex justify-end gap-2 border-t">
              <button
                type="button"
                onClick={() => {
                  setIsEditUserModalOpen(false);
                  setEditingUser(null);
                }}
                className="px-4 py-2 bg-slate-100 rounded-xl font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black shadow-md"
              >
                Save Changes
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* CREATE NEW USER MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Register New User Account"
        subtitle="Provision account credentials across the institution"
        badge="PROVISION"
      >
        <form onSubmit={handleCreateUser} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Full Name *</label>
            <input
              type="text"
              required
              value={formName}
              onChange={(e) => setFormName(e.target.value)}
              placeholder="e.g. Sir Sajjad Ali Qasmi"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-medium outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Email Address *</label>
              <input
                type="email"
                required
                value={formEmail}
                onChange={(e) => setFormEmail(e.target.value)}
                placeholder="user@taleemacademy.edu.pk"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-medium outline-none"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Phone Number</label>
              <input
                type="tel"
                value={formPhone}
                onChange={(e) => setFormPhone(e.target.value)}
                placeholder="0300-1234567"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-medium outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Assigned Role *</label>
              <select
                value={formRole}
                onChange={(e) => setFormRole(e.target.value as AppUser['role'])}
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-bold outline-none"
              >
                {isDev && <option value="developer">👑 Developer</option>}
                <option value="admin">🛡️ Academy Admin</option>
                <option value="teacher">👨‍🏫 Teacher</option>
                <option value="student">🎓 Student</option>
                <option value="parent">👨‍👩‍👧 Parent</option>
              </select>
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Academy Branch</label>
              <select
                value={formAcademyId}
                onChange={(e) => setFormAcademyId(e.target.value)}
                disabled={!isDev}
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-bold outline-none truncate"
              >
                {academies.map((a) => (
                  <option key={a.academyId} value={a.academyId}>
                    {a.academyName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Initial Password *</label>
            <input
              type="text"
              required
              value={formPassword}
              onChange={(e) => setFormPassword(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-mono text-slate-800 outline-none"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black shadow-md transition cursor-pointer"
            >
              Confirm Registration
            </button>
          </div>
        </form>
      </Modal>

      {/* DELETE CONFIRMATION MODAL */}
      {userToDelete && (
        <Modal
          isOpen={Boolean(userToDelete)}
          onClose={() => setUserToDelete(null)}
          title="Confirm Permanent Deletion"
        >
          <div className="space-y-4 text-xs">
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-extrabold text-rose-900 text-sm">
                  Are you sure you want to delete {userToDelete.name}?
                </p>
                <p className="text-rose-700 mt-1">
                  Role: <b>{userToDelete.role.toUpperCase()}</b> • Email: <b>{userToDelete.email}</b>
                </p>
                <p className="text-rose-600 mt-1">
                  This user account will be permanently erased from Firestore and local storage.
                </p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                onClick={() => setUserToDelete(null)}
                className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black shadow-md cursor-pointer"
              >
                Yes, Delete User Account
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Official Printable Users Directory Modal (A4) */}
      <Modal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
        title="Official Users & Roles Directory (A4 Printable)"
        maxWidth="max-w-5xl"
      >
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-3 border-b no-print">
            <p className="text-xs text-slate-500">
              Formatted for official letterhead printing and administrative record keeping.
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => triggerBrowserPrint()}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Print A4 List</span>
              </button>
              <button
                type="button"
                onClick={() => downloadElementAsPdf('users-printable-roster', 'TaleemOS_Users_Directory')}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Download PDF</span>
              </button>
            </div>
          </div>

          <div id="users-printable-roster">
            <LetterheadPrint
              title="INSTITUTIONAL USER ACCOUNTS & ROLES DIRECTORY"
              subtitle={`Complete stakeholder roster with registration dates & permissions • Generated: ${new Date().toLocaleDateString()}`}
              documentNo="USR-LEDGER-2026"
              summaryStats={[
                { label: 'Total Users', value: totalCount },
                { label: 'Admins', value: adminCount },
                { label: 'Teachers', value: teacherCount },
                { label: 'Students', value: studentCount },
              ]}
              signatures={[
                'IT / System Admin',
                'Director of Human Resources',
                'Principal / Executive Seal',
              ]}
            >
              <div className="space-y-4 text-xs text-slate-800">
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead className="bg-slate-100">
                    <tr>
                      <th className="border border-slate-300 p-2 font-black w-8">#</th>
                      <th className="border border-slate-300 p-2 font-black">Full Name</th>
                      <th className="border border-slate-300 p-2 font-black">Email</th>
                      <th className="border border-slate-300 p-2 font-black">Phone</th>
                      <th className="border border-slate-300 p-2 font-black">Role</th>
                      <th className="border border-slate-300 p-2 font-black">Academy Campus</th>
                      <th className="border border-slate-300 p-2 font-black">When Joined</th>
                      <th className="border border-slate-300 p-2 font-black">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(selectedUserIds.length > 0
                      ? visibleUsers.filter((u) => selectedUserIds.includes(u.uid || u.id || ''))
                      : visibleUsers
                    ).map((u, idx) => (
                      <tr key={u.uid || u.id} className="border-b border-slate-200 hover:bg-slate-50">
                        <td className="border border-slate-300 p-2 font-mono text-center">{idx + 1}</td>
                        <td className="border border-slate-300 p-2 font-bold">{u.name}</td>
                        <td className="border border-slate-300 p-2 font-mono">{u.email}</td>
                        <td className="border border-slate-300 p-2 font-mono">{u.phone || '-'}</td>
                        <td className="border border-slate-300 p-2 font-bold uppercase">{u.role}</td>
                        <td className="border border-slate-300 p-2">{u.academyName || 'Global'}</td>
                        <td className="border border-slate-300 p-2 font-mono whitespace-nowrap">
                          {formatJoinedDateTime(u.createdAt)}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold uppercase">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] ${
                              u.status === 'approved'
                                ? 'bg-emerald-100 text-emerald-800'
                                : u.status === 'pending'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {u.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </LetterheadPrint>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default UsersModule;
