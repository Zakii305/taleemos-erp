import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Building2,
  Users,
  CheckCircle2,
  XCircle,
  Plus,
  Search,
  ArrowRight,
  TrendingUp,
  MapPin,
  Phone,
  Mail,
  UserCheck,
  Clock,
  ExternalLink,
  RefreshCw,
  Trash2,
  Edit3,
  KeyRound,
  Sparkles,
  Copy,
  Shuffle,
  Ban,
  Lock,
  Eye,
  EyeOff,
  Check,
} from 'lucide-react';
import { erpStorage } from '../lib/storage';
import {
  fetchActiveAcademies,
  createAcademy,
  updateAcademy,
  deleteAcademy,
  getPendingAdmins,
  setUserApprovalStatus,
  getLocalUsers,
  deleteUserAccount,
} from '../lib/academyService';
import {
  getDemoAccountsConfig,
  toggleDemoVisibility,
  resetRandomDemoCredentials,
  revokeDemoCredentials,
  restoreDemoCredentials,
  updateCustomDemoCredentials,
  type DemoRole,
  type DemoAccountsConfig,
} from '../lib/demoAccountService';
import { type Academy, type AppUser } from '../types';
import { Modal } from '../components/common/Modal';

interface DeveloperModuleProps {
  onNavigate?: (path: string) => void;
  onSelectAcademy?: (academyId: string) => void;
}

export const DeveloperModule: React.FC<DeveloperModuleProps> = ({
  onNavigate,
  onSelectAcademy,
}) => {
  const [academies, setAcademies] = useState<Academy[]>([]);
  const [pendingAdmins, setPendingAdmins] = useState<AppUser[]>([]);
  const [allUsers, setAllUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'academies' | 'pending' | 'users' | 'demo'>('academies');
  const [search, setSearch] = useState('');

  const [demoConfig, setDemoConfig] = useState<DemoAccountsConfig>(getDemoAccountsConfig);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [customEditRole, setCustomEditRole] = useState<DemoRole | null>(null);
  const [customLoginInput, setCustomLoginInput] = useState('');
  const [customPasswordInput, setCustomPasswordInput] = useState('');

  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newAcademyName, setNewAcademyName] = useState('');
  const [newAcademyCode, setNewAcademyCode] = useState('');
  const [newAcademyAddress, setNewAcademyAddress] = useState('');
  const [newAcademyPhone, setNewAcademyPhone] = useState('');
  const [assignedAdminEmail, setAssignedAdminEmail] = useState('');

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingAcademy, setEditingAcademy] = useState<Academy | null>(null);
  const [editName, setEditName] = useState('');
  const [editCode, setEditCode] = useState('');
  const [editAddress, setEditAddress] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editAdminEmail, setEditAdminEmail] = useState('');
  const [editAdminName, setEditAdminName] = useState('');
  const [editIsActive, setEditIsActive] = useState(true);

  const [deletingAcademy, setDeletingAcademy] = useState<Academy | null>(null);
  const [deletingUser, setDeletingUser] = useState<AppUser | null>(null);

  const [toast, setToast] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    try {
      const [acadList, adminsList] = await Promise.all([
        fetchActiveAcademies(),
        getPendingAdmins(),
      ]);
      setAcademies(acadList);
      setPendingAdmins(adminsList);
      setAllUsers(getLocalUsers());
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleCreateAcademy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAcademyName.trim() || !newAcademyCode.trim()) return;

    const newAcad = await createAcademy(
      {
        academyId: `acad-${Date.now().toString().slice(-4)}`,
        academyName: newAcademyName.trim(),
        code: newAcademyCode.trim().toUpperCase(),
        address: newAcademyAddress.trim() || 'Sindh, Pakistan',
        phone: newAcademyPhone.trim() || '0300-0000000',
        adminEmail: assignedAdminEmail.trim() || undefined,
        createdBy: 'developer@hisaabkitaab.com',
      },
      'developer@hisaabkitaab.com'
    );

    setIsCreateModalOpen(false);
    setNewAcademyName('');
    setNewAcademyCode('');
    setNewAcademyAddress('');
    setNewAcademyPhone('');
    setAssignedAdminEmail('');
    showToast(`✅ Created new Academy: ${newAcad.academyName} (${newAcad.code})`);
    loadData();
  };

  const handleApproveAdmin = async (adminUser: AppUser, allottedAcadId?: string) => {
    const targetAcademy = allottedAcadId || adminUser.academyId || academies[0]?.academyId;
    await setUserApprovalStatus(adminUser.uid, 'approved', targetAcademy || undefined);
    showToast(`🎉 Approved Admin: ${adminUser.name} (${adminUser.email})`);
    loadData();
  };

  const handleRejectAdmin = async (adminUser: AppUser) => {
    await setUserApprovalStatus(adminUser.uid, 'rejected');
    showToast(`❌ Rejected Admin registration: ${adminUser.email}`);
    loadData();
  };

  const handleOpenEdit = (acad: Academy) => {
    setEditingAcademy(acad);
    setEditName(acad.academyName || '');
    setEditCode(acad.code || '');
    setEditAddress(acad.address || '');
    setEditPhone(acad.phone || '');
    setEditAdminEmail(acad.adminEmail || '');
    setEditAdminName(acad.adminName || '');
    setEditIsActive(acad.isActive ?? true);
    setIsEditModalOpen(true);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAcademy || !editName.trim() || !editCode.trim()) return;

    const res = await updateAcademy(editingAcademy.academyId, {
      academyName: editName.trim(),
      code: editCode.trim().toUpperCase(),
      address: editAddress.trim(),
      phone: editPhone.trim(),
      adminEmail: editAdminEmail.trim() || undefined,
      adminName: editAdminName.trim() || undefined,
      isActive: editIsActive,
    });

    if (res.success) {
      showToast(`✏️ Updated "${editName.trim()}" successfully!`);
      setIsEditModalOpen(false);
      setEditingAcademy(null);
      loadData();
    } else {
      showToast(`❌ Failed to update: ${res.error || 'Unknown error'}`);
    }
  };

  const handleDeleteAcademy = (acad: Academy) => {
    setDeletingAcademy(acad);
  };

  const confirmDeleteAcademy = async () => {
    if (!deletingAcademy) return;
    const target = deletingAcademy;
    setDeletingAcademy(null);

    const res = await deleteAcademy(target.academyId);
    if (res.success) {
      showToast(`🗑️ Successfully deleted academy: ${target.academyName}`);
      loadData();
    } else {
      showToast(`❌ Error: ${res.error || 'Failed to delete'}`);
    }
  };

  const confirmDeleteUser = async () => {
    if (!deletingUser) return;
    const target = deletingUser;
    setDeletingUser(null);

    const currentUser = {
      uid: 'dev-master',
      email: 'developer@hisaabkitaab.com',
      name: 'Developer',
      role: 'developer' as const,
      academyId: null,
      academyName: 'All',
      status: 'approved' as const,
      createdAt: Date.now(),
    };
    const res = await deleteUserAccount(target.uid, target, currentUser);
    if (res.success) {
      showToast(`🗑️ Deleted user: ${target.name} (${target.role})`);
      loadData();
    } else {
      showToast(`❌ Error: ${res.error || 'Failed to delete user'}`);
    }
  };

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    showToast(`Copied to clipboard: ${text}`);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleToggleDemoVisibility = () => {
    const nextState = !demoConfig.isEnabled;
    const updated = toggleDemoVisibility(nextState);
    setDemoConfig({ ...updated });
    showToast(
      nextState
        ? '👁️ Demo Accounts are now VISIBLE on Login page'
        : '🙈 Demo Accounts are now HIDDEN from Login page'
    );
  };

  const handleResetAllRandom = () => {
    const updated = resetRandomDemoCredentials();
    setDemoConfig({ ...updated });
    showToast('🎲 Random logins & passwords generated for all 4 Demo Accounts!');
  };

  const handleResetSingleRole = (role: DemoRole) => {
    const updated = resetRandomDemoCredentials(role);
    setDemoConfig({ ...updated });
    showToast(`🎲 Random login & password generated for ${demoConfig.accounts[role].roleTitle}!`);
  };

  const handleRevokeSingleRole = (role: DemoRole) => {
    const isCurrentlyRevoked = demoConfig.accounts[role].isRevoked;
    if (isCurrentlyRevoked) {
      const updated = restoreDemoCredentials(role);
      setDemoConfig({ ...updated });
      showToast(`✅ Restored demo access for ${demoConfig.accounts[role].roleTitle}`);
    } else {
      const updated = revokeDemoCredentials(role);
      setDemoConfig({ ...updated });
      showToast(`⛔ Revoked/Expired demo credentials for ${demoConfig.accounts[role].roleTitle}`);
    }
  };

  const handleRevokeAll = () => {
    const updated = revokeDemoCredentials();
    setDemoConfig({ ...updated });
    showToast('⛔ All 4 Demo Accounts have been REVOKED and EXPIRED immediately!');
  };

  const handleRestoreAll = () => {
    const updated = restoreDemoCredentials();
    setDemoConfig({ ...updated });
    showToast('✅ All 4 Demo Accounts RESTORED to Active state!');
  };

  const handleOpenCustomEdit = (role: DemoRole) => {
    const creds = demoConfig.accounts[role];
    setCustomEditRole(role);
    setCustomLoginInput(creds.loginId);
    setCustomPasswordInput(creds.password);
  };

  const handleSaveCustomCredentials = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customEditRole || !customLoginInput.trim() || !customPasswordInput.trim()) return;
    const updated = updateCustomDemoCredentials(
      customEditRole,
      customLoginInput.trim(),
      customPasswordInput.trim()
    );
    setDemoConfig({ ...updated });
    showToast(`✏️ Updated credentials for ${demoConfig.accounts[customEditRole].roleTitle}`);
    setCustomEditRole(null);
  };

  const state = erpStorage.getState();

  const filteredAcademies = academies.filter(
    (a) =>
      a.academyName.toLowerCase().includes(search.toLowerCase()) ||
      a.code.toLowerCase().includes(search.toLowerCase()) ||
      a.address.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Toast */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 text-xs font-bold animate-fade-in">
          <span>{toast}</span>
        </div>
      )}

      {/* Developer Master Header */}
      <div className="rounded-3xl bg-gradient-to-r from-slate-950 via-indigo-950 to-slate-950 p-6 md:p-8 text-white shadow-xl border border-indigo-900/50 relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-radial from-indigo-500/10 to-transparent pointer-events-none" />
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Super Super Admin • Developer Authority
              </span>
              <span className="text-xs text-slate-400">developer@hisaabkitaab.com</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight">
              Developer Central Control & Multi-Academy Hub
            </h1>
            <p className="text-xs text-slate-300 mt-1 max-w-xl">
              Create and allot academies, review & approve new academy administrators, and monitor global multi-tenant institutional operations.
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center gap-2 shadow-lg shadow-indigo-950/40 transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create / Allot New Academy</span>
            </button>
            <button
              onClick={loadData}
              title="Refresh Network Data"
              className="w-10 h-10 bg-white/10 hover:bg-white/20 text-white rounded-xl flex items-center justify-center transition border border-white/10 cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Global Network Counters */}
        <div className="mt-6 pt-5 border-t border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Total Academies</span>
            <span className="text-2xl font-black text-indigo-300 font-mono mt-1 block">
              {academies.length} Branches
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Pending Admin Approvals</span>
            <span className={`text-2xl font-black font-mono mt-1 block ${pendingAdmins.length > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {pendingAdmins.length} Requests
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Network Students</span>
            <span className="text-2xl font-black text-emerald-300 font-mono mt-1 block">
              {state.students.length.toLocaleString()}
            </span>
          </div>

          <div className="p-3 bg-white/5 rounded-2xl border border-white/10">
            <span className="text-[10px] font-bold uppercase text-slate-400 block">Network ERP Modules</span>
            <span className="text-2xl font-black text-sky-300 font-mono mt-1 block">
              29 Modules
            </span>
          </div>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="bg-white rounded-2xl border p-4 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex bg-slate-100 p-1 rounded-xl text-xs font-bold w-fit">
          <button
            onClick={() => setActiveTab('academies')}
            className={`px-4 py-2 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'academies' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>All Academies ({academies.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('pending')}
            className={`px-4 py-2 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'pending' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Pending Admins</span>
            {pendingAdmins.length > 0 && (
              <span className="px-1.5 py-0.2 bg-amber-500 text-white rounded-full text-[10px]">
                {pendingAdmins.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('users')}
            className={`px-4 py-2 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'users' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Registered Users</span>
          </button>
          <button
            onClick={() => setActiveTab('demo')}
            className={`px-4 py-2 rounded-lg transition cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'demo' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-900'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5 text-amber-500" />
            <span>Demo Accounts Sandbox</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[9px] font-mono font-bold ${
                demoConfig.isEnabled ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
              }`}
            >
              {demoConfig.isEnabled ? 'Visible' : 'Hidden'}
            </span>
          </button>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search academy or code..."
            className="pl-8 pr-3 py-1.5 bg-slate-50 border rounded-xl text-xs outline-none focus:border-indigo-500 w-full sm:w-56"
          />
        </div>
      </div>

      {/* Tab 1: All Academies List */}
      {activeTab === 'academies' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredAcademies.map((acad) => (
            <div
              key={acad.academyId}
              className="bg-white rounded-3xl border p-5 shadow-sm hover:shadow-md transition flex flex-col justify-between group border-slate-200"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="font-mono text-xs font-black bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-lg border border-indigo-100">
                    {acad.code}
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    Active Branch
                  </span>
                </div>

                <h3 className="font-black text-base text-slate-900 group-hover:text-indigo-600 transition">
                  {acad.academyName}
                </h3>

                <div className="mt-3 space-y-1.5 text-xs text-slate-500">
                  <p className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{acad.address}</span>
                  </p>
                  <p className="flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{acad.phone}</span>
                  </p>
                  {acad.adminEmail && (
                    <p className="flex items-center gap-1.5">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-medium text-slate-700">{acad.adminEmail}</span>
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <span className="text-[10px] text-slate-400 font-mono">ID: {acad.academyId}</span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(acad)}
                    title="Edit Academy Details"
                    className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer border border-amber-200/70 active:scale-95"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>Edit</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDeleteAcademy(acad)}
                    title="Delete Academy Permanently"
                    className="px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer border border-rose-200/70 active:scale-95"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      erpStorage.setActiveInstitution(acad.academyId);
                      onSelectAcademy?.(acad.academyId);
                      showToast(`Switched active view to ${acad.academyName}`);
                    }}
                    className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold flex items-center gap-1 transition cursor-pointer border border-indigo-200/70 active:scale-95"
                  >
                    <span>Enter</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Pending Admin Approvals (Developer Role only) */}
      {activeTab === 'pending' && (
        <div className="bg-white rounded-3xl border shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-black text-base text-slate-900">
                Pending Admin Registrations Awaiting Developer Approval
              </h3>
              <p className="text-xs text-slate-500">
                Admins cannot access institution databases or approve teachers until authorized by Developer.
              </p>
            </div>
            <span className="text-xs font-mono font-bold bg-amber-50 text-amber-700 border border-amber-200 px-3 py-1 rounded-full">
              {pendingAdmins.length} Awaiting
            </span>
          </div>

          {pendingAdmins.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto" />
              <p className="font-bold text-sm text-slate-800">All Admin registrations are approved!</p>
              <p className="text-xs text-slate-400">New requests will automatically appear here for verification.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {pendingAdmins.map((admin) => (
                <div
                  key={admin.uid}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-sm text-slate-900">{admin.name}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-50 text-indigo-700">
                        Admin Applicant
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Email: <b>{admin.email}</b> {admin.phone ? `• Phone: ${admin.phone}` : ''}
                    </p>
                    <p className="text-xs text-indigo-600 font-medium mt-1">
                      Target Academy: {admin.academyName || 'New Academy Proposed'}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleRejectAdmin(admin)}
                      className="px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-xl text-xs font-bold border border-rose-200 transition cursor-pointer"
                    >
                      Reject
                    </button>
                    <button
                      onClick={() => handleApproveAdmin(admin)}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-md shadow-emerald-900/30 transition cursor-pointer"
                    >
                      Authorize & Approve Admin
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Registered Users Directory */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-3xl border shadow-sm p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b">
            <div>
              <h3 className="font-black text-base text-slate-900">
                Network User Directory (All Roles)
              </h3>
              <p className="text-xs text-slate-500">
                Developer privileges: You can delete any role or view the full printable directory.
              </p>
            </div>
            <button
              onClick={() => onNavigate?.('users')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow transition cursor-pointer flex items-center gap-1.5"
            >
              <Users className="w-4 h-4" />
              <span>Open Printable Users Section →</span>
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {allUsers.map((u) => (
              <div key={u.uid} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div>
                  <p className="font-extrabold text-slate-900">{u.name}</p>
                  <p className="text-slate-500 text-[11px]">
                    {u.email} &bull; {u.academyName}
                  </p>
                </div>
                <div className="flex items-center gap-2 self-start sm:self-auto">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-100 text-slate-700">
                    {u.role}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      u.status === 'approved'
                        ? 'bg-emerald-100 text-emerald-800'
                        : u.status === 'pending'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {u.status}
                  </span>
                  <button
                    type="button"
                    onClick={() => setDeletingUser(u)}
                    title="Developer: Delete this role/user"
                    className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-lg transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Developer Demo Accounts & Sandbox Authority */}
      {activeTab === 'demo' && (
        <div className="space-y-6">
          {/* Master Control Banner */}
          <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 border border-indigo-800/40 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-5">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  Sandbox Access Governance
                </span>
                <span
                  className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded-full ${
                    demoConfig.isEnabled
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {demoConfig.isEnabled ? 'Login Page: VISIBLE' : 'Login Page: HIDDEN'}
                </span>
              </div>
              <h2 className="text-xl md:text-2xl font-black tracking-tight">
                Demo Accounts Authority & Security Control
              </h2>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
                Configure sandbox access for Admin, Teacher, Student, and Parent. Reset passwords randomly, revoke access to expire logins instantly, or hide the demo section from the public login screen. All demo sessions operate in strict <b>Read-Only Mode</b>.
              </p>
            </div>

            {/* Quick Master Actions */}
            <div className="flex flex-wrap items-center gap-2.5 shrink-0">
              {/* Toggle Hide/Show */}
              <button
                type="button"
                onClick={handleToggleDemoVisibility}
                className={`px-4 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer shadow-md ${
                  demoConfig.isEnabled
                    ? 'bg-rose-600 hover:bg-rose-700 text-white'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
              >
                {demoConfig.isEnabled ? <Ban className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                <span>{demoConfig.isEnabled ? 'Hide Demo from Login' : 'Show Demo on Login'}</span>
              </button>

              {/* Randomize All */}
              <button
                type="button"
                onClick={handleResetAllRandom}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black transition flex items-center gap-2 shadow-lg shadow-indigo-950/40 active:scale-95 cursor-pointer"
              >
                <Shuffle className="w-4 h-4" />
                <span>Randomize All Credentials</span>
              </button>

              {/* Revoke All */}
              <button
                type="button"
                onClick={handleRevokeAll}
                title="Expire all demo credentials immediately"
                className="px-3.5 py-2.5 bg-white/10 hover:bg-rose-600/30 text-rose-300 hover:text-white rounded-xl text-xs font-bold transition border border-rose-500/40 cursor-pointer"
              >
                <span>Revoke All</span>
              </button>

              {/* Restore All */}
              <button
                type="button"
                onClick={handleRestoreAll}
                title="Restore all demo credentials to active"
                className="px-3.5 py-2.5 bg-white/10 hover:bg-emerald-600/30 text-emerald-300 hover:text-white rounded-xl text-xs font-bold transition border border-emerald-500/40 cursor-pointer"
              >
                <span>Restore All</span>
              </button>
            </div>
          </div>

          {/* 4 Demo Roles Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {(['admin', 'teacher', 'student', 'parent'] as DemoRole[]).map((r) => {
              const creds = demoConfig.accounts[r];
              const isRevoked = creds.isRevoked;
              const roleIcons: Record<DemoRole, string> = {
                admin: '🎓',
                teacher: '👨‍🏫',
                student: '👨‍🎓',
                parent: '👨‍👩‍👧',
              };

              return (
                <div
                  key={r}
                  className={`bg-white rounded-3xl border p-5 shadow-sm transition flex flex-col justify-between group ${
                    isRevoked ? 'border-rose-200 bg-rose-50/20' : 'border-slate-200 hover:shadow-md'
                  }`}
                >
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl">{roleIcons[r]}</span>
                        <div>
                          <h3 className="font-black text-sm text-slate-900">{creds.roleTitle}</h3>
                          <p className="text-[11px] text-slate-400 font-medium">{creds.userName}</p>
                        </div>
                      </div>

                      {isRevoked ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-rose-100 text-rose-800 border border-rose-300 flex items-center gap-1">
                          <Ban className="w-3 h-3" />
                          REVOKED / EXPIRED
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          ACTIVE (READ-ONLY)
                        </span>
                      )}
                    </div>

                    {/* Credentials Display */}
                    <div className="mt-4 space-y-3">
                      {/* Login ID */}
                      <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                            Login ID / Username
                          </span>
                          <span className="font-mono font-bold text-xs text-slate-900 select-all">
                            {creds.loginId}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopy(creds.loginId, `${r}-login`)}
                          className="px-2.5 py-1 bg-white hover:bg-slate-100 border rounded-lg text-[11px] font-bold text-slate-600 transition flex items-center gap-1 cursor-pointer"
                        >
                          <Copy className="w-3 h-3" />
                          <span>{copiedKey === `${r}-login` ? 'Copied!' : 'Copy'}</span>
                        </button>
                      </div>

                      {/* Password */}
                      <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">
                            Password
                          </span>
                          <span className="font-mono font-bold text-xs text-indigo-700 select-all">
                            {creds.password}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopy(creds.password, `${r}-pass`)}
                          className="px-2.5 py-1 bg-white hover:bg-slate-100 border rounded-lg text-[11px] font-bold text-indigo-700 transition flex items-center gap-1 cursor-pointer"
                        >
                          <Copy className="w-3 h-3" />
                          <span>{copiedKey === `${r}-pass` ? 'Copied!' : 'Copy'}</span>
                        </button>
                      </div>

                      {/* Reset Timestamp & Read-Only Notice */}
                      <div className="flex items-center justify-between text-[10px] text-slate-400 px-1">
                        <span>Last reset: {new Date(creds.lastResetAt).toLocaleTimeString()}</span>
                        <span className="text-indigo-600 font-semibold">Strict Read-Only Guard</span>
                      </div>
                    </div>
                  </div>

                  {/* Actions Footer */}
                  <div className="mt-5 pt-3.5 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => handleOpenCustomEdit(r)}
                      className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span>Custom Edit</span>
                    </button>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleResetSingleRole(r)}
                        title="Randomly generate a new login ID and strong password"
                        className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer active:scale-95"
                      >
                        <Shuffle className="w-3.5 h-3.5" />
                        <span>Random Reset</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleRevokeSingleRole(r)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer active:scale-95 ${
                          isRevoked
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
                        }`}
                      >
                        {isRevoked ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Reactivate</span>
                          </>
                        ) : (
                          <>
                            <Ban className="w-3.5 h-3.5" />
                            <span>Revoke</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Sandbox Architecture Explainer */}
          <div className="bg-indigo-50/50 border border-indigo-200/80 rounded-3xl p-5 text-xs text-indigo-950 flex flex-col sm:flex-row items-start gap-3.5">
            <span className="text-2xl mt-0.5">🛡️</span>
            <div className="space-y-1">
              <h4 className="font-extrabold text-sm text-indigo-900">
                Developer Read-Only Enforcement Policy
              </h4>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Whenever anyone authenticates using any of the 4 demo accounts above, the user session is flagged as <code>isDemo: true</code> and <code>readOnly: true</code>. All mutations in the ERP storage engine are intercepted and blocked with user notifications. If you click <b>Revoke</b>, any subsequent login attempts are rejected with immediate expiration feedback.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Create / Allot New Academy */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create & Allot New Academy (Developer Only)"
      >
        <form onSubmit={handleCreateAcademy} className="space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">Academy Name *</label>
            <input
              type="text"
              required
              value={newAcademyName}
              onChange={(e) => setNewAcademyName(e.target.value)}
              placeholder="e.g. Taleem Academy Larkana Campus"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Branch Code *</label>
              <input
                type="text"
                required
                value={newAcademyCode}
                onChange={(e) => setNewAcademyCode(e.target.value)}
                placeholder="e.g. TAL-04"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-mono uppercase font-bold"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Official Contact Phone</label>
              <input
                type="text"
                value={newAcademyPhone}
                onChange={(e) => setNewAcademyPhone(e.target.value)}
                placeholder="0300-1234567"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Campus Physical Address</label>
            <input
              type="text"
              value={newAcademyAddress}
              onChange={(e) => setNewAcademyAddress(e.target.value)}
              placeholder="City, District, Province"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Allot to Admin Email (Optional)</label>
            <input
              type="email"
              value={assignedAdminEmail}
              onChange={(e) => setAssignedAdminEmail(e.target.value)}
              placeholder="admin@academy.edu.pk"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={() => setIsCreateModalOpen(false)}
              className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl font-bold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black shadow-md shadow-indigo-900/30 cursor-pointer"
            >
              Confirm & Allot Academy
            </button>
          </div>
        </form>
      </Modal>

      {/* Edit Academy Modal (Developer Authority) */}
      <Modal
        isOpen={isEditModalOpen}
        onClose={() => {
          setIsEditModalOpen(false);
          setEditingAcademy(null);
        }}
        title={`Edit Academy: ${editingAcademy?.academyName || ''}`}
      >
        <form onSubmit={handleSaveEdit} className="space-y-4 text-xs">
          <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-2xl flex items-center gap-2.5 text-amber-800">
            <span className="text-base">👑</span>
            <div>
              <p className="font-bold text-[11px]">Developer Master Authority</p>
              <p className="text-[10px] text-amber-700">Modifying academy ID: <span className="font-mono font-bold">{editingAcademy?.academyId}</span></p>
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Academy / Campus Official Name *
            </label>
            <input
              type="text"
              required
              value={editName}
              onChange={(e) => setEditName(e.target.value)}
              placeholder="e.g. Taleem Academy Main Campus"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl outline-none focus:border-indigo-600"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Campus Code *</label>
              <input
                type="text"
                required
                value={editCode}
                onChange={(e) => setEditCode(e.target.value)}
                placeholder="TAK-01"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl uppercase font-mono outline-none focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Official Phone</label>
              <input
                type="text"
                value={editPhone}
                onChange={(e) => setEditPhone(e.target.value)}
                placeholder="0300-1234567"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">Campus Physical Address</label>
            <input
              type="text"
              value={editAddress}
              onChange={(e) => setEditAddress(e.target.value)}
              placeholder="City, District, Province"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl outline-none focus:border-indigo-600"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Assigned Admin Email</label>
              <input
                type="email"
                value={editAdminEmail}
                onChange={(e) => setEditAdminEmail(e.target.value)}
                placeholder="admin@academy.edu.pk"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl outline-none focus:border-indigo-600"
              />
            </div>
            <div>
              <label className="block font-bold text-slate-700 mb-1">Assigned Admin Name</label>
              <input
                type="text"
                value={editAdminName}
                onChange={(e) => setEditAdminName(e.target.value)}
                placeholder="Prof. Name"
                className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          <div className="flex items-center gap-2.5 p-3 bg-slate-50 border rounded-xl">
            <input
              type="checkbox"
              id="editIsActiveCheckbox"
              checked={editIsActive}
              onChange={(e) => setEditIsActive(e.target.checked)}
              className="w-4 h-4 rounded text-indigo-600 cursor-pointer"
            />
            <label htmlFor="editIsActiveCheckbox" className="font-bold text-slate-700 cursor-pointer text-xs">
              Branch Active Status (Show in Campus Selectors)
            </label>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={() => {
                setIsEditModalOpen(false);
                setEditingAcademy(null);
              }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black shadow-md shadow-indigo-900/30 cursor-pointer"
            >
              Save Academy Changes
            </button>
          </div>
        </form>
      </Modal>

      {/* Custom Credentials Editor Modal */}
      <Modal
        isOpen={!!customEditRole}
        onClose={() => setCustomEditRole(null)}
        title={`Custom Credentials: ${customEditRole ? demoConfig.accounts[customEditRole]?.roleTitle : ''}`}
      >
        <form onSubmit={handleSaveCustomCredentials} className="space-y-4 text-xs">
          <p className="text-slate-500 text-[11px] leading-relaxed">
            Set custom Login ID and Password for this demo account. These credentials will be strictly required on the login page for this role.
          </p>
          <div>
            <label className="block font-bold text-slate-700 mb-1">Demo Login ID / Username *</label>
            <input
              type="text"
              required
              value={customLoginInput}
              onChange={(e) => setCustomLoginInput(e.target.value)}
              placeholder="e.g. demo.admin@taleemos.pk"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-mono text-xs outline-none focus:border-indigo-600"
            />
          </div>
          <div>
            <label className="block font-bold text-slate-700 mb-1">Demo Password *</label>
            <input
              type="text"
              required
              value={customPasswordInput}
              onChange={(e) => setCustomPasswordInput(e.target.value)}
              placeholder="e.g. CustomPass#123"
              className="w-full px-3.5 py-2.5 bg-slate-50 border rounded-xl font-mono text-xs outline-none focus:border-indigo-600"
            />
          </div>
          <div className="flex justify-end gap-2 pt-3 border-t">
            <button
              type="button"
              onClick={() => setCustomEditRole(null)}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black shadow-md shadow-indigo-900/30 cursor-pointer"
            >
              Save Credentials
            </button>
          </div>
        </form>
      </Modal>

      {/* Delete Academy Confirmation Modal */}
      <Modal
        isOpen={!!deletingAcademy}
        onClose={() => setDeletingAcademy(null)}
        title="Confirm Academy Permanent Deletion"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-900">
            <span className="text-xl">⚠️</span>
            <div className="space-y-1">
              <p className="font-bold text-sm text-rose-950">
                Are you sure you want to delete this academy?
              </p>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                You are about to permanently remove <strong className="text-slate-900">{deletingAcademy?.academyName}</strong> (Code: <code className="font-mono font-bold text-indigo-700">{deletingAcademy?.code}</code>).
              </p>
              <p className="text-rose-700 font-semibold text-[10px]">
                This will unregister the branch from the multi-campus network.
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t">
            <button
              type="button"
              onClick={() => setDeletingAcademy(null)}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={confirmDeleteAcademy}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black shadow-lg shadow-rose-900/30 transition cursor-pointer flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Yes, Delete Academy Permanently</span>
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete User Confirmation Modal */}
      <Modal
        isOpen={!!deletingUser}
        onClose={() => setDeletingUser(null)}
        title="Confirm User Deletion (Developer Override)"
      >
        <div className="space-y-4 text-xs">
          <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-900">
            <span className="text-xl">🗑️</span>
            <div className="space-y-1">
              <p className="font-bold text-sm text-rose-950">
                Delete User: {deletingUser?.name}
              </p>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                Email: <strong>{deletingUser?.email}</strong> &bull; Role: <strong className="uppercase">{deletingUser?.role}</strong>
              </p>
              <p className="text-rose-700 font-semibold text-[10px]">
                This action will permanently delete this account credentials and associated roles.
              </p>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2 border-t">
            <button
              type="button"
              onClick={() => setDeletingUser(null)}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={confirmDeleteUser}
              className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black shadow-lg shadow-rose-900/30 transition cursor-pointer"
            >
              Confirm Delete User
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default DeveloperModule;
