import React, { useState } from 'react';
import {
  Building2,
  Search,
  Plus,
  X,
  Wrench,
  Calendar,
  MapPin,
  DollarSign,
  TrendingDown,
  ShieldAlert,
  Percent,
  Download,
  Printer,
  Sparkles,
  Layers,
  CheckCircle2,
  Sliders,
  Clock,
  Trash2,
  Edit2
} from 'lucide-react';
import { triggerBrowserPrint } from '../lib/pdf';
import { FloatingPdfButton } from '../components/common/FloatingPdfButton';
import { UnifiedPrintLayout } from '../components/common/UnifiedPrintLayout';
import { Modal } from '../components/common/Modal';
import { logAuditEvent } from '../lib/auditLogger';

export interface CampusAsset {
  id: string;
  name: string;
  category: 'Vehicle' | 'Electronics & IT' | 'Lab Equipment' | 'Campus Furniture' | 'HVAC & Solar Power';
  location: string;
  purchaseDate: string; // YYYY-MM-DD
  originalCost: number; // PKR
  usefulLifeYears: number; // e.g. 5, 10
  salvageValue: number; // PKR scrap value
  depreciationMethod: 'Straight-Line' | 'Reducing-Balance';
  condition: 'Good' | 'Needs Repair' | 'Damaged' | 'Surplus';
  assignedTo: string;
}

const INITIAL_ASSETS: CampusAsset[] = [
  {
    id: 'AST-001',
    name: 'School Bus - Toyota Coaster (52 Seater)',
    category: 'Vehicle',
    location: 'Campus Parking Bay 1',
    purchaseDate: '2021-06-15',
    originalCost: 4800000,
    usefulLifeYears: 10,
    salvageValue: 800000,
    depreciationMethod: 'Straight-Line',
    condition: 'Good',
    assignedTo: 'Transport Department',
  },
  {
    id: 'AST-002',
    name: 'Interactive Smart Panels 75" 4K (Set of 6)',
    category: 'Electronics & IT',
    location: 'Senior Wing Classrooms',
    purchaseDate: '2023-02-10',
    originalCost: 1650000,
    usefulLifeYears: 5,
    salvageValue: 150000,
    depreciationMethod: 'Straight-Line',
    condition: 'Good',
    assignedTo: 'IT & Smart Classroom Incharge',
  },
  {
    id: 'AST-003',
    name: '30kW On-Grid Hybrid Solar Inverter System',
    category: 'HVAC & Solar Power',
    location: 'Main Academic Block Rooftop',
    purchaseDate: '2022-08-20',
    originalCost: 3200000,
    usefulLifeYears: 15,
    salvageValue: 400000,
    depreciationMethod: 'Straight-Line',
    condition: 'Good',
    assignedTo: 'Campus Facilities Head',
  },
  {
    id: 'AST-004',
    name: 'Advanced Optical Microscopes & Centrifuge Lab',
    category: 'Lab Equipment',
    location: 'Senior Biology & Biotech Lab',
    purchaseDate: '2022-11-05',
    originalCost: 750000,
    usefulLifeYears: 7,
    salvageValue: 80000,
    depreciationMethod: 'Straight-Line',
    condition: 'Needs Repair',
    assignedTo: 'Senior Science Faculty',
  },
  {
    id: 'AST-005',
    name: 'Ergonomic Student Dual Desks & Benches (120 Sets)',
    category: 'Campus Furniture',
    location: 'Classes 9 & 10 Wings',
    purchaseDate: '2020-03-12',
    originalCost: 960000,
    usefulLifeYears: 8,
    salvageValue: 100000,
    depreciationMethod: 'Straight-Line',
    condition: 'Good',
    assignedTo: 'Estate & Logistics',
  },
  {
    id: 'AST-006',
    name: 'High-Volume Enterprise Xerox Photocopier & Scanner',
    category: 'Electronics & IT',
    location: 'Exam Cell & Staff Room',
    purchaseDate: '2023-09-01',
    originalCost: 450000,
    usefulLifeYears: 4,
    salvageValue: 50000,
    depreciationMethod: 'Straight-Line',
    condition: 'Good',
    assignedTo: 'Examination Controller',
  },
];

export const AssetsModule: React.FC = () => {
  const [assets, setAssets] = useState<CampusAsset[]>(INITIAL_ASSETS);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('All');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'registry'>('dashboard');
  const [depreciationMode, setDepreciationMode] = useState<'Straight-Line' | 'Reducing-Balance'>('Straight-Line');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form Fields
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<CampusAsset['category']>('Electronics & IT');
  const [formLocation, setFormLocation] = useState('');
  const [formOriginalCost, setFormOriginalCost] = useState(150000);
  const [formUsefulLifeYears, setFormUsefulLifeYears] = useState(5);
  const [formSalvageValue, setFormSalvageValue] = useState(20000);
  const [formCondition, setFormCondition] = useState<CampusAsset['condition']>('Good');
  const [formAssignedTo, setFormAssignedTo] = useState('');
  const [formPurchaseDate, setFormPurchaseDate] = useState(new Date().toISOString().split('T')[0]);

  // Real-time calculation helper
  const now = new Date();
  const calculateDepreciation = (asset: CampusAsset) => {
    const pDate = new Date(asset.purchaseDate);
    const diffTime = Math.max(0, now.getTime() - pDate.getTime());
    const ageYears = diffTime / (1000 * 60 * 60 * 24 * 365.25);

    let currentBookValue = asset.originalCost;
    let accumulatedDepreciation = 0;

    if (depreciationMode === 'Straight-Line') {
      const depreciableAmount = Math.max(0, asset.originalCost - asset.salvageValue);
      const annualDepreciation = depreciableAmount / (asset.usefulLifeYears || 1);
      accumulatedDepreciation = Math.min(depreciableAmount, annualDepreciation * ageYears);
      currentBookValue = Math.max(asset.salvageValue, asset.originalCost - accumulatedDepreciation);
    } else {
      // Reducing-Balance method with standardized annual rate derived from salvage
      const rate = 1 - Math.pow(Math.max(0.01, asset.salvageValue / asset.originalCost), 1 / (asset.usefulLifeYears || 5));
      currentBookValue = Math.max(asset.salvageValue, asset.originalCost * Math.pow(1 - rate, ageYears));
      accumulatedDepreciation = asset.originalCost - currentBookValue;
    }

    const writtenOffPercentage = Math.min(100, Math.round((accumulatedDepreciation / asset.originalCost) * 100));
    const remainingUsefulLife = Math.max(0, Number((asset.usefulLifeYears - ageYears).toFixed(1)));

    return {
      ageYears: Number(ageYears.toFixed(1)),
      currentBookValue: Math.round(currentBookValue),
      accumulatedDepreciation: Math.round(accumulatedDepreciation),
      writtenOffPercentage,
      remainingUsefulLife,
    };
  };

  // Summaries
  const totalOriginalCost = assets.reduce((sum, a) => sum + a.originalCost, 0);
  const totalBookValue = assets.reduce((sum, a) => sum + calculateDepreciation(a).currentBookValue, 0);
  const totalDepreciation = totalOriginalCost - totalBookValue;
  const overallRetentionRate = Math.round((totalBookValue / totalOriginalCost) * 100);

  // Filtered Assets
  const filteredAssets = assets.filter((a) => {
    const matchesSearch =
      a.name.toLowerCase().includes(search.toLowerCase()) ||
      a.id.toLowerCase().includes(search.toLowerCase()) ||
      a.location.toLowerCase().includes(search.toLowerCase()) ||
      a.assignedTo.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || a.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const handleCreateAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || formOriginalCost <= 0) return;

    const newAsset: CampusAsset = {
      id: `AST-00${assets.length + 1}`,
      name: formName,
      category: formCategory,
      location: formLocation || 'Main Campus',
      purchaseDate: formPurchaseDate,
      originalCost: Number(formOriginalCost),
      usefulLifeYears: Number(formUsefulLifeYears),
      salvageValue: Number(formSalvageValue),
      depreciationMethod: depreciationMode,
      condition: formCondition,
      assignedTo: formAssignedTo || 'Facilities Management',
    };

    setAssets([newAsset, ...assets]);
    logAuditEvent({
      action: 'ASSET_CREATE',
      module: 'Assets & Infrastructure',
      targetRecord: newAsset.name,
      details: `Capitalized asset with initial cost PKR ${newAsset.originalCost.toLocaleString()}`,
    });

    setIsAddModalOpen(false);
    setFormName('');
    setFormLocation('');
    setToastMessage(`Capitalized asset ${newAsset.name} successfully.`);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleDeleteAsset = (id: string) => {
    const target = assets.find((a) => a.id === id);
    if (confirm(`Remove asset ${target?.name || id} from the depreciation schedule?`)) {
      setAssets(assets.filter((a) => a.id !== id));
      logAuditEvent({
        action: 'ASSET_DECOMMISSION',
        module: 'Assets & Infrastructure',
        targetRecord: target?.name || id,
        details: `Removed asset from active balance sheet`,
      });
      setToastMessage('Asset retired from ledger.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200 relative">
      {/* Floating Download as PDF */}
      <FloatingPdfButton
        label="Export Asset Valuation PDF"
        onPrint={() => triggerBrowserPrint()}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Hero Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <Building2 className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">
              Campus Assets &amp; Depreciation Engine
            </h1>
            <span className="px-2 py-0.5 bg-emerald-500 text-white font-black text-[10px] rounded uppercase">
              GAAP / IFRS
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Real-time physical asset capitalization, accumulated amortization, and dynamic book value tracking.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => triggerBrowserPrint()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Schedule
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Capitalize Asset
          </button>
        </div>
      </div>

      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-sm">
          <div className="text-[11px] font-semibold text-slate-500 uppercase">Original Capital Outlay</div>
          <div className="text-2xl font-black text-slate-900 font-mono mt-1">
            PKR {totalOriginalCost.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Historical Purchase Value</div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-emerald-200 bg-emerald-50/20 shadow-sm">
          <div className="text-[11px] font-semibold text-emerald-700 uppercase">Current Real-Time Book Value</div>
          <div className="text-2xl font-black text-emerald-700 font-mono mt-1">
            PKR {totalBookValue.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600 font-bold mt-0.5">
            {overallRetentionRate}% Residual Asset Net Worth
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-rose-200 bg-rose-50/20 shadow-sm">
          <div className="text-[11px] font-semibold text-rose-700 uppercase">Accumulated Depreciation</div>
          <div className="text-2xl font-black text-rose-700 font-mono mt-1">
            PKR {totalDepreciation.toLocaleString()}
          </div>
          <div className="text-[11px] text-rose-600 font-bold mt-0.5">
            {100 - overallRetentionRate}% Total Value Amortized
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-indigo-200 bg-indigo-50/20 shadow-sm">
          <div className="text-[11px] font-semibold text-indigo-700 uppercase">Depreciation Model</div>
          <div className="flex items-center justify-between mt-1.5">
            <span className="text-sm font-black text-indigo-900 font-mono">
              {depreciationMode}
            </span>
            <button
              type="button"
              onClick={() =>
                setDepreciationMode(
                  depreciationMode === 'Straight-Line' ? 'Reducing-Balance' : 'Straight-Line'
                )
              }
              className="text-[10px] font-bold px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg shadow-sm cursor-pointer"
            >
              Switch Model
            </button>
          </div>
          <div className="text-[11px] text-indigo-600 mt-1">
            {depreciationMode === 'Straight-Line' ? 'Constant Annual Write-Off' : 'Accelerated Front-Loaded'}
          </div>
        </div>
      </div>

      {/* Tabs & Filters Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search assets by name, code (AST-001), custodian, or location..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 outline-none focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 outline-none cursor-pointer"
            >
              <option value="All">All Categories</option>
              <option value="Vehicle">Vehicle</option>
              <option value="Electronics & IT">Electronics &amp; IT</option>
              <option value="Lab Equipment">Lab Equipment</option>
              <option value="Campus Furniture">Campus Furniture</option>
              <option value="HVAC & Solar Power">HVAC &amp; Solar Power</option>
            </select>
          </div>
        </div>
      </div>

      {/* Detailed Real-Time Asset Depreciation Schedule Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-sm font-black text-slate-900 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-600" />
            <span>Asset Valuation &amp; Real-Time Net Book Value Schedule</span>
          </h2>
          <span className="text-xs text-slate-500 font-semibold">
            {filteredAssets.length} Active Records
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold uppercase text-[10px] tracking-wider">
                <th className="py-3 px-4">Asset ID &amp; Item</th>
                <th className="py-3 px-4">Category &amp; Location</th>
                <th className="py-3 px-4">Acquisition &amp; Age</th>
                <th className="py-3 px-4 text-right">Original Cost</th>
                <th className="py-3 px-4 text-right">Amortized</th>
                <th className="py-3 px-4 text-right">Net Book Value</th>
                <th className="py-3 px-4 text-center">Remaining Life</th>
                <th className="py-3 px-4 text-center">Condition</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredAssets.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400">
                    No assets matched your search or category filter.
                  </td>
                </tr>
              ) : (
                filteredAssets.map((asset) => {
                  const dep = calculateDepreciation(asset);
                  return (
                    <tr key={asset.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="font-mono text-[10px] font-black text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded inline-block">
                          {asset.id}
                        </div>
                        <div className="font-extrabold text-slate-900 mt-1">{asset.name}</div>
                        <div className="text-[10px] text-slate-400">Custodian: {asset.assignedTo}</div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700">
                          {asset.category}
                        </span>
                        <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-slate-400" />
                          <span>{asset.location}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-mono text-slate-800">{asset.purchaseDate}</div>
                        <div className="text-[10px] text-slate-500 mt-0.5">
                          Age: <strong>{dep.ageYears} yrs</strong> of {asset.usefulLifeYears}y
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900">
                        PKR {asset.originalCost.toLocaleString()}
                        <div className="text-[10px] text-slate-400 font-normal">
                          Scrap: PKR {asset.salvageValue.toLocaleString()}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono text-rose-600 font-bold">
                        -PKR {dep.accumulatedDepreciation.toLocaleString()}
                        <div className="text-[10px] text-rose-500 font-normal">
                          ({dep.writtenOffPercentage}% written off)
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-right font-mono font-black text-emerald-700 text-sm">
                        PKR {dep.currentBookValue.toLocaleString()}
                        <div className="w-20 ml-auto bg-slate-100 rounded-full h-1.5 mt-1 overflow-hidden">
                          <div
                            className="bg-emerald-500 h-1.5 rounded-full"
                            style={{ width: `${100 - dep.writtenOffPercentage}%` }}
                          />
                        </div>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span className="font-mono font-bold text-indigo-700">
                          {dep.remainingUsefulLife} yrs
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <span
                          className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                            asset.condition === 'Good'
                              ? 'bg-emerald-100 text-emerald-800'
                              : asset.condition === 'Needs Repair'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {asset.condition}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <button
                          type="button"
                          onClick={() => handleDeleteAsset(asset.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer transition-colors"
                          title="Decommission Asset"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add New Asset Capitalization Modal */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Capitalize New Campus Asset"
        subtitle="Add infrastructure or equipment to the real-time depreciation schedule"
        badge="CAPITAL EXPENDITURE"
      >
        <form onSubmit={handleCreateAsset} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Asset Title / Specification *
            </label>
            <input
              type="text"
              required
              value={formName}
              onChange={(e) => setFormName(e.target.value)}
              placeholder="e.g. 50-KVA Silent Backup Diesel Generator"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Asset Category
              </label>
              <select
                value={formCategory}
                onChange={(e) => setFormCategory(e.target.value as CampusAsset['category'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Electronics & IT">Electronics &amp; IT</option>
                <option value="Vehicle">Vehicle / Transport</option>
                <option value="HVAC & Solar Power">HVAC &amp; Solar Power</option>
                <option value="Lab Equipment">Lab Equipment</option>
                <option value="Campus Furniture">Campus Furniture</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Installation Location
              </label>
              <input
                type="text"
                required
                value={formLocation}
                onChange={(e) => setFormLocation(e.target.value)}
                placeholder="e.g. Generator Yard / Ground Floor"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Original Cost (PKR) *
              </label>
              <input
                type="number"
                required
                min={1000}
                value={formOriginalCost}
                onChange={(e) => setFormOriginalCost(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Useful Life (Years) *
              </label>
              <input
                type="number"
                required
                min={1}
                max={50}
                value={formUsefulLifeYears}
                onChange={(e) => setFormUsefulLifeYears(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Salvage Value (PKR)
              </label>
              <input
                type="number"
                min={0}
                value={formSalvageValue}
                onChange={(e) => setFormSalvageValue(Number(e.target.value))}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Acquisition Date *
              </label>
              <input
                type="date"
                required
                value={formPurchaseDate}
                onChange={(e) => setFormPurchaseDate(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Physical Condition
              </label>
              <select
                value={formCondition}
                onChange={(e) => setFormCondition(e.target.value as CampusAsset['condition'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                <option value="Good">Good / Operational</option>
                <option value="Needs Repair">Needs Repair</option>
                <option value="Damaged">Damaged</option>
                <option value="Surplus">Surplus / Standby</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Assigned Custodian
              </label>
              <input
                type="text"
                value={formAssignedTo}
                onChange={(e) => setFormAssignedTo(e.target.value)}
                placeholder="e.g. Electrical Incharge"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-md shadow-indigo-600/30 cursor-pointer"
            >
              Capitalize Asset
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AssetsModule;
