import React, { useState, useEffect, useRef } from 'react';
import {
  MessageSquare,
  Plus,
  Printer,
  Download,
  Send,
  Phone,
  Bell,
  Radio,
  CheckCircle2,
  Bookmark,
  Sparkles,
  Edit2,
  Trash2,
  Copy,
  Eye,
  Tag,
  Layers,
  ArrowRight,
  Info,
} from 'lucide-react';
import { erpStorage } from '../lib/storage';
import { type CommunicationMessage, type MessageTemplate } from '../types';
import { Modal } from '../components/common/Modal';
import { LetterheadPrint } from '../components/common/LetterheadPrint';
import { triggerBrowserPrint, downloadElementAsPdf } from '../lib/pdf';
import {
  getMessageTemplates,
  saveMessageTemplate,
  deleteMessageTemplate,
  substitutePlaceholders,
  DYNAMIC_PLACEHOLDERS,
} from '../lib/messageTemplates';
import { logAuditEvent } from '../lib/auditLogger';
import { getCurrentUser } from '../components/auth/AuthSystem';
import { FloatingPdfButton } from '../components/common/FloatingPdfButton';

export const CommunicationModule: React.FC = () => {
  const state = erpStorage.getState();
  const currentUser = getCurrentUser();
  const academyId = currentUser?.academyId || state.activeInstitutionId || 'inst-1';

  // Navigation tab
  const [activeTab, setActiveTab] = useState<'outbox' | 'templates'>('outbox');

  // Broadcast modal state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPrintAllOpen, setIsPrintAllOpen] = useState(false);
  const [sentNotice, setSentNotice] = useState<string | null>(null);

  // Compose Broadcast form fields
  const [channel, setChannel] = useState<CommunicationMessage['channel']>('WhatsApp');
  const [audience, setAudience] = useState<CommunicationMessage['audience']>('All Students');
  const [targetBatch, setTargetBatch] = useState('Batch 2026-A (Morning)');
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const messageInputRef = useRef<HTMLTextAreaElement>(null);

  // Template Manager state
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);
  const [editingTemplateId, setEditingTemplateId] = useState<string | null>(null);
  const [tmplTitle, setTmplTitle] = useState('');
  const [tmplCategory, setTmplCategory] = useState<MessageTemplate['category']>('Fee Reminder');
  const [tmplChannel, setTmplChannel] = useState<MessageTemplate['channel']>('SMS');
  const [tmplMessage, setTmplMessage] = useState('');
  const [tmplError, setTmplError] = useState<string | null>(null);
  const templateInputRef = useRef<HTMLTextAreaElement>(null);

  const loadTemplates = () => {
    setTemplates(getMessageTemplates(academyId));
  };

  useEffect(() => {
    loadTemplates();
    const handleTemplateChange = () => loadTemplates();
    window.addEventListener('taleemos_templates_changed', handleTemplateChange);
    return () => window.removeEventListener('taleemos_templates_changed', handleTemplateChange);
  }, [academyId]);

  // Insert dynamic placeholder into textarea
  const insertPlaceholderIntoBroadcast = (tag: string) => {
    const textarea = messageInputRef.current;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const before = message.substring(0, start);
      const after = message.substring(end);
      const newText = before + tag + after;
      setMessage(newText);
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + tag.length, start + tag.length);
      }, 50);
    } else {
      setMessage((prev) => (prev ? `${prev} ${tag}` : tag));
    }
  };

  const insertPlaceholderIntoTemplate = (tag: string) => {
    const textarea = templateInputRef.current;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const before = tmplMessage.substring(0, start);
      const after = tmplMessage.substring(end);
      const newText = before + tag + after;
      setTmplMessage(newText);
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + tag.length, start + tag.length);
      }, 50);
    } else {
      setTmplMessage((prev) => (prev ? `${prev} ${tag}` : tag));
    }
  };

  const handleUseTemplate = (tmpl: MessageTemplate) => {
    setTitle(tmpl.title);
    setMessage(tmpl.message);
    setChannel(tmpl.channel as any);
    setIsAddModalOpen(true);
    setSentNotice(`Loaded template: "${tmpl.title}" into broadcast composer.`);
    setTimeout(() => setSentNotice(null), 3000);
  };

  const handleOpenAddTemplate = () => {
    setEditingTemplateId(null);
    setTmplTitle('');
    setTmplCategory('Fee Reminder');
    setTmplChannel('SMS');
    setTmplMessage('');
    setTmplError(null);
    setIsTemplateModalOpen(true);
  };

  const handleOpenEditTemplate = (tmpl: MessageTemplate) => {
    setEditingTemplateId(tmpl.id);
    setTmplTitle(tmpl.title);
    setTmplCategory(tmpl.category);
    setTmplChannel(tmpl.channel);
    setTmplMessage(tmpl.message);
    setTmplError(null);
    setIsTemplateModalOpen(true);
  };

  const handleSaveTemplate = (e: React.FormEvent) => {
    e.preventDefault();
    setTmplError(null);

    if (!tmplTitle.trim() || !tmplMessage.trim()) {
      setTmplError('Please fill in both the title and the message body.');
      return;
    }

    const res = saveMessageTemplate(
      {
        id: editingTemplateId || undefined,
        title: tmplTitle.trim(),
        category: tmplCategory,
        channel: tmplChannel,
        message: tmplMessage.trim(),
      },
      academyId
    );

    if (!res.success) {
      setTmplError(res.error || 'Failed to save template.');
      return;
    }

    loadTemplates();
    setIsTemplateModalOpen(false);
    setSentNotice(editingTemplateId ? 'Template updated successfully!' : 'New template saved!');
    setTimeout(() => setSentNotice(null), 3000);
  };

  const handleDeleteTemplate = (id: string, titleStr: string) => {
    if (confirm(`Are you sure you want to delete message template "${titleStr}"?`)) {
      const res = deleteMessageTemplate(id, academyId);
      if (res.success) {
        loadTemplates();
        setSentNotice(`Deleted template "${titleStr}".`);
        setTimeout(() => setSentNotice(null), 3000);
      } else {
        alert(res.error || 'Failed to delete template.');
      }
    }
  };

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;

    const newMsg: CommunicationMessage = {
      id: `COM-${Date.now().toString().slice(-4)}`,
      channel,
      audience,
      targetBatch: audience === 'Selected Batch' ? targetBatch : undefined,
      title,
      message,
      sentDate: new Date().toISOString().split('T')[0],
      sentBy: state.userName,
      deliveryStatus: 'Delivered',
    };

    erpStorage.addItem('communications', newMsg);

    logAuditEvent({
      action: 'BROADCAST_MESSAGE',
      module: 'Communication',
      targetRecord: `${title} (${channel})`,
      targetId: newMsg.id,
      details: `Dispatched ${channel} broadcast to ${audience}${targetBatch ? ` (${targetBatch})` : ''}`,
      academyId,
    });

    setIsAddModalOpen(false);

    // If channel is WhatsApp, open wa.me
    if (channel === 'WhatsApp') {
      const resolved = substitutePlaceholders(message);
      window.open(
        `https://wa.me/?text=${encodeURIComponent(`*${title}*\n\n${resolved}\n\n- ${currentUser?.academyName || 'Taleem Academy'}`)}`,
        '_blank'
      );
    }

    setSentNotice(`Successfully broadcasted message via ${channel} to ${audience}!`);
    setTimeout(() => setSentNotice(null), 4000);

    setTitle('');
    setMessage('');
  };

  const filteredTemplates = templates.filter(
    (t) => selectedCategory === 'All' || t.category === selectedCategory
  );

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      <FloatingPdfButton
        label="Download Communication PDF"
        onPrint={() => setIsPrintAllOpen(true)}
      />

      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <MessageSquare className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">Institutional Communication Hub</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              MULTI-CHANNEL & TEMPLATES
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Bulk SMS gateways, official WhatsApp broadcasts, message template manager, and digital notice board.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setIsPrintAllOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white text-xs font-bold rounded-xl border border-white/20 transition-all cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            Print Dispatch Log
          </button>
          <button
            type="button"
            onClick={handleOpenAddTemplate}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-indigo-700 hover:bg-indigo-600 active:scale-95 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-sm"
          >
            <Bookmark className="w-4 h-4" />
            New Template
          </button>
          <button
            type="button"
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
            Compose Broadcast
          </button>
        </div>
      </div>

      {sentNotice && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl animate-in fade-in flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{sentNotice}</span>
        </div>
      )}

      {/* Tabs Switcher: Outbox vs Template Manager */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          type="button"
          onClick={() => setActiveTab('outbox')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'outbox'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Radio className="w-4 h-4" />
          <span>Broadcast Outbox ({state.communications.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('templates')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
            activeTab === 'templates'
              ? 'bg-indigo-600 text-white shadow-md'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>Message Template Manager ({templates.length})</span>
        </button>
      </div>

      {/* TAB 1: BROADCAST OUTBOX FEED */}
      {activeTab === 'outbox' && (
        <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
              <Radio className="w-4 h-4 text-indigo-600" />
              Broadcast Outbox & Delivery Status
            </h3>
            <span className="text-xs text-slate-400">Multi-Channel Instant Delivery</span>
          </div>

          <div className="space-y-3">
            {state.communications.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                <MessageSquare className="w-8 h-8 mx-auto mb-2 text-slate-300" />
                No broadcast messages logged yet. Click &quot;Compose Broadcast&quot; to send an announcement.
              </div>
            ) : (
              state.communications.map((c) => (
                <div
                  key={c.id}
                  className="p-4 bg-slate-50 hover:bg-white rounded-2xl border border-slate-200 transition-all flex flex-col md:flex-row md:items-start justify-between gap-3"
                >
                  <div className="flex items-start gap-3">
                    <div
                      className={`p-2.5 rounded-xl text-white font-black shrink-0 ${
                        c.channel === 'WhatsApp'
                          ? 'bg-emerald-600'
                          : c.channel === 'SMS'
                          ? 'bg-indigo-600'
                          : 'bg-amber-600'
                      }`}
                    >
                      {c.channel === 'WhatsApp' ? (
                        <MessageSquare className="w-5 h-5" />
                      ) : c.channel === 'SMS' ? (
                        <Phone className="w-5 h-5" />
                      ) : (
                        <Bell className="w-5 h-5" />
                      )}
                    </div>

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-slate-900 text-sm">{c.title}</span>
                        <span className="px-2 py-0.5 bg-slate-200 text-slate-700 text-[10px] font-bold rounded">
                          {c.audience} {c.targetBatch ? `(${c.targetBatch})` : ''}
                        </span>
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">
                          {c.deliveryStatus}
                        </span>
                      </div>

                      <p className="mt-1.5 text-xs text-slate-700 bg-white p-3 rounded-xl border border-slate-100 leading-relaxed font-medium">
                        {c.message}
                      </p>

                      <div className="mt-2 text-[10px] text-slate-400 font-mono">
                        Channel: {c.channel} &bull; Dispatched by {c.sentBy} on {c.sentDate}
                      </div>
                    </div>
                  </div>

                  {c.channel === 'WhatsApp' && (
                    <button
                      type="button"
                      onClick={() =>
                        window.open(
                          `https://wa.me/?text=${encodeURIComponent(`*${c.title}*\n\n${c.message}\n\n- ${currentUser?.academyName || 'Taleem Academy'}`)}`,
                          '_blank'
                        )
                      }
                      className="px-3 py-1.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-bold hover:bg-emerald-100 shrink-0 cursor-pointer"
                    >
                      Re-share WhatsApp
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 2: TEMPLATE MANAGER */}
      {activeTab === 'templates' && (
        <div className="space-y-4">
          {/* Category Filter Pills & Add Button */}
          <div className="p-4 bg-white rounded-[22px] border border-slate-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mr-1">
                Category:
              </span>
              {[
                'All',
                'Fee Reminder',
                'Attendance Alert',
                'Exam Notice',
                'General Announcement',
                'Admission',
              ].map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1 rounded-full text-[11px] font-bold cursor-pointer transition-all ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={handleOpenAddTemplate}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 shadow-sm cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Create Template</span>
            </button>
          </div>

          {/* Templates Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredTemplates.map((tmpl) => {
              const previewText = substitutePlaceholders(tmpl.message);

              return (
                <div
                  key={tmpl.id}
                  className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                          tmpl.category === 'Fee Reminder'
                            ? 'bg-emerald-100 text-emerald-800'
                            : tmpl.category === 'Attendance Alert'
                            ? 'bg-rose-100 text-rose-800'
                            : tmpl.category === 'Exam Notice'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {tmpl.category}
                        </span>
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-700 text-[10px] font-mono rounded font-bold">
                          {tmpl.channel}
                        </span>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEditTemplate(tmpl)}
                          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition cursor-pointer"
                          title="Edit Template"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteTemplate(tmpl.id, tmpl.title)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                          title="Delete Template"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <h4 className="font-extrabold text-slate-900 text-sm mt-2">{tmpl.title}</h4>

                    {/* Raw Template with placeholder highlighting */}
                    <div className="mt-2 p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs font-mono text-slate-700 leading-relaxed">
                      {tmpl.message}
                    </div>

                    {/* Live Dynamic Resolution Preview */}
                    <div className="mt-2.5 p-3 bg-indigo-50/50 rounded-xl border border-indigo-100 text-xs text-indigo-950">
                      <div className="flex items-center gap-1 font-bold text-[10px] text-indigo-600 uppercase mb-1">
                        <Sparkles className="w-3 h-3" />
                        <span>Live Resolved Preview (Sample Student)</span>
                      </div>
                      <p className="leading-relaxed text-[11px] text-slate-700">{previewText}</p>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] text-slate-400">
                      {tmpl.isSystem ? 'System Preset' : 'Custom Template'}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleUseTemplate(tmpl)}
                      className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-sm transition cursor-pointer active:scale-95"
                    >
                      <span>Use in Broadcast</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* COMPOSE BROADCAST MODAL */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Compose Communication Broadcast"
        subtitle="Dispatches notifications via SMS gateway or WhatsApp"
        badge="BROADCAST DISPATCH"
        maxWidth="max-w-2xl"
      >
        <form onSubmit={handleBroadcast} className="space-y-4">
          {/* Quick Template Selector */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Bookmark className="w-4 h-4 text-indigo-600" />
              <span>Load Saved Template:</span>
            </span>
            <select
              onChange={(e) => {
                const found = templates.find((t) => t.id === e.target.value);
                if (found) {
                  setTitle(found.title);
                  setMessage(found.message);
                  setChannel(found.channel as any);
                }
              }}
              className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 outline-none cursor-pointer"
              defaultValue=""
            >
              <option value="" disabled>
                -- Choose from {templates.length} saved templates --
              </option>
              {templates.map((t) => (
                <option key={t.id} value={t.id}>
                  [{t.category}] {t.title}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Channel *</label>
              <select
                value={channel}
                onChange={(e) => setChannel(e.target.value as CommunicationMessage['channel'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white font-medium"
              >
                <option value="WhatsApp">WhatsApp Message</option>
                <option value="SMS">SMS Gateway</option>
                <option value="Notice Board">Digital Notice Board</option>
                <option value="Push Notification">Push Notification</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Target Audience</label>
              <select
                value={audience}
                onChange={(e) => setAudience(e.target.value as CommunicationMessage['audience'])}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white font-medium"
              >
                <option value="All Students">All Students</option>
                <option value="Selected Batch">Selected Batch Only</option>
                <option value="All Parents">All Parents</option>
                <option value="Faculty">Faculty & Staff</option>
              </select>
            </div>
          </div>

          {audience === 'Selected Batch' && (
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Choose Batch</label>
              <select
                value={targetBatch}
                onChange={(e) => setTargetBatch(e.target.value)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white"
              >
                {state.batches.map((b) => (
                  <option key={b.id} value={b.batchName}>
                    {b.batchName}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Notice Headline *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Schedule for Mid-Term Exams 2026"
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
            />
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-bold text-slate-700 uppercase">Message Content *</label>
              <span className="text-[10px] text-slate-400 font-mono">{message.length} characters</span>
            </div>

            {/* Dynamic Placeholder Insertion Chips */}
            <div className="mb-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Click placeholder to insert into draft:
              </span>
              <div className="flex flex-wrap items-center gap-1.5">
                {DYNAMIC_PLACEHOLDERS.map((p) => (
                  <button
                    key={p.tag}
                    type="button"
                    onClick={() => insertPlaceholderIntoBroadcast(p.tag)}
                    className="px-2 py-0.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-[10px] font-mono font-bold cursor-pointer transition"
                    title={`Inserts ${p.tag} (Sample: ${p.sample})`}
                  >
                    + {p.tag}
                  </button>
                ))}
              </div>
            </div>

            <textarea
              ref={messageInputRef}
              required
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Write your broadcast announcement... Click dynamic placeholder chips above to insert personalized student attributes."
              className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600 font-mono"
            />

            {/* Dynamic Resolved Live Preview */}
            {message.trim() && (
              <div className="mt-2 p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs text-indigo-950">
                <span className="text-[10px] font-bold text-indigo-600 uppercase flex items-center gap-1 mb-1">
                  <Sparkles className="w-3 h-3" /> Live Dynamic Output Preview:
                </span>
                <p className="text-slate-800 text-xs leading-relaxed font-sans">
                  {substitutePlaceholders(message)}
                </p>
              </div>
            )}
          </div>

          <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
            <button
              type="button"
              onClick={() => setIsAddModalOpen(false)}
              className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Broadcast Now</span>
            </button>
          </div>
        </form>
      </Modal>

      {/* CREATE / EDIT TEMPLATE MODAL */}
      {isTemplateModalOpen && (
        <Modal
          isOpen={isTemplateModalOpen}
          onClose={() => setIsTemplateModalOpen(false)}
          title={editingTemplateId ? 'Edit Message Draft Template' : 'Create New Message Template'}
          subtitle="Save reusable templates with dynamic student and fee placeholders"
          badge="TEMPLATE BUILDER"
          maxWidth="max-w-2xl"
        >
          <form onSubmit={handleSaveTemplate} className="space-y-4">
            {tmplError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl">
                {tmplError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Template Title *
                </label>
                <input
                  type="text"
                  required
                  value={tmplTitle}
                  onChange={(e) => setTmplTitle(e.target.value)}
                  placeholder="e.g. Monthly Tuition Fee Notice"
                  className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                  Category *
                </label>
                <select
                  value={tmplCategory}
                  onChange={(e) => setTmplCategory(e.target.value as any)}
                  className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white font-medium"
                >
                  <option value="Fee Reminder">Fee Reminder</option>
                  <option value="Attendance Alert">Attendance Alert</option>
                  <option value="Exam Notice">Exam Notice</option>
                  <option value="General Announcement">General Announcement</option>
                  <option value="Admission">Admission Confirmation</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Preferred Channel
              </label>
              <select
                value={tmplChannel}
                onChange={(e) => setTmplChannel(e.target.value as any)}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none bg-white font-medium"
              >
                <option value="SMS">SMS Gateway</option>
                <option value="WhatsApp">WhatsApp Broadcast</option>
                <option value="Push Notification">Push Notification</option>
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-slate-700 uppercase">
                  Template Message Body *
                </label>
                <span className="text-[10px] text-slate-400 font-mono">{tmplMessage.length} characters</span>
              </div>

              {/* Clickable dynamic placeholder chips */}
              <div className="mb-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 space-y-1.5">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                  Click to insert placeholder:
                </span>
                <div className="flex flex-wrap items-center gap-1.5">
                  {DYNAMIC_PLACEHOLDERS.map((p) => (
                    <button
                      key={p.tag}
                      type="button"
                      onClick={() => insertPlaceholderIntoTemplate(p.tag)}
                      className="px-2 py-0.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg text-[10px] font-mono font-bold cursor-pointer transition"
                    >
                      + {p.tag}
                    </button>
                  ))}
                </div>
              </div>

              <textarea
                ref={templateInputRef}
                required
                rows={4}
                value={tmplMessage}
                onChange={(e) => setTmplMessage(e.target.value)}
                placeholder="Dear Parent of {student_name} ({roll_no}), your fee of PKR {due_amount} for {class_name} is due by {due_date}..."
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600 font-mono"
              />

              {tmplMessage.trim() && (
                <div className="mt-2 p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs">
                  <span className="text-[10px] font-bold text-indigo-600 uppercase flex items-center gap-1 mb-1">
                    <Sparkles className="w-3 h-3" /> Live Dynamic Resolution Preview:
                  </span>
                  <p className="text-slate-800 text-xs leading-relaxed font-sans">
                    {substitutePlaceholders(tmplMessage)}
                  </p>
                </div>
              )}
            </div>

            <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsTemplateModalOpen(false)}
                className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer"
              >
                {editingTemplateId ? 'Save Changes' : 'Save Template Draft'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* PRINT ALL BROADCASTS MODAL */}
      {isPrintAllOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 no-print overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
              <h3 className="font-bold text-base text-slate-900">Communication Dispatch Records</h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => triggerBrowserPrint()}
                  className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print A4
                </button>
                <button
                  type="button"
                  onClick={() => downloadElementAsPdf('comm-print-table', 'TaleemOS_Communication_Dispatch')}
                  className="px-3 py-1.5 bg-slate-800 text-white rounded-lg text-xs font-bold hover:bg-slate-700 flex items-center gap-1 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  PDF Download
                </button>
                <button
                  type="button"
                  onClick={() => setIsPrintAllOpen(false)}
                  className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-800"
                >
                  Close
                </button>
              </div>
            </div>

            <div id="comm-print-table">
              <LetterheadPrint
                title="Institutional Communication & Broadcast Log"
                documentNo="COM-LOG-2026"
                summaryStats={[
                  { label: 'Total Messages', value: state.communications.length },
                  { label: 'Templates Available', value: templates.length },
                  { label: 'Primary Gateway', value: 'WhatsApp / SMS' },
                  { label: 'Status', value: 'All Delivered' },
                ]}
              >
                <table className="w-full border-collapse border border-slate-300 text-left text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-bold">
                      <th className="border border-slate-300 p-2">Date</th>
                      <th className="border border-slate-300 p-2">Channel</th>
                      <th className="border border-slate-300 p-2">Audience</th>
                      <th className="border border-slate-300 p-2">Headline</th>
                      <th className="border border-slate-300 p-2">Message Content</th>
                      <th className="border border-slate-300 p-2">Dispatched By</th>
                    </tr>
                  </thead>
                  <tbody>
                    {state.communications.map((c) => (
                      <tr key={c.id}>
                        <td className="border border-slate-300 p-2 font-mono text-[10px] whitespace-nowrap">
                          {c.sentDate}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold">{c.channel}</td>
                        <td className="border border-slate-300 p-2">
                          {c.audience} {c.targetBatch ? `(${c.targetBatch})` : ''}
                        </td>
                        <td className="border border-slate-300 p-2 font-bold">{c.title}</td>
                        <td className="border border-slate-300 p-2 text-slate-700">{c.message}</td>
                        <td className="border border-slate-300 p-2 font-medium">{c.sentBy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </LetterheadPrint>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CommunicationModule;
