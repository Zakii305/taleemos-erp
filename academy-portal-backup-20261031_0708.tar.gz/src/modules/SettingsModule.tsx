import React, { useState, useEffect } from 'react';
import {
  Settings,
  Shield,
  Database,
  Building2,
  RefreshCw,
  Download,
  Upload,
  CheckCircle2,
  Terminal,
  Activity,
  Plus,
  Edit2,
  Trash2,
  Calendar,
  Type,
  AlertCircle,
  FileText,
  Sliders,
} from 'lucide-react';
import { erpStorage, INSTITUTIONS } from '../lib/storage';
import { type UserRole, type CustomFieldDefinition } from '../types';
import { isFirebaseConfigured } from '../lib/firebase';
import { CLOUDINARY_CLOUD_NAME, CLOUDINARY_UPLOAD_PRESET } from '../lib/cloudinary';
import {
  getCustomFieldsForAcademy,
  addCustomField,
  updateCustomField,
  deleteCustomField,
} from '../lib/customFields';
import { getCurrentUser } from '../components/auth/AuthSystem';
import { Modal } from '../components/common/Modal';

export const SettingsModule: React.FC = () => {
  const state = erpStorage.getState();
  const currentUser = getCurrentUser();
  const academyId = currentUser?.academyId || state.activeInstitutionId || 'inst-1';

  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Custom Fields State
  const [customFields, setCustomFields] = useState<CustomFieldDefinition[]>([]);
  const [isFieldModalOpen, setIsFieldModalOpen] = useState(false);
  const [editingFieldId, setEditingFieldId] = useState<string | null>(null);
  const [fieldLabel, setFieldLabel] = useState('');
  const [fieldType, setFieldType] = useState<'text' | 'date'>('text');
  const [fieldPlaceholder, setFieldPlaceholder] = useState('');
  const [fieldRequired, setFieldRequired] = useState(false);
  const [fieldError, setFieldError] = useState<string | null>(null);

  const loadFields = () => {
    setCustomFields(getCustomFieldsForAcademy(academyId));
  };

  useEffect(() => {
    loadFields();
    const handleFieldChange = () => loadFields();
    window.addEventListener('taleemos_custom_fields_changed', handleFieldChange);
    return () => window.removeEventListener('taleemos_custom_fields_changed', handleFieldChange);
  }, [academyId]);

  const handleOpenAddField = () => {
    if (customFields.length >= 5) {
      alert('Maximum of 5 custom fields reached. Please delete an existing custom field first.');
      return;
    }
    setEditingFieldId(null);
    setFieldLabel('');
    setFieldType('text');
    setFieldPlaceholder('');
    setFieldRequired(false);
    setFieldError(null);
    setIsFieldModalOpen(true);
  };

  const handleOpenEditField = (field: CustomFieldDefinition) => {
    setEditingFieldId(field.id);
    setFieldLabel(field.label);
    setFieldType(field.type);
    setFieldPlaceholder(field.placeholder || '');
    setFieldRequired(Boolean(field.isRequired));
    setFieldError(null);
    setIsFieldModalOpen(true);
  };

  const handleSaveField = (e: React.FormEvent) => {
    e.preventDefault();
    setFieldError(null);

    if (!fieldLabel.trim()) {
      setFieldError('Field label cannot be empty.');
      return;
    }

    if (editingFieldId) {
      const res = updateCustomField(academyId, editingFieldId, {
        label: fieldLabel.trim(),
        type: fieldType,
        placeholder: fieldPlaceholder.trim(),
        isRequired: fieldRequired,
      });
      if (!res.success) {
        setFieldError(res.error || 'Failed to update field.');
        return;
      }
    } else {
      const res = addCustomField(academyId, {
        label: fieldLabel.trim(),
        type: fieldType,
        placeholder: fieldPlaceholder.trim(),
        isRequired: fieldRequired,
      });
      if (!res.success) {
        setFieldError(res.error || 'Failed to add field.');
        return;
      }
    }

    loadFields();
    setIsFieldModalOpen(false);
    setImportStatus(editingFieldId ? 'Custom student field updated!' : 'New custom student field added!');
    setTimeout(() => setImportStatus(null), 3500);
  };

  const handleDeleteField = (id: string, label: string) => {
    if (confirm(`Are you sure you want to delete custom student field "${label}"? Existing student values for this field will no longer be tracked.`)) {
      const res = deleteCustomField(academyId, id);
      if (res.success) {
        loadFields();
        setImportStatus(`Removed custom field "${label}".`);
        setTimeout(() => setImportStatus(null), 3000);
      } else {
        alert(res.error || 'Could not delete custom field.');
      }
    }
  };

  const rolesMatrix: {
    role: UserRole;
    description: string;
    permissions: string[];
  }[] = [
    {
      role: 'Super Admin',
      description: 'Full institutional authority, multi-tenant campus management, audit logs, backup and recovery.',
      permissions: ['Manage All Settings', 'All 23 Modules', 'Approve All High-Value Actions', 'Export/Import Backup'],
    },
    {
      role: 'Director / Owner',
      description: 'Executive governance, approve high admissions, fee discounts > 500, payroll sanction.',
      permissions: ['Approve Admissions', 'Approve Discounts > 500', 'Payroll Approval', 'Approve Expenses > 5000'],
    },
    {
      role: 'Principal',
      description: 'Chief Academic Officer, approves leaves, examinations, report cards, and student promotions.',
      permissions: ['Academic Approval', 'Staff Leave Sanction', 'Student Promotion', 'Marks Final Submit', 'View Finance'],
    },
    {
      role: 'Accountant',
      description: 'Financial ledger maintenance, fees collection, vouchers, defaulter follow-ups, and payroll.',
      permissions: ['Fee Invoices', 'Expense Records', 'Payroll Slip Processing', 'Defaulter Actions'],
    },
    {
      role: 'Teacher',
      description: 'Batch instructor, records student attendance for assigned cohorts, creates examination marks.',
      permissions: ['Assigned Batch Attendance', 'Marks Entry', 'Personal Timetable', 'Leave Request'],
    },
    {
      role: 'Receptionist / Front Desk',
      description: 'Campus reception, registers new enquiries and prospective admissions in pending status.',
      permissions: ['New Enquiries (Full)', 'Admissions (Pending Only)', 'Fee Collection (Pending)', 'No Deletions'],
    },
    {
      role: 'Student',
      description: 'Student portal profile, view own attendance ratio, fee vouchers, report card transcript, and books.',
      permissions: ['View Own Attendance', 'View Own Fees', 'Download Transcript', 'View Library Records'],
    },
    {
      role: 'Parent',
      description: 'Parent guardian portal, monitor child daily attendance, fee dues, notices, and exam results.',
      permissions: ['Monitor Child Attendance', 'Fee Arrears Reminders', 'Exam Report Card View'],
    },
  ];

  const handleExportBackup = () => {
    erpStorage.exportToJson();
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        const ok = erpStorage.importFromJson(text);
        if (ok) {
          setImportStatus('Backup restored successfully! All records refreshed.');
          setTimeout(() => setImportStatus(null), 4000);
        } else {
          alert('Failed to parse backup JSON file. Ensure it is a valid TaleemOS export.');
        }
      };
      reader.readAsText(file);
    }
  };

  const handleResetData = () => {
    if (confirm('Reset entire system database to initial demo state? All custom records will be replaced.')) {
      erpStorage.resetToDemo();
      setImportStatus('Database reset to factory demo state.');
      setTimeout(() => setImportStatus(null), 4000);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="rounded-[24px] bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-600 rounded-xl">
              <Settings className="w-5 h-5 text-white" />
            </span>
            <h1 className="text-xl md:text-2xl font-black tracking-tight">System Settings & Governance</h1>
            <span className="px-2 py-0.5 bg-indigo-500 text-white font-black text-[10px] rounded uppercase">
              RBAC & BACKUP
            </span>
          </div>
          <p className="text-xs text-indigo-200 mt-1">
            Enterprise role-based permissions matrix, multi-tenant campus configuration, and JSON backup/restore.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleResetData}
            className="px-3.5 py-2 bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 hover:text-white border border-rose-500/40 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            Reset to Demo Data
          </button>
        </div>
      </div>

      {importStatus && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold rounded-2xl animate-in fade-in flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{importStatus}</span>
        </div>
      )}

      {/* Cloud & Termux Configuration Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Database className="w-4 h-4 text-indigo-600" />
              Firebase Database Integration
            </h4>
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                isFirebaseConfigured()
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-indigo-100 text-indigo-800'
              }`}
            >
              {isFirebaseConfigured() ? 'Connected' : 'Offline / LocalStorage Active'}
            </span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            All records persist instantaneously in browser offline storage and sync with Firestore automatically when environment credentials in <code className="bg-slate-100 px-1 py-0.5 rounded font-mono text-indigo-700">.env</code> are provided.
          </p>
          <div className="text-[11px] font-mono text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div>Auth Domain: {import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || 'taleemos-hub.firebaseapp.com'}</div>
            <div>Project ID: {import.meta.env.VITE_FIREBASE_PROJECT_ID || 'taleemos-hub'}</div>
          </div>
        </div>

        <div className="p-5 bg-white rounded-[22px] border border-slate-200 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Upload className="w-4 h-4 text-emerald-600" />
              Cloudinary Direct Browser Uploads
            </h4>
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[10px] font-black uppercase">
              Unsigned Preset
            </span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Student photos, ID cards, and expense receipts upload directly to Cloudinary without exposing API secrets.
          </p>
          <div className="text-[11px] font-mono text-slate-600 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div>Cloud Name: {CLOUDINARY_CLOUD_NAME}</div>
            <div>Upload Preset: {CLOUDINARY_UPLOAD_PRESET}</div>
          </div>
        </div>
      </div>

      {/* Backup & Restore Section */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm space-y-4">
        <div>
          <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
            <Database className="w-4 h-4 text-indigo-600" />
            Institutional Disaster Recovery & JSON Backups
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Export a full JSON snapshot of all 23 modules or restore an earlier institutional archive.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            type="button"
            onClick={handleExportBackup}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 active:scale-95 text-white text-xs font-bold rounded-xl shadow-md shadow-indigo-600/30 flex items-center gap-2 cursor-pointer transition-all"
          >
            <Download className="w-4 h-4" />
            Export Full Database (.JSON)
          </button>

          <label className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 active:scale-95 text-slate-700 text-xs font-bold rounded-xl flex items-center gap-2 cursor-pointer transition-all border border-slate-200">
            <Upload className="w-4 h-4 text-indigo-600" />
            <span>Restore from JSON File</span>
            <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
          </label>
        </div>
      </div>

      {/* Student Records Custom Fields Configuration (Max 5 text/date fields) */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-600" />
                Student Records Custom Fields Configuration
              </h3>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${
                customFields.length >= 5
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-indigo-100 text-indigo-800'
              }`}>
                {customFields.length} / 5 Fields Configured
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Add up to 5 custom text or date fields to student profiles. These automatically appear in student registration forms, profiles, and CSV exports.
            </p>
          </div>

          <button
            type="button"
            onClick={handleOpenAddField}
            disabled={customFields.length >= 5}
            className={`px-4 py-2 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-all shrink-0 ${
              customFields.length >= 5
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
                : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-md shadow-indigo-600/30 cursor-pointer active:scale-95'
            }`}
          >
            <Plus className="w-4 h-4" />
            <span>Add Custom Field {customFields.length >= 5 ? '(Limit Reached)' : ''}</span>
          </button>
        </div>

        {/* Custom Fields Grid / Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3">Field Label</th>
                <th className="p-3">Data Type</th>
                <th className="p-3">Placeholder / Helper</th>
                <th className="p-3">Validation</th>
                <th className="p-3">Active Scope</th>
                <th className="p-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {customFields.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-6 text-center text-slate-400">
                    No custom student fields defined yet. Click &quot;Add Custom Field&quot; to configure up to 5 additional text or date fields.
                  </td>
                </tr>
              ) : (
                customFields.map((field) => (
                  <tr key={field.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="p-3 font-bold text-slate-900">
                      <div className="flex items-center gap-2">
                        <FileText className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                        <span>{field.label}</span>
                      </div>
                    </td>

                    <td className="p-3">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        field.type === 'date'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {field.type === 'date' ? (
                          <Calendar className="w-3 h-3" />
                        ) : (
                          <Type className="w-3 h-3" />
                        )}
                        <span className="capitalize">{field.type} Field</span>
                      </span>
                    </td>

                    <td className="p-3 font-mono text-slate-500 text-[11px]">
                      {field.placeholder || '—'}
                    </td>

                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        field.isRequired ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {field.isRequired ? 'Mandatory' : 'Optional'}
                      </span>
                    </td>

                    <td className="p-3 text-slate-500 text-[11px]">
                      Student Profile & CSV
                    </td>

                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => handleOpenEditField(field)}
                          className="p-1.5 hover:bg-slate-100 text-slate-600 rounded-lg transition cursor-pointer"
                          title="Edit Custom Field"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteField(field.id, field.label)}
                          className="p-1.5 hover:bg-rose-50 text-rose-600 rounded-lg transition cursor-pointer"
                          title="Delete Custom Field"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        <div className="p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-[11px] text-indigo-900 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
          <span>
            <b>Integration Note:</b> Any custom fields created here automatically show up in the <b>Students Directory modal</b>, <b>Admission forms</b>, <b>Student Profile modal</b>, and all <b>CSV/Excel exports</b>.
          </span>
        </div>
      </div>

      {/* Custom Field Add/Edit Modal */}
      {isFieldModalOpen && (
        <Modal
          isOpen={isFieldModalOpen}
          onClose={() => setIsFieldModalOpen(false)}
          title={editingFieldId ? 'Edit Custom Student Field' : 'Add Custom Student Field'}
          subtitle={`Limit: Maximum 5 custom fields per academy (${customFields.length}/5 used)`}
          badge="STUDENT SCHEMA"
          maxWidth="max-w-md"
        >
          <form onSubmit={handleSaveField} className="space-y-4">
            {fieldError && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{fieldError}</span>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Field Label *
              </label>
              <input
                type="text"
                required
                value={fieldLabel}
                onChange={(e) => setFieldLabel(e.target.value)}
                placeholder="e.g. Emergency Contact Person or Polio Vaccination Date"
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
              <span className="text-[10px] text-slate-400 mt-1 block">
                This label will be displayed as the input name and column header.
              </span>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Data Type *
              </label>
              <div className="grid grid-cols-2 gap-3">
                <label className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition ${
                  fieldType === 'text'
                    ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}>
                  <input
                    type="radio"
                    name="fieldType"
                    value="text"
                    checked={fieldType === 'text'}
                    onChange={() => setFieldType('text')}
                    className="text-indigo-600"
                  />
                  <div className="text-xs">
                    <div className="flex items-center gap-1 font-bold">
                      <Type className="w-3.5 h-3.5" /> Text Field
                    </div>
                    <span className="text-[10px] text-slate-500 font-normal">Single-line text</span>
                  </div>
                </label>

                <label className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition ${
                  fieldType === 'date'
                    ? 'border-indigo-600 bg-indigo-50/50 text-indigo-950 font-bold'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}>
                  <input
                    type="radio"
                    name="fieldType"
                    value="date"
                    checked={fieldType === 'date'}
                    onChange={() => setFieldType('date')}
                    className="text-indigo-600"
                  />
                  <div className="text-xs">
                    <div className="flex items-center gap-1 font-bold">
                      <Calendar className="w-3.5 h-3.5" /> Date Field
                    </div>
                    <span className="text-[10px] text-slate-500 font-normal">Calendar date</span>
                  </div>
                </label>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Placeholder / Hint
              </label>
              <input
                type="text"
                value={fieldPlaceholder}
                onChange={(e) => setFieldPlaceholder(e.target.value)}
                placeholder={fieldType === 'date' ? 'YYYY-MM-DD' : 'e.g. Uncle / Legal Guardian name'}
                className="w-full px-3.5 py-2 border border-slate-200 rounded-xl text-xs outline-none focus:border-indigo-600"
              />
            </div>

            <div className="pt-1">
              <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={fieldRequired}
                  onChange={(e) => setFieldRequired(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded"
                />
                <span>Mark field as mandatory during registration</span>
              </label>
            </div>

            <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFieldModalOpen(false)}
                className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-100 text-xs font-bold rounded-xl cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer"
              >
                {editingFieldId ? 'Save Changes' : 'Create Custom Field'}
              </button>
            </div>
          </form>
        </Modal>
      )}

      {/* Role-Based Access Control (RBAC) Hierarchy Table */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm space-y-4">
        <div>
          <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
            <Shield className="w-4 h-4 text-amber-500" />
            Role-Based Access Control (RBAC) & Authority Governance
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Strict institutional permission boundaries across administrative and academic roles.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                <th className="p-3 w-48">Institutional Role</th>
                <th className="p-3">Description & Scope</th>
                <th className="p-3">Authorized Capabilities</th>
              </tr>
            </thead>
            <tbody>
              {rolesMatrix.map((r, i) => (
                <tr key={i} className="border-b border-slate-100 hover:bg-slate-50/50 transition-colors">
                  <td className="p-3 font-bold text-slate-900">
                    <span
                      className={`inline-block px-2.5 py-1 rounded-lg text-xs ${
                        r.role === state.activeRole
                          ? 'bg-indigo-600 text-white font-extrabold shadow-sm'
                          : 'bg-slate-100 text-slate-800'
                      }`}
                    >
                      {r.role}
                    </span>
                  </td>
                  <td className="p-3 text-slate-600 leading-relaxed">{r.description}</td>
                  <td className="p-3">
                    <div className="flex flex-wrap gap-1">
                      {r.permissions.map((p, pIdx) => (
                        <span
                          key={pIdx}
                          className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[10px] font-medium"
                        >
                          {p}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Multi-Tenant Campuses List */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
          <Building2 className="w-4 h-4 text-indigo-600" />
          Multi-Tenant Academic Campuses
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {INSTITUTIONS.map((inst) => {
            const isSelected = inst.id === state.activeInstitutionId;
            return (
              <div
                key={inst.id || inst.academyId}
                onClick={() => erpStorage.setActiveInstitution(inst.id || inst.academyId || '')}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-50/70 border-indigo-500 shadow-md ring-2 ring-indigo-500/20'
                    : 'bg-slate-50 border-slate-200 hover:bg-white'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-xs font-black text-indigo-700">{inst.code}</span>
                  {isSelected && (
                    <span className="px-2 py-0.2 bg-indigo-600 text-white text-[10px] font-black rounded uppercase">
                      Active
                    </span>
                  )}
                </div>
                <h4 className="font-bold text-slate-900 text-sm">{inst.name}</h4>
                <p className="text-xs text-slate-500 mt-1">{inst.address}</p>
                <div className="mt-2 text-[11px] text-slate-400 font-mono">Ph: {inst.phone}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Audit Log Trail */}
      <div className="p-6 bg-white rounded-[24px] border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-600" />
          Enterprise System Audit Logs
        </h3>

        <div className="space-y-2 max-h-60 overflow-y-auto">
          {state.auditLogs.map((log) => (
            <div
              key={log.id}
              className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-1"
            >
              <div>
                <span className="font-bold text-indigo-950 font-mono mr-2">[{log.action}]</span>
                <span className="text-slate-800">{log.details}</span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono whitespace-nowrap">
                {log.timestamp} &bull; {log.user} ({log.role})
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SettingsModule;
